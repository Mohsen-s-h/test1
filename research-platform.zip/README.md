
# Integrated System for Energy Systems Planning and Simulation  
Developed within HiPEL Lab (McMaster University)  


## Overview

This repository implements the **Energy Systems Research Framework**, a research-oriented platform for integrated modeling, analysis, and design of energy systems.


---

## Prerequisites

- Python installed  
- `uv` installed  
- Visual Studio Code (recommended)
- Git installed

---

## How to Run (From a Clean Setup)

### Step 1 — Open VS Code

- Open Visual Studio Code  
- Open a terminal:  
  **Terminal → New Terminal**

---

### Step 2 — Clone the repository (dev branch)

Run the following in the VS Code terminal:

```bash
cd $HOME/Desktop
git clone -b dev https://github.com/mcmaster-hipel/research-platform.git
cd research-platform
```

---

### Step 3 — Install dependencies

Run the following:

```bash
uv sync
```

---

### Step 4 — Run the platform

Run the following:

```bash
.\run.ps1
```

---

## What the script does

- Initializes the environment
- Creates required working directories
- Launches the application

---

## Notes

- All commands must be run from inside the `research-platform` folder
- No manual setup of URBANopt or Ruby is required
- The platform has been tested from a clean clone without manual configuration

