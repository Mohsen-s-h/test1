$env:PYTHONPATH="src"
uv run python -m col.ui.app_main