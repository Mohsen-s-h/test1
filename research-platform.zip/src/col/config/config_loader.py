"""
MODULE: Application Configuration Loader
FILE: config_loader.py
LOCATION:
src/col/config/config_loader.py
PURPOSE
-------
This module provides a centralized configuration system for the Energy Systems Research Framework.

It loads configuration from a YAML file (config.yaml) and converts it into a
structured, immutable Python object used across all platform components.

The configuration defines:
- workspace directories
- project storage locations
- integration paths (URBANopt, PyPSA)
- data/cache/export locations
- platform-level constants

RESPONSIBILITIES
----------------
1. Locate repository root directory
2. Load configuration from config.yaml (if available)
3. Apply default values where configuration is missing
4. Convert all paths into pathlib.Path objects
5. Resolve relative paths against appropriate base directories
6. Cache configuration object for reuse (singleton behavior)
7. Ensure required directories exist on disk

EXECUTION FLOW
--------------
Typical workflow:

1. load_app_config() is called by any module requiring configuration
2. Repository root is determined dynamically
3. config.yaml is loaded (if present)
4. Configuration sections are parsed:
   - paths
   - data
   - integrations (urbanopt, pypsa)
5. Paths are resolved and converted to Path objects
6. AppConfig dataclass instance is created and cached
7. Required directories are created automatically
8. Cached configuration is returned for subsequent calls

TYPICAL CALLER
--------------
- URBANopt modules
- DER optimization core
- Load forecasting core
- UI and orchestration layers

IMPORTANT NOTES
---------------
- Configuration is loaded once and cached globally (_CACHE)
- All paths are normalized using pathlib
- Relative paths are resolved against workspace or repo root
- Missing config.yaml is handled gracefully with defaults
- Required directories are auto-created at runtime
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import yaml

# ---------------------------------------------------------------------
# Helper: determine repository root
# ---------------------------------------------------------------------
# Assumes file structure:
#   src/col/config/config_loader.py
# Therefore:
#   parents[3] → repository root
# ---------------------------------------------------------------------


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


# ---------------------------------------------------------------------
# Helper: normalize path (absolute or relative)
# ---------------------------------------------------------------------
# Converts:
# - absolute paths → unchanged
# - relative paths → resolved against base directory
# ---------------------------------------------------------------------


def _as_path(value: str | Path, *, base: Path) -> Path:
    p = Path(value)
    return p if p.is_absolute() else (base / p)


# ---------------------------------------------------------------------
# Demo project bootstrap
# ---------------------------------------------------------------------

DEMO_PROJECT_NAME = "Seaton_Mulberry_project_20260311_162026"
DEMO_PROJECTS_DIRNAME = "sample_projects"


def get_demo_project_source(repo_root: Path) -> Path:
    """
    Return the demo project location stored inside the repository.
    """
    return repo_root / DEMO_PROJECTS_DIRNAME / DEMO_PROJECT_NAME


def get_demo_project_destination(cfg: "AppConfig") -> Path:
    """
    Return the destination path inside the runtime workspace.
    """
    return cfg.projects_root / DEMO_PROJECT_NAME


def ensure_demo_project_available(
    cfg: "AppConfig", repo_root: Path | None = None
) -> Path | None:
    """
    Ensure the demo project exists under the configured workspace projects root.

    Behavior:
    - Copy the demo project from the repository into the workspace if missing
    - Never overwrite an existing workspace project
    - Return the workspace path if available, otherwise None
    """
    repo_root = repo_root or _repo_root()

    source = get_demo_project_source(repo_root)
    destination = get_demo_project_destination(cfg)

    if not source.exists():
        return None

    if not destination.exists():
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(source, destination)

    return destination


# ---------------------------------------------------------------------
# Main configuration container
# ---------------------------------------------------------------------
# Immutable dataclass representing full platform configuration.
#
# Contains:
# - workspace directories
# - integration paths
# - naming conventions
# - secrets
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class AppConfig:
    workspace_root: Path
    projects_root: Path
    sessions_root: Path
    drawings_root: Path
    logs_root: Path
    templates_root: Path
    cache_root: Path
    exports_root: Path

    # Directory naming conventions
    site_design_dirname: str
    load_forecasting_dirname: str
    der_optimization_dirname: str
    results_dirname: str
    project_logs_dirname: str

    # URBANopt integration paths
    urbanopt_projects_root: Path
    urbanopt_run_root: Path
    urbanopt_env_script: Path

    # PyPSA integration paths
    pypsa_run_root: Path

    # Platform secret (e.g., storage, tokens)
    storage_secret: str


# ---------------------------------------------------------------------
# Global cache (singleton pattern)
# ---------------------------------------------------------------------

_CACHE: AppConfig | None = None


# ---------------------------------------------------------------------
# Public API: load application configuration
# ---------------------------------------------------------------------
# This is the main entry point used across the platform.
#
# Behavior:
# - Loads config.yaml if present
# - Applies defaults otherwise
# - Creates required directories
# - Caches result for reuse
# ---------------------------------------------------------------------


def load_app_config() -> AppConfig:
    global _CACHE

    # Return cached config if already loaded
    if _CACHE is not None:
        return _CACHE

    # Determine repository root
    repo = _repo_root()

    # Locate config file
    cfg_file = repo / "config.yaml"

    # Load raw YAML content
    raw: dict[str, Any] = {}
    if cfg_file.exists():
        parsed = yaml.safe_load(cfg_file.read_text(encoding="utf-8")) or {}
        if isinstance(parsed, dict):
            raw = parsed

    # -----------------------------------------------------------------
    # Workspace root (base directory for all operations)
    # -----------------------------------------------------------------

    workspace_root = _as_path(raw.get("workspace_root", r"C:\COL"), base=repo)

    # -----------------------------------------------------------------
    # Parse configuration sections
    # -----------------------------------------------------------------

    paths = raw.get("paths", {}) if isinstance(raw.get("paths"), dict) else {}
    data = raw.get("data", {}) if isinstance(raw.get("data"), dict) else {}
    integrations = (
        raw.get("integrations", {}) if isinstance(raw.get("integrations"), dict) else {}
    )

    urbanopt = (
        integrations.get("urbanopt", {})
        if isinstance(integrations.get("urbanopt"), dict)
        else {}
    )
    pypsa = (
        integrations.get("pypsa", {})
        if isinstance(integrations.get("pypsa"), dict)
        else {}
    )

    # -----------------------------------------------------------------
    # Relative path defaults
    # -----------------------------------------------------------------

    projects_rel = paths.get("projects", "projects")
    sessions_rel = paths.get("sessions", "sessions")
    drawings_rel = paths.get("drawings", "drawings")
    logs_rel = paths.get("logs", "logs")
    templates_rel = paths.get("templates", "templates")

    cache_rel = data.get("cache", "cache")
    exports_rel = data.get("exports", "exports")

    # -----------------------------------------------------------------
    # Integration paths (URBANopt / PyPSA)
    # -----------------------------------------------------------------

    urbanopt_projects_root = _as_path(
        urbanopt.get("projects_root", r"C:\URBANoptProjects"), base=workspace_root
    )

    urbanopt_run_root = _as_path(
        urbanopt.get("run_dir", "urbanopt_runs"), base=workspace_root
    )

    pypsa_run_root = _as_path(pypsa.get("run_dir", "pypsa_runs"), base=workspace_root)

    urbanopt_env_script = _as_path(
        urbanopt.get("env_script", "uo_env.ps1"), base=urbanopt_projects_root
    )

    # -----------------------------------------------------------------
    # Build final configuration object
    # -----------------------------------------------------------------

    _CACHE = AppConfig(
        workspace_root=workspace_root,
        projects_root=_as_path(projects_rel, base=workspace_root),
        sessions_root=_as_path(sessions_rel, base=workspace_root),
        drawings_root=_as_path(drawings_rel, base=workspace_root),
        logs_root=_as_path(logs_rel, base=workspace_root),
        templates_root=_as_path(templates_rel, base=workspace_root),
        cache_root=_as_path(cache_rel, base=workspace_root),
        exports_root=_as_path(exports_rel, base=workspace_root),
        site_design_dirname=str(paths.get("site_design", "site_design")),
        load_forecasting_dirname=str(paths.get("load_forecasting", "load_forecasting")),
        der_optimization_dirname=str(paths.get("der_optimization", "der_optimization")),
        results_dirname=str(paths.get("results", "results")),
        project_logs_dirname=str(paths.get("logs", "logs")),
        urbanopt_projects_root=urbanopt_projects_root,
        urbanopt_run_root=urbanopt_run_root,
        urbanopt_env_script=urbanopt_env_script,
        pypsa_run_root=pypsa_run_root,
        storage_secret=str(raw.get("storage_secret", "col-platform-dev-secret")),
    )

    # -----------------------------------------------------------------
    # Ensure required directories exist
    # ---------------------------------------------------------------------

    for p in (
        _CACHE.workspace_root,
        _CACHE.projects_root,
        _CACHE.sessions_root,
        _CACHE.drawings_root,
        _CACHE.logs_root,
        _CACHE.templates_root,
        _CACHE.cache_root,
        _CACHE.exports_root,
        _CACHE.urbanopt_run_root,
        _CACHE.pypsa_run_root,
    ):
        p.mkdir(parents=True, exist_ok=True)

    # -----------------------------------------------------------------
    # Ensure demo project is installed in workspace (if bundled in repo)
    # -----------------------------------------------------------------

    ensure_demo_project_available(_CACHE, repo)

    return _CACHE
