# orchestration

Platform workflow controller.
Coordinates execution across scenario, demand, techno-economic, and optimization modules.
