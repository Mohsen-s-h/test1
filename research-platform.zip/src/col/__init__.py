"""
src/col/__init__.py

Core package for the COL platform.

This package represents the main application namespace and contains
all major layers of the system, including the user interface,
platform modules, technical cores, and shared utilities. It provides
the structural organization for building, running, and extending
the COL platform.

Typical Usage:
- Import and access main components of the COL platform
- Serve as the root namespace for all application modules
"""
