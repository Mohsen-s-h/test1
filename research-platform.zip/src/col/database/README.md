# database

Parameter library and database layer.
Includes:
- technology parameters
- cost and tariff data
- material and ESG factors
