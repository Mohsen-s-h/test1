"""
MODULE: Project Workspace Orchestrator
FILE: project_workspace_orchestrator.py
LOCATION:
src/col/platform/orchestration/project_orchestrator.py

PURPOSE
-------
This module manages the lifecycle of project workspaces within the Energy Systems Research Framework.

It provides a centralized mechanism for:
- creating project directories
- organizing platform folder structure
- storing and retrieving project metadata
- maintaining consistency across all platform cores

All projects are stored under a unified workspace root:

    /COL/projects/<client_name>/<project_id>/

ARCHITECTURAL ROLE
------------------
This module is part of the orchestration layer and follows:

    UI → Orchestrator → Core

It ensures:
- UI does not directly manipulate filesystem structure
- workspace structure remains consistent across modules
- metadata is standardized and persistently stored

RESPONSIBILITIES
----------------
1. Ensure platform workspace root and required directories exist
2. Create new project workspaces with standardized structure
3. Generate unique project identifiers
4. Persist project metadata (project.json)
5. Load project metadata from disk
6. List existing projects across the workspace
7. Update project metadata safely

EXECUTION FLOW
--------------
Typical workflow:

1. UI requests project creation
2. create_project_workspace(...) is called
3. Workspace directory structure is created
4. project.json metadata file is written
5. ProjectMeta object is returned

For existing projects:
1. list_existing_projects() scans workspace
2. project.json files are loaded
3. ProjectMeta objects are returned to UI

TYPICAL CALLER
--------------
- Project setup UI
- Platform initialization workflows
- Site design / load forecasting / DER cores

WORKSPACE STRUCTURE
-------------------
/COL/
    ├── projects/
    │     └── <client>/
    │           └── <project_id>/
    │                 ├── site_design/
    │                 ├── load_forecasting/
    │                 ├── der_optimization/
    │                 ├── results/
    │                 └── logs/
    ├── logs/
    ├── templates/
    └── cache/

IMPORTANT NOTES
---------------
- Project IDs are timestamp-based to ensure uniqueness
- All metadata is stored in project.json
- Directory names are configurable via AppConfig
- Slug function ensures filesystem-safe naming
- Module is intentionally free of UI or solver logic
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------
# Internal configuration
# ---------------------------------------------------------------------

from col.config.config_loader import load_app_config

# ---------------------------------------------------------------------
# Load global configuration paths
# ---------------------------------------------------------------------

_cfg = load_app_config()

COL_ROOT = _cfg.workspace_root
COL_PROJECTS_ROOT = _cfg.projects_root
COL_LOGS_ROOT = _cfg.logs_root
COL_TEMPLATES_ROOT = _cfg.templates_root
COL_CACHE_ROOT = _cfg.cache_root


# ---------------------------------------------------------------------
# Ensure platform workspace structure exists
# ---------------------------------------------------------------------
# Creates root directories if missing.
# ---------------------------------------------------------------------


def ensure_platform_workspace_root() -> None:
    """Ensure workspace root and standard subdirectories exist."""
    for p in (
        COL_ROOT,
        COL_PROJECTS_ROOT,
        COL_LOGS_ROOT,
        COL_TEMPLATES_ROOT,
        COL_CACHE_ROOT,
    ):
        p.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------
# Helper: slugify string for safe folder naming
# ---------------------------------------------------------------------
# Converts arbitrary string into filesystem-safe identifier.
# ---------------------------------------------------------------------


def _slug(s: str, *, default: str = "project") -> str:
    s = (s or "").strip()

    if not s:
        return default

    s = s.lower()
    s = re.sub(r"[^a-z0-9]+", "_", s).strip("_")

    return s or default


# ---------------------------------------------------------------------
# Helper: generate timestamp
# ---------------------------------------------------------------------
# Returns:
# - short timestamp for IDs
# - ISO timestamp for metadata
# ---------------------------------------------------------------------


def _now_ts() -> tuple[str, str]:
    dt = datetime.now()
    return dt.strftime("%Y%m%d_%H%M%S"), dt.isoformat(timespec="seconds")


# ---------------------------------------------------------------------
# Data container: project metadata
# ---------------------------------------------------------------------
# Represents project information stored in project.json
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class ProjectMeta:
    client_name: str
    project_name: str
    project_id: str
    workspace_path: str
    created_at: str
    project_type: str
    address: str = ""
    latitude: float | None = None
    longitude: float | None = None

    def to_dict(self) -> dict[str, Any]:
        """
        Convert metadata to dictionary for JSON serialization.
        """
        d: dict[str, Any] = {
            "client_name": self.client_name,
            "project_name": self.project_name,
            "project_id": self.project_id,
            "workspace_path": self.workspace_path,
            "created_at": self.created_at,
            "project_type": self.project_type,
        }

        if self.address:
            d["address"] = self.address

        if self.latitude is not None:
            d["latitude"] = self.latitude

        if self.longitude is not None:
            d["longitude"] = self.longitude

        return d


# ---------------------------------------------------------------------
# Create new project workspace
# ---------------------------------------------------------------------
# Initializes directory structure and metadata.
# ---------------------------------------------------------------------


def create_project_workspace(
    *,
    client_name: str,
    project_name: str,
    project_type: str,
    address: str = "",
    latitude: float | None = None,
    longitude: float | None = None,
) -> ProjectMeta:
    """
    Create a new project workspace under COL/projects.
    """

    ensure_platform_workspace_root()

    client = _slug(client_name, default="client")
    pname_slug = _slug(project_name, default="project")

    ts, created_at = _now_ts()

    project_id = f"{pname_slug}_{ts}"
    ws = COL_PROJECTS_ROOT / client / project_id

    # -----------------------------------------------------------------
    # Create core workspace directories
    # -----------------------------------------------------------------

    for sub in (
        _cfg.site_design_dirname,
        _cfg.load_forecasting_dirname,
        _cfg.der_optimization_dirname,
        _cfg.results_dirname,
        _cfg.project_logs_dirname,
    ):
        (ws / sub).mkdir(parents=True, exist_ok=True)

    # -----------------------------------------------------------------
    # Build metadata object
    # -----------------------------------------------------------------

    meta = ProjectMeta(
        client_name=str(client_name).strip(),
        project_name=str(project_name).strip(),
        project_id=project_id,
        workspace_path=str(ws),
        created_at=created_at,
        project_type=_slug(project_type, default="project"),
        address=(address or "").strip(),
        latitude=latitude,
        longitude=longitude,
    )

    # -----------------------------------------------------------------
    # Save metadata to project.json
    # -----------------------------------------------------------------

    (ws / "project.json").write_text(
        json.dumps(meta.to_dict(), indent=2), encoding="utf-8"
    )

    return meta


# ---------------------------------------------------------------------
# Load project metadata from file
# ---------------------------------------------------------------------


def _read_project_json(path: Path) -> ProjectMeta:
    raw = json.loads(path.read_text(encoding="utf-8"))

    return ProjectMeta(
        client_name=str(raw.get("client_name") or "").strip(),
        project_name=str(raw.get("project_name") or "").strip(),
        project_id=str(raw.get("project_id") or "").strip(),
        workspace_path=str(raw.get("workspace_path") or "").strip(),
        created_at=str(raw.get("created_at") or "").strip(),
        project_type=str(raw.get("project_type") or "").strip(),
        address=str(raw.get("address") or "").strip(),
        latitude=float(raw.get("latitude"))
        if raw.get("latitude") is not None
        else None,
        longitude=float(raw.get("longitude"))
        if raw.get("longitude") is not None
        else None,
    )


# ---------------------------------------------------------------------
# List all existing projects
# ---------------------------------------------------------------------
# Scans workspace recursively for project.json files.
# ---------------------------------------------------------------------


def list_existing_projects() -> list[ProjectMeta]:
    """
    Return list of all existing projects in workspace.
    """

    ensure_platform_workspace_root()

    metas: list[ProjectMeta] = []

    try:
        for pj in COL_PROJECTS_ROOT.rglob("project.json"):
            try:
                metas.append(_read_project_json(pj))
            except Exception:
                continue
    except Exception:
        return []

    # Sort newest first
    metas.sort(key=lambda m: m.created_at or "", reverse=True)

    return metas


# ---------------------------------------------------------------------
# Load project by workspace path
# ---------------------------------------------------------------------


def load_project_by_workspace(workspace_path: str) -> ProjectMeta:
    """
    Load project metadata from workspace directory.
    """

    ws = Path(workspace_path)
    pj = ws / "project.json"

    if not pj.exists():
        raise FileNotFoundError(f"project.json not found: {pj}")

    return _read_project_json(pj)


# ---------------------------------------------------------------------
# Update project metadata
# ---------------------------------------------------------------------
# Allows partial updates (only provided fields are changed).
# ---------------------------------------------------------------------


def update_project_metadata(
    workspace_path: str,
    *,
    address: str | None = None,
    latitude: float | None = None,
    longitude: float | None = None,
) -> ProjectMeta:
    ws = Path(workspace_path)
    pj = ws / "project.json"

    if not pj.exists():
        raise FileNotFoundError(f"project.json not found: {pj}")

    meta = _read_project_json(pj)

    updated = ProjectMeta(
        client_name=meta.client_name,
        project_name=meta.project_name,
        project_id=meta.project_id,
        workspace_path=meta.workspace_path,
        created_at=meta.created_at,
        project_type=meta.project_type,
        address=meta.address if address is None else address,
        latitude=meta.latitude if latitude is None else latitude,
        longitude=meta.longitude if longitude is None else longitude,
    )

    pj.write_text(json.dumps(updated.to_dict(), indent=2), encoding="utf-8")

    return updated
