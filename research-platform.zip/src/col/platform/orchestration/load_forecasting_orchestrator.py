"""
MODULE: Load Forecasting Orchestrator (URBANopt Integration)
FILE: load_forecasting_orchestrator.py
LOCATION:
src/col/platform/orchestration/load_forecasting_orchestrator.py

PURPOSE
-------
This module orchestrates the complete load forecasting workflow using
URBANopt simulations within the Energy Systems Research Framework.

It acts as the integration layer between:
- COL UI / orchestration layer
- URBANopt simulation engine
- Load data extraction pipeline

ARCHITECTURAL ROLE
------------------
This module enforces the design pattern:

    UI → Orchestrator → URBANopt Core → Outputs → Aggregation → UI

It ensures that:
- UI does not directly interact with URBANopt execution
- All preprocessing, execution, and postprocessing are centralized
- Output is returned in a UI-friendly structure

RESPONSIBILITIES
----------------
1. Load shared_state from run directory
2. Download weather data based on project location
3. Generate GeoJSON input for URBANopt
4. Validate and fix GeoJSON schema issues
5. Initialize URBANopt execution workspace
6. Verify URBANopt CLI availability
7. Execute URBANopt simulation
8. Wait for simulation outputs to be generated
9. Read and aggregate building load profiles
10. Move results into COL workspace
11. Return structured output for UI consumption

EXECUTION FLOW
--------------
1. Load configuration (URBANopt + app config)
2. Load shared_state.json from run directory
3. Download EPW weather data
4. Update shared_state with weather metadata
5. Generate GeoJSON input file
6. Fix GeoJSON template issues (if needed)
7. Verify URBANopt CLI environment
8. Create URBANopt project and run simulation
9. Wait for OpenStudio outputs (CSV reports)
10. Read feature-level load data
11. Aggregate loads across features
12. Move URBANopt project into workspace
13. Return results to UI

TYPICAL CALLER
--------------
- Load forecasting UI tab
- Platform orchestration pipelines

OUTPUT CONTRACT
---------------
Returns dictionary containing:

• project_path
• scenario_csv
• scenario_stem
• full_log_path
• series:
    - per_feature (DataFrame)
    - total (Series)

IMPORTANT NOTES
---------------
- Includes polling mechanism to wait for URBANopt outputs
- Handles GeoJSON schema correction automatically
- Weather data is dynamically downloaded per project
- Execution is isolated in a temporary workspace
- Results are moved into COL workspace after completion
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import json
import os
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import pandas as pd

# ---------------------------------------------------------------------
# Internal imports
# ---------------------------------------------------------------------

from col.config.config_loader import load_app_config
from col.platform.cores.load_forecasting.geojson.input_file_gen import generate_geojson
from col.platform.cores.load_forecasting.urbanopt.config import load_urbanopt_config
from col.platform.cores.load_forecasting.urbanopt.runner import (
    UrbanOptConfig,
    create_and_run_urbanopt,
)
from col.platform.weather.weather_download import download_climate_file

# ---------------------------------------------------------------------
# Data container for URBANopt outputs
# ---------------------------------------------------------------------
# Holds both:
# - per-feature load profiles
# - aggregated total load
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class UrbanOptOutputs:
    per_feature: pd.DataFrame  # columns = feature IDs
    total: pd.Series  # aggregated load


# ---------------------------------------------------------------------
# Helper: wait for URBANopt outputs
# ---------------------------------------------------------------------
# Polls until default_feature_reports.csv files are available.
#
# Handles:
# - simulation still running
# - finished jobs without outputs (error case)
# - timeout protection
# ---------------------------------------------------------------------


def _find_default_feature_reports(
    project_path: Path,
    scenario_stem: str,
    expected_features: int,
    timeout_s: int = 60 * 60,
    poll_s: float = 2.0,
) -> list[Path]:
    base = project_path / "run" / scenario_stem

    if not base.exists():
        raise FileNotFoundError(f"Run folder not found: {base}")

    start = time.time()

    while True:
        csvs = sorted(base.rglob("default_feature_reports.csv"))

        # Success condition
        if len(csvs) >= expected_features:
            return csvs

        # Detect failed runs
        finished_jobs = list(base.glob("*/finished.job"))

        if len(finished_jobs) >= expected_features and len(csvs) == 0:
            raise FileNotFoundError(f"Runs finished but no outputs found under: {base}")

        # Timeout protection
        if time.time() - start > timeout_s:
            raise TimeoutError(f"Timeout waiting for outputs under: {base}")

        time.sleep(poll_s)


# ---------------------------------------------------------------------
# Read facility load data
# ---------------------------------------------------------------------
# Extracts electricity demand from each feature CSV
# and aggregates into:
# - per_feature DataFrame
# - total Series
# ---------------------------------------------------------------------


def read_facility_loads_kw(
    project_path: Path,
    scenario_stem: str,
    expected_features: int,
    load_col: str = "Electricity:Facility Power(kW)",
) -> UrbanOptOutputs:
    csvs = _find_default_feature_reports(
        project_path,
        scenario_stem,
        expected_features=expected_features,
    )

    series_list: list[pd.Series] = []

    for csv_path in csvs:
        df = pd.read_csv(csv_path)

        if "Datetime" not in df.columns:
            raise ValueError(f"'Datetime' missing in {csv_path}")

        if load_col not in df.columns:
            raise ValueError(f"'{load_col}' missing in {csv_path}")

        dt_index = pd.to_datetime(df["Datetime"])

        # Extract feature ID from directory structure
        feature_id = csv_path.parent.parent.name

        s = pd.Series(df[load_col].to_numpy(), index=dt_index, name=str(feature_id))
        series_list.append(s)

    # Combine features
    per_feature = pd.concat(series_list, axis=1).sort_index()

    # Aggregate load
    total = per_feature.sum(axis=1)
    total.name = "total_load_kw"

    # Attempt numeric column ordering
    try:
        per_feature = per_feature.reindex(
            sorted(per_feature.columns, key=lambda x: int(str(x))),
            axis=1,
        )
    except Exception:
        pass

    return UrbanOptOutputs(per_feature=per_feature, total=total)


# ---------------------------------------------------------------------
# MAIN ORCHESTRATION FUNCTION
# ---------------------------------------------------------------------


def run_load_forecasting_and_collect(
    project_prefix: str,
    run_dir: Path,
    status_cb: Callable[[float, str], None],
    detail_cb: Callable[[str], None],
) -> dict[str, Any]:
    """
    Execute full load forecasting workflow and return results.

    This function coordinates:
    - weather download
    - GeoJSON generation
    - URBANopt execution
    - output extraction
    """

    # -----------------------------------------------------------------
    # Load configuration
    # -----------------------------------------------------------------

    base_cfg = load_urbanopt_config()
    app_cfg = load_app_config()

    # Create isolated URBANopt execution workspace
    run_id = run_dir.name
    uo_exec_dir = app_cfg.urbanopt_run_root / run_id
    uo_exec_dir.mkdir(parents=True, exist_ok=True)

    projects_root = uo_exec_dir
    uo_env_ps1 = base_cfg.projects_root / "uo_env.ps1"

    # Validate environment paths
    if not projects_root.exists():
        raise FileNotFoundError(f"projects_root not found: {projects_root}")

    if not uo_env_ps1.exists():
        raise FileNotFoundError(f"uo_env.ps1 not found: {uo_env_ps1}")

    cfg = UrbanOptConfig(projects_root=projects_root, uo_env_ps1=uo_env_ps1)

    # -----------------------------------------------------------------
    # Step 0 — Load shared state + weather
    # -----------------------------------------------------------------

    shared_state_file = run_dir / "shared_state.json"

    if not shared_state_file.exists():
        raise FileNotFoundError("shared_state.json missing")

    with open(shared_state_file, "r") as f:
        shared_state = json.load(f)

    lat = shared_state["lat"]
    lon = shared_state["lon"]

    status_cb(0.02, "Downloading weather data...")

    weather_folder = run_dir / "weather"
    weather_folder.mkdir(parents=True, exist_ok=True)

    epw_path, ddy_path, stat_path, zip_path = download_climate_file(
        lat, lon, weather_folder
    )

    detail_cb(f"Weather EPW: {epw_path}")

    # Update shared_state
    shared_state["weather_filename"] = os.path.basename(epw_path)
    shared_state["epw_path"] = str(epw_path)
    shared_state["ddy_path"] = str(ddy_path) if ddy_path else ""
    shared_state["stat_path"] = str(stat_path) if stat_path else ""

    with open(shared_state_file, "w") as f:
        json.dump(shared_state, f, indent=2)

    # -----------------------------------------------------------------
    # Step 0.5 — Generate GeoJSON
    # -----------------------------------------------------------------

    status_cb(0.04, "Generating GeoJSON...")

    geojson_path = generate_geojson(shared_state, run_dir)

    detail_cb(f"GeoJSON created: {geojson_path}")

    # -----------------------------------------------------------------
    # Auto-fix GeoJSON template (URBANopt schema requirement)
    # -----------------------------------------------------------------

    with open(geojson_path, "r", encoding="utf-8") as f:
        geo = json.load(f)

    valid_template = "Residential IECC 2018 - Customizable Template Apr 2022"
    modified = False

    for feature in geo.get("features", []):
        props = feature.get("properties", {})

        if props.get("type") == "Building":
            template = props.get("template")

            if template == "ResidentialTemplate" or template is None:
                props["template"] = valid_template
                modified = True

    if modified:
        with open(geojson_path, "w", encoding="utf-8") as f:
            json.dump(geo, f, indent=2)

        detail_cb("GeoJSON template auto-corrected")

    # -----------------------------------------------------------------
    # Step 1 — Verify URBANopt CLI
    # -----------------------------------------------------------------

    status_cb(0.05, "Checking URBANopt...")

    cmd = f'. "{cfg.uo_env_ps1}"; uo --help'

    result = subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    if result.returncode != 0:
        raise RuntimeError("URBANopt CLI not accessible")

    detail_cb("URBANopt CLI OK")

    # -----------------------------------------------------------------
    # Step 2 — Execute URBANopt
    # -----------------------------------------------------------------

    status_cb(0.15, "Running URBANopt...")

    workspace_project_path = run_dir.parents[3]

    run_result = create_and_run_urbanopt(
        cfg=cfg,
        project_prefix=project_prefix,
        workspace_project_path=workspace_project_path,
    )

    # -----------------------------------------------------------------
    # Step 3 — Read outputs
    # -----------------------------------------------------------------

    status_cb(0.85, "Reading reports...")

    run_base = run_result.project_path / "run" / run_result.scenario_stem

    expected_features = len([d for d in run_base.iterdir() if d.is_dir()])

    outputs = read_facility_loads_kw(
        project_path=run_result.project_path,
        scenario_stem=run_result.scenario_stem,
        expected_features=expected_features,
    )

    # -----------------------------------------------------------------
    # Step 4 — Finalize results
    # -----------------------------------------------------------------

    status_cb(0.95, "Preparing results...")

    uo_project_exec_path = run_result.project_path
    uo_project_name = uo_project_exec_path.name

    workspace_project_path = run_dir / uo_project_name

    if not workspace_project_path.exists():
        shutil.move(uo_project_exec_path, workspace_project_path)

    return {
        "project_path": str(workspace_project_path),
        "scenario_csv": run_result.scenario_csv,
        "scenario_stem": run_result.scenario_stem,
        "full_log_path": str(run_result.full_log_path),
        "series": {
            "per_feature": outputs.per_feature,
            "total": outputs.total,
        },
    }
