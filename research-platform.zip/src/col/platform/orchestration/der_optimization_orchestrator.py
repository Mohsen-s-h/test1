"""
MODULE: DER Optimization Orchestrator
FILE: der_optimization_orchestrator.py
LOCATION:
src/col/platform/orchestration/der_optimization_orchestrator.py

PURPOSE
-------
This module provides the orchestration boundary between the UI layer
and the DER optimization core.

It ensures that the user interface does not call core optimization
engines directly. Instead, the UI interacts with this orchestrator,
which delegates execution to the underlying DER optimization runner
and returns a UI-friendly result contract.

ARCHITECTURAL ROLE
------------------
This module enforces the platform design rule:

    UI → Orchestrator → Core

This separation improves:
- modularity
- maintainability
- testability
- future extensibility

RESPONSIBILITIES
----------------
1. Receive DER optimization requests from the UI layer
2. Delegate execution to the PyPSA core runner
3. Preserve compatibility with existing UI call signatures
4. Detect exported output files after optimization
5. Return a stable result contract for the UI
6. Avoid direct solver logic in the orchestration layer

EXECUTION FLOW
--------------
Typical workflow:

1. UI calls `run_der_optimization(...)`
2. Orchestrator lazily imports the core runner
3. Request parameters are forwarded to the core
4. Core executes DER optimization
5. Orchestrator scans export directory for generated CSV files
6. Export paths are attached only if files are present
7. A stable result dictionary is returned to the UI

TYPICAL CALLER
--------------
- DER optimization UI tab
- Higher-level application workflow controller

IMPORTANT NOTES
---------------
- This module intentionally contains no solver logic
- Core imports are lazy to reduce startup coupling
- Export paths are discovered after execution rather than enforced
- UI-safe return behavior is maintained even when exports are missing
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from pathlib import Path
from typing import Any, Callable

# ---------------------------------------------------------------------
# Helper: locate most recent exported file
# ---------------------------------------------------------------------
# Searches recursively because export files may be written inside
# nested folders depending on run structure.
#
# Returns:
# - string path if found
# - None if not found or any error occurs
#
# A string is returned instead of Path to keep the result contract
# easily serializable for UI and API layers.
# ---------------------------------------------------------------------


def _find_latest_under(root: Path, pattern: str) -> str | None:
    """
    Return the most recently modified file matching a pattern under root.

    Parameters
    ----------
    root : Path
        Root directory to search recursively.

    pattern : str
        Filename pattern passed to Path.rglob().

    Returns
    -------
    str | None
        Most recent matching file path as string, or None if not found.
    """

    try:
        root = Path(root)

        if not root.exists():
            return None

        matches = [p for p in root.rglob(pattern) if p.is_file()]
        if not matches:
            return None

        # Select most recently modified file
        matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        return str(matches[0])

    except Exception:
        # Intentionally silent to preserve orchestrator stability
        return None


# ---------------------------------------------------------------------
# Main orchestration entry point
# ---------------------------------------------------------------------
# This function acts as a thin wrapper around the DER optimization core.
#
# Design goals:
# - preserve current UI signature
# - keep UI decoupled from the core implementation
# - attach export metadata only when outputs actually exist
# ---------------------------------------------------------------------


def run_der_optimization(
    *,
    project_path: Path,
    scenario_stem: str,
    der_case_name: str,
    battery_hours: float,
    grid_import_limit_kw: float | None,
    costs: Any,
    cb_status: Callable[[float, str], None] | None,
    cb_detail: Callable[[str], None] | None,
    export_dir: Path,
    outage_start_hour: int,
    outage_hours_per_day: int,
    outage_start_date: Any,
    return_timeseries: bool,
) -> dict[str, Any]:
    """
    Orchestrate a DER optimization run.

    This function delegates execution to the existing PyPSA core runner:

        col.platform.cores.der_optimization.pypsa.runner_option.run_der_optimization_option

    The orchestrator exists so the UI does not depend directly on
    core optimization engines.

    Parameters
    ----------
    project_path : Path
        Root project directory associated with the run.

    scenario_stem : str
        Scenario identifier used by the core.

    der_case_name : str
        DER case selection name from UI.

    battery_hours : float
        Battery storage duration in hours.

    grid_import_limit_kw : float | None
        Optional grid import power limit.

    costs : Any
        Cost structure forwarded directly to the core.

    cb_status : Callable[[float, str], None] | None
        Optional progress callback for high-level status updates.

    cb_detail : Callable[[str], None] | None
        Optional callback for detailed progress messages.

    export_dir : Path
        Output directory where exported CSV files may be written.

    outage_start_hour : int
        Weak-grid outage start hour.

    outage_hours_per_day : int
        Daily outage duration in hours.

    outage_start_date : Any
        Optional outage start date forwarded to the core.

    return_timeseries : bool
        Whether time-series metadata should be returned.

    Returns
    -------
    dict[str, Any]
        Result contract containing core outputs and optional export info.
    """

    # -----------------------------------------------------------------
    # Lazy import of core runner
    # -----------------------------------------------------------------
    # This avoids coupling application startup to heavy numerical /
    # solver-related dependencies until execution is actually requested.
    # -----------------------------------------------------------------

    from col.platform.cores.der_optimization.pypsa.runner_option import (
        run_der_optimization_option,
    )

    # -----------------------------------------------------------------
    # Delegate execution to core
    # -----------------------------------------------------------------

    core_result = run_der_optimization_option(
        project_path=project_path,
        scenario_stem=scenario_stem,
        der_case_name=der_case_name,
        battery_hours=battery_hours,
        grid_import_limit_kw=grid_import_limit_kw,
        costs=costs,
        cb_status=cb_status,
        cb_detail=cb_detail,
        export_dir=export_dir,
        outage_start_hour=outage_start_hour,
        outage_hours_per_day=outage_hours_per_day,
        outage_start_date=outage_start_date,
        plot_start=None,
        plot_days=None,
        return_timeseries=return_timeseries,
    )

    # -----------------------------------------------------------------
    # Detect exported output files
    # -----------------------------------------------------------------
    # Important design choice:
    # The orchestrator does not modify core behavior.
    # It only inspects whether expected output files were produced and,
    # if so, attaches an export contract for the UI.
    #
    # This prevents the UI from attempting plots or file reads when
    # export CSVs are absent.
    # -----------------------------------------------------------------

    out_dir = Path(export_dir)

    export_dict = {
        "out_dir": str(out_dir),
        "load_csv": _find_latest_under(out_dir, f"{der_case_name}_load_MW.csv"),
        "dispatch_generators_csv": _find_latest_under(
            out_dir, f"{der_case_name}_dispatch_generators_MW.csv"
        ),
        "dispatch_storage_csv": _find_latest_under(
            out_dir, f"{der_case_name}_dispatch_storage_MW.csv"
        ),
        "soc_csv": _find_latest_under(out_dir, f"{der_case_name}_battery_soc_MWh.csv"),
    }

    # Determine whether any export output is actually available
    has_any_export = any(v for k, v in export_dict.items() if k != "out_dir")

    if has_any_export:
        return {**core_result, "export": export_dict}

    # -----------------------------------------------------------------
    # Stable UI contract when no export files exist
    # -----------------------------------------------------------------
    # The "export" key is always present, but set to None when outputs
    # are missing. This avoids downstream UI ambiguity.
    # -----------------------------------------------------------------

    return {**core_result, "export": None}
