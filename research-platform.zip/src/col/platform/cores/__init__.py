"""
src/col/platform/cores/__init__.py

Technical core modules for the COL platform.

This package groups the main functional domains of the platform,
such as load forecasting, DER optimization, and other analytical
components. Each core represents a distinct technical capability
and provides domain-specific logic that can be used by orchestration
and UI layers.

Typical Usage:
- Access domain-specific core modules
- Integrate core functionalities into platform workflows
"""
