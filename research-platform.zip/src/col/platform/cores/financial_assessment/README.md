# Financial Assessment Core
