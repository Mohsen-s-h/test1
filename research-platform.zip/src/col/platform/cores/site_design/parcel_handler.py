"""
MODULE: Parcel Geometry Handler (Site Design Core)
FILE: parcel_handler.py
LOCATION:
src/col/platform/cores/site_design/parcel_handler.py

PURPOSE
-------
This module processes parcel geometry inputs (GeoJSON) and initializes
a new site-design project within the Energy Systems Research Framework..

It converts geographic parcel data into a structured project folder,
computes key geometric metrics (area), and stores both raw and derived
data for downstream site design workflows.

RESPONSIBILITIES
----------------
1. Receive parcel geometry in GeoJSON format
2. Extract geometry and compute parcel area
3. Perform coordinate transformation (WGS84 → projected CRS)
4. Create project directory structure
5. Store parcel geometry and metadata
6. Return project information for further processing

EXECUTION FLOW
--------------
Typical workflow:

1. Parcel GeoJSON is received from UI or API
2. Geometry is extracted from first feature
3. Coordinates are projected from EPSG:4326 to EPSG:32617
4. Parcel area is computed in square meters
5. A new project directory is created:
   <projects_root>/project_<timestamp>/
6. Parcel geometry is saved to:
   site/parcel.geojson
7. Metadata is generated and saved to:
   site/parcel_meta.json
8. Project path and computed metrics are returned

TYPICAL CALLER
--------------
- Site design UI
- Project initialization workflows
- Land feasibility modules

OUTPUT STRUCTURE
----------------
<COLProjects>/project_<timestamp>/
    └── site/
        ├── parcel.geojson
        └── parcel_meta.json

IMPORTANT NOTES
---------------
- Input geometry is assumed to be in WGS84 (EPSG:4326)
- Area computation uses UTM Zone 17N (EPSG:32617)
- Only the first feature in GeoJSON is processed
- Project naming is timestamp-based (UTC)
"""


# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from datetime import datetime
import json


# ---------------------------------------------------------------------
# Third-party imports (geospatial processing)
# ---------------------------------------------------------------------

from shapely.geometry import shape
from shapely.ops import transform
from pyproj import Transformer


# ---------------------------------------------------------------------
# Internal configuration
# ---------------------------------------------------------------------

from col.config.config_loader import load_app_config


# ---------------------------------------------------------------------
# Root directory for site design projects
# ---------------------------------------------------------------------
# Retrieved from global application configuration
# ---------------------------------------------------------------------

PROJECTS_ROOT = load_app_config().projects_root


# ---------------------------------------------------------------------
# Compute parcel area (m²)
# ---------------------------------------------------------------------
# Converts geographic coordinates (lat/lon) into projected CRS
# before computing area to ensure accuracy.
# ---------------------------------------------------------------------


def compute_area_m2(parcel_geojson: dict) -> float:
    """
    Compute parcel area from GeoJSON geometry.

    Parameters
    ----------
    parcel_geojson : dict
        GeoJSON FeatureCollection describing the parcel

    Returns
    -------
    float
        Parcel area in square meters
    """

    # Extract first geometry from FeatureCollection
    geom = shape(parcel_geojson["features"][0]["geometry"])

    # Define coordinate transformation:
    # WGS84 → UTM Zone 17N (Ontario region)
    transformer = Transformer.from_crs("EPSG:4326", "EPSG:32617", always_xy=True)

    # Apply projection to geometry
    geom_m = transform(transformer.transform, geom)

    # Compute area in projected coordinate system
    return geom_m.area


# ---------------------------------------------------------------------
# Create site project and store parcel data
# ---------------------------------------------------------------------
# Initializes project folder and saves:
# - geometry (GeoJSON)
# - metadata (area, CRS, timestamp)
# ---------------------------------------------------------------------


def save_parcel_project(parcel_geojson: dict) -> dict:
    """
    Create a new site-design project from parcel geometry.

    Parameters
    ----------
    parcel_geojson : dict
        GeoJSON FeatureCollection

    Returns
    -------
    dict
        Project metadata including path and computed area
    """

    # Generate unique project name using UTC timestamp
    ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    project_dir = PROJECTS_ROOT / f"project_{ts}"
    site_dir = project_dir / "site"

    # Ensure directory structure exists
    site_dir.mkdir(parents=True, exist_ok=True)

    # -----------------------------------------------------------------
    # Compute parcel area
    # -----------------------------------------------------------------

    area_m2 = compute_area_m2(parcel_geojson)

    # -----------------------------------------------------------------
    # Save parcel geometry
    # -----------------------------------------------------------------

    with open(site_dir / "parcel.geojson", "w") as f:
        json.dump(parcel_geojson, f, indent=2)

    # -----------------------------------------------------------------
    # Build metadata
    # -----------------------------------------------------------------

    meta = {
        "area_m2": round(area_m2, 2),
        "area_ha": round(area_m2 / 10_000, 4),
        "crs": "EPSG:32617",
        "created_utc": ts,
    }

    # -----------------------------------------------------------------
    # Save metadata file
    # -----------------------------------------------------------------

    with open(site_dir / "parcel_meta.json", "w") as f:
        json.dump(meta, f, indent=2)

    # -----------------------------------------------------------------
    # Return project summary
    # -----------------------------------------------------------------

    return {
        "project_path": str(project_dir),
        **meta,
    }
