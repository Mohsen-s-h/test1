"""
src/col/platform/cores/load_forecasting/__init__.py

Load forecasting core package for the COL platform.

This package provides core functionalities for load forecasting
within the platform. It serves as a container for different
forecasting implementations (e.g., URBANopt-based workflows)
and supports integration with orchestration and UI layers.

Typical Usage:
- Access load forecasting core modules
- Integrate forecasting workflows into platform pipelines
"""
