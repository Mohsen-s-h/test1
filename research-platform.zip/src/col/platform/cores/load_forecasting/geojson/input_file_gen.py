"""
MODULE: GeoJSON Input Generator for URBANopt
FILE: input_file_gen.py
LOCATION:
src/col/platform/cores/load_forecasting/geojson/input_file_gen.py
PURPOSE
-------
This module generates GeoJSON input files required by URBANopt simulations.

It converts structured user input (from UI or shared state) into a valid
URBANopt project GeoJSON file, including:
- Project-level simulation settings
- Site origin definition
- Building features with geometry and properties

The generated GeoJSON is stored in the run directory and used as input
for URBANopt simulations.

RESPONSIBILITIES
----------------
1. Load and modify a template GeoJSON project file
2. Configure project-level simulation parameters
3. Define site origin (location + weather)
4. Generate building features based on user input
5. Create simple geometric footprints for buildings
6. Save GeoJSON files with unique filenames

EXECUTION FLOW
--------------
Typical workflow:

1. Load template GeoJSON from predefined location
2. Initialize GeoJSONProject object
3. Apply project-level settings (weather, time range, etc.)
4. Iterate through dwelling configurations:
   - Create building features
   - Assign geometry and attributes
5. Save generated GeoJSON into run directory
6. Return path to generated file

TYPICAL CALLER
--------------
- Load forecasting core
- Project setup pipeline
- UI-based scenario creation

IMPORTANT NOTES
---------------
- Building footprints are approximated as square polygons
- Geographic conversion uses simplified meters-to-degrees approximation
- Only "Site Origin" feature is preserved from template
- All building features are dynamically generated
"""


# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import json
import math
import os
from pathlib import Path


# ---------------------------------------------------------------------
# Utility: generate unique filename
# ---------------------------------------------------------------------
# Creates filenames like:
#   generated_project_1.json
#   generated_project_2.json
#
# Ensures no overwrite of existing files.
# ---------------------------------------------------------------------


def get_next_filename(base_path: Path, base_name: str, extension: str) -> Path:
    n = 1
    while True:
        filename = f"{base_name}_{n}.{extension}"
        full_path = os.path.join(base_path, filename)

        if not os.path.exists(full_path):
            return full_path

        n += 1


# ---------------------------------------------------------------------
# Main class: GeoJSON project builder
# ---------------------------------------------------------------------
# Wraps template modification and building creation logic.
# ---------------------------------------------------------------------


class GeoJSONProject:
    def __init__(self, template_path):
        """
        Initialize GeoJSON project from template.

        Only the "Site Origin" feature is retained.
        All building features will be generated dynamically.
        """
        with open(template_path) as f:
            self.data = json.load(f)

        # Keep only Site Origin feature
        self.data["features"] = [
            f for f in self.data["features"] if f["properties"]["type"] == "Site Origin"
        ]

    # -----------------------------------------------------------------
    # Project-level configuration
    # -----------------------------------------------------------------

    def set_project_inputs(
        self,
        weather_filename,
        climate_zone,
        begin_date,
        end_date,
        timesteps_per_hour,
        template,
        lon,
        lat,
    ):
        """
        Set global project simulation parameters.

        Also updates Site Origin feature with same information.
        """

        p = self.data["project"]

        p["weather_filename"] = weather_filename
        p["climate_zone"] = climate_zone
        p["begin_date"] = begin_date
        p["end_date"] = end_date
        p["timesteps_per_hour"] = timesteps_per_hour
        p["default_template"] = template

        site = self._get_site_origin()

        if site:
            site["properties"]["weather_filename"] = weather_filename
            site["properties"]["climate_zone"] = climate_zone
            site["properties"]["begin_date"] = begin_date
            site["properties"]["end_date"] = end_date
            site["properties"]["timesteps_per_hour"] = timesteps_per_hour

            # Update site location (lon, lat)
            site["geometry"]["coordinates"] = [lon, lat]

    # -----------------------------------------------------------------
    # Helper: get Site Origin feature
    # -----------------------------------------------------------------

    def _get_site_origin(self):
        for f in self.data["features"]:
            if f["properties"]["type"] == "Site Origin":
                return f
        return None

    # -----------------------------------------------------------------
    # Generate next building ID
    # -----------------------------------------------------------------
    # Ensures unique building identifiers across features.
    # -----------------------------------------------------------------

    def _next_building_id(self):
        ids = [
            int(f["properties"]["id"])
            for f in self.data["features"]
            if f["properties"]["type"] == "Building"
        ]

        return max(ids) + 1 if ids else 1

    # -----------------------------------------------------------------
    # Geometry generator: square footprint
    # -----------------------------------------------------------------
    # Creates a square polygon centered at given centroid.
    #
    # Inputs:
    # - centroid (lon, lat)
    # - footprint area (ft²)
    #
    # Notes:
    # - Converts ft² → m²
    # - Uses approximate conversion to degrees
    # -----------------------------------------------------------------

    def _square_polygon(self, centroid, area_ft2):
        lon, lat = centroid

        # Convert ft² → m²
        area_m2 = area_ft2 * 0.092903

        side = math.sqrt(area_m2)
        half = side / 2

        # Convert meters → degrees (approximate)
        lat_deg = half / 111320
        lon_deg = half / (111320 * math.cos(math.radians(lat)))

        polygon = [
            [lon - lon_deg, lat - lat_deg],
            [lon - lon_deg, lat + lat_deg],
            [lon + lon_deg, lat + lat_deg],
            [lon + lon_deg, lat - lat_deg],
            [lon - lon_deg, lat - lat_deg],
        ]

        return polygon

    # -----------------------------------------------------------------
    # Add building feature
    # -----------------------------------------------------------------
    # Creates a GeoJSON feature with building attributes and geometry.
    # -----------------------------------------------------------------

    def add_building(
        self,
        centroid,
        building_type,
        floor_area,
        footprint_area,
        number_of_stories_above_ground,
        number_of_stories,
        number_of_bedrooms,
        foundation_type,
        attic_type,
        system_type,
        heating_system_fuel_type,
        cooking_range_oven_fuel_type,
        clothes_dryer_fuel_type,
        water_heater_fuel_type,
        onsite_parking_fraction,
        template,
        number_of_occupants,
    ):
        building_id = self._next_building_id()

        # Generate square footprint geometry
        polygon = self._square_polygon(centroid, footprint_area)

        feature = {
            "type": "Feature",
            "properties": {
                "id": str(building_id),
                "name": f"Residential {building_id}",
                "type": "Building",
                # Building attributes
                "building_type": building_type,
                "floor_area": floor_area,
                "footprint_area": footprint_area,
                "number_of_stories_above_ground": number_of_stories_above_ground,
                "number_of_stories": number_of_stories,
                "number_of_bedrooms": number_of_bedrooms,
                "foundation_type": foundation_type,
                "attic_type": attic_type,
                "system_type": system_type,
                "heating_system_fuel_type": heating_system_fuel_type,
                "cooking_range_oven_fuel_type": cooking_range_oven_fuel_type,
                "clothes_dryer_fuel_type": clothes_dryer_fuel_type,
                "water_heater_fuel_type": water_heater_fuel_type,
                "onsite_parking_fraction": onsite_parking_fraction,
                "template": template,
                "number_of_occupants": number_of_occupants,
            },
            "geometry": {"type": "Polygon", "coordinates": [polygon]},
        }

        self.data["features"].append(feature)

        print(f"Added Residential {building_id}")

    # -----------------------------------------------------------------
    # Save GeoJSON file
    # ---------------------------------------------------------------------

    def save(self, output_path):
        with open(output_path, "w") as f:
            json.dump(self.data, f, indent=2)

        print("GeoJSON saved:", output_path)


# ---------------------------------------------------------------------
# Main function: generate GeoJSON from shared state
# ---------------------------------------------------------------------
# Converts UI/shared_state input into URBANopt-ready GeoJSON file.
# ---------------------------------------------------------------------


def generate_geojson(shared_state, run_dir):
    print("DWELLINGS DATA:", shared_state["dwellings"])

    # -----------------------------------------------------------------
    # Load template
    # -----------------------------------------------------------------

    template_path = (
        Path(__file__).parent / "templates" / "example_project_combined.json"
    )

    if not template_path.exists():
        raise FileNotFoundError(f"GeoJSON template not found: {template_path}")

    proj = GeoJSONProject(template_path)

    # -----------------------------------------------------------------
    # Apply project-level settings
    # -----------------------------------------------------------------

    proj.set_project_inputs(
        weather_filename=shared_state["weather_filename"],
        climate_zone=shared_state["climate_zone"],
        begin_date=shared_state["begin_date"],
        end_date=shared_state["end_date"],
        timesteps_per_hour=shared_state["timesteps_per_hour"],
        template=shared_state["template"],
        lon=float(shared_state["lon"]),
        lat=float(shared_state["lat"]),
    )

    # -----------------------------------------------------------------
    # Create building features
    # -----------------------------------------------------------------

    for dwelling in shared_state.get("dwellings", []):
        system_type = (
            f"Residential - {dwelling['Heating_type']} and {dwelling['Cooling_type']}"
        )

        num_buildings = int(dwelling["num_buildings"])

        for _ in range(num_buildings):
            proj.add_building(
                centroid=(float(shared_state["lon"]), float(shared_state["lat"])),
                building_type=dwelling["Archetype_house_1"],
                floor_area=float(dwelling["Floor_area"]),
                footprint_area=float(dwelling["Floor_area_1"]),
                number_of_stories_above_ground=int(dwelling["No_floors_above"]),
                number_of_stories=int(dwelling["No_floors"]),
                number_of_bedrooms=int(dwelling["No_bedrooms"]),
                foundation_type=dwelling["Basement_type"],
                attic_type=dwelling["Attic_type"],
                system_type=system_type,
                heating_system_fuel_type=dwelling["Fuel_type_heating"],
                cooking_range_oven_fuel_type=dwelling["Range_fuel"],
                clothes_dryer_fuel_type=dwelling["Dryer_fuel"],
                water_heater_fuel_type=dwelling["Water_heater_fuel"],
                onsite_parking_fraction=1 if dwelling["parking_entry"] == "yes" else 0,
                template=shared_state["template"],
                number_of_occupants=int(dwelling["Occupants_entry"]),
            )

    # -----------------------------------------------------------------
    # Save GeoJSON
    # -----------------------------------------------------------------

    geojson_folder = run_dir / "geojson"
    geojson_folder.mkdir(parents=True, exist_ok=True)

    save_path = get_next_filename(geojson_folder, "generated_project", "json")

    proj.save(save_path)

    return save_path
