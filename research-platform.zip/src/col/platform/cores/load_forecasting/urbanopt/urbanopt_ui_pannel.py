"""
src/col/platform/cores/load_forecasting/urbanopt/urbanopt_ui_pannel.py

URBANopt load forecasting UI panel for the COL platform.

Purpose
-------
This module contains the detailed NiceGUI-based user interface for the
residential URBANopt load forecasting workflow. It isolates the URBANopt-
specific UI implementation from the top-level load forecasting tab so that
the tab layer remains thin, readable, and easier to maintain.

Responsibilities
----------------
1. Render the residential URBANopt load forecasting input form
2. Support running a new URBANopt load forecasting simulation
3. Support loading and plotting an existing URBANopt run
4. Manage queue-driven UI status updates and logs
5. Render Plotly figures for facility profiles and weather data

Execution Flow
--------------
home_page.py
    -> load_forecasting_tab()
        -> render_load_forecasting_urbanopt_panel()
            -> user runs a new simulation
            -> or user loads an existing run
            -> queue-driven UI updates refresh status and logs
            -> Plotly plots are rendered on demand

Design Note
-----------
This module is an intermediate refactor target that moves the heavy URBANopt
UI implementation out of the top-level tab module so the tab layer remains
focused on high-level layout only.
"""

from __future__ import annotations

# =============================================================================
# STANDARD LIBRARY IMPORTS
# =============================================================================

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from queue import Empty, Queue
from typing import Any

# =============================================================================
# THIRD-PARTY IMPORTS
# =============================================================================

import pandas as pd
import plotly.graph_objects as go
from nicegui import app, run, ui

# =============================================================================
# INTERNAL IMPORTS
# =============================================================================

from col.config.config_loader import load_app_config
from col.platform.orchestration.load_forecasting_orchestrator import (
    run_load_forecasting_and_collect,
)

# =============================================================================
# CONFIGURATION HELPERS
# =============================================================================


def _get_default_projects_root() -> str:
    """
    Return the default URBANopt projects root using configured sources.

    Resolution order
    ----------------
    1. UI configuration constant
    2. URBANopt configuration loader
    3. Centralized application configuration
    """
    try:
        from col.ui.config import PROJECTS_ROOT_DEFAULT  # type: ignore

        return str(PROJECTS_ROOT_DEFAULT)
    except Exception:
        pass

    try:
        from col.platform.cores.load_forecasting.urbanopt.config import (
            load_urbanopt_config,
        )  # type: ignore

        cfg = load_urbanopt_config()
        if getattr(cfg, "projects_root", None):
            return str(cfg.projects_root)
    except Exception:
        pass

    return str(load_app_config().urbanopt_projects_root)


# =============================================================================
# URBANOPT PROJECT DISCOVERY UTILITIES
# =============================================================================


def _list_urbanopt_projects(root: Path) -> dict[str, Path]:
    """Return mapping of project_name -> full_path using the expected run structure."""
    try:
        if not root.exists():
            return {}

        projects: dict[str, Path] = {}

        for timestamp_dir in root.iterdir():
            if not timestamp_dir.is_dir():
                continue

            for proj in timestamp_dir.iterdir():
                if proj.is_dir() and proj.name.lower().startswith("uo_"):
                    projects[proj.name] = proj

        return dict(sorted(projects.items()))

    except Exception as e:
        print("[ERROR] project listing failed:", e)
        return {}


def _list_run_scenarios(project_path: Path) -> list[str]:
    """Return scenario folder names under project_path/run."""
    try:
        run_dir = project_path / "run"
        if not run_dir.exists():
            return []
        return sorted([p.name for p in run_dir.iterdir() if p.is_dir()])
    except Exception:
        return []


# =============================================================================
# FEATURE LOADING
# =============================================================================


def _load_features_from_run(project_path: Path, scenario: str) -> list[dict[str, Any]]:
    """
    Load feature report CSV data from an existing URBANopt run.

    Parameters
    ----------
    project_path:
        URBANopt project root directory.
    scenario:
        Scenario folder name under project_path/run.

    Returns
    -------
    list[dict[str, Any]]
        Feature metadata and dataframes used by the plotting controls.
    """
    base = project_path / "run" / scenario
    features: list[dict[str, Any]] = []

    for fdir in sorted(base.iterdir()):
        if not fdir.is_dir():
            continue

        json_file = (
            fdir / "025_default_feature_reports" / "default_feature_reports.json"
        )
        if not json_file.exists():
            continue

        with open(json_file, encoding="utf-8") as f:
            data = json.load(f)

        csv_name = Path(data["timeseries_csv"]["path"]).name
        csv_path = fdir / "025_default_feature_reports" / csv_name

        print("[DEBUG] Trying CSV:", csv_path)

        if not csv_path.exists():
            raise FileNotFoundError(f"CSV NOT FOUND: {csv_path}")

        df = pd.read_csv(csv_path)
        df["Datetime"] = pd.to_datetime(df["Datetime"], errors="coerce")
        df = df.dropna(subset=["Datetime"])

        features.append(
            {
                "name": data.get("name", f"Feature {fdir.name}"),
                "df": df,
                "columns": [c for c in df.columns if c != "Datetime"],
            }
        )

    return features


# =============================================================================
# PLOTTING ENGINE
# =============================================================================


def _build_plotly_figure(
    feature_data: list[dict[str, Any]], selected_column: str
) -> go.Figure:
    """Build a Plotly figure for the selected variable across loaded features."""
    fig = go.Figure()
    total_series = None
    total_x = None

    for feature in feature_data:
        df = feature["df"]
        name = feature["name"]

        if selected_column not in df.columns:
            continue

        x = pd.to_datetime(df["Datetime"], errors="coerce").ffill()
        y = pd.to_numeric(df[selected_column], errors="coerce").fillna(0.0)

        if total_series is None:
            total_series = y.copy()
            total_x = x.copy()
        else:
            total_series = total_series.add(y, fill_value=0.0)

        fig.add_trace(
            go.Scatter(
                x=x,
                y=y,
                mode="lines",
                name=name,
            )
        )

    if total_series is not None and total_x is not None:
        fig.add_trace(
            go.Scatter(
                x=total_x,
                y=total_series,
                mode="lines",
                name="TOTAL",
                line=dict(width=4),
            )
        )

    unit = ""
    if "(" in selected_column:
        unit = selected_column.split("(")[-1].replace(")", "")

    fig.update_layout(
        title=selected_column,
        xaxis_title="Time",
        yaxis_title=unit,
        template="plotly_white",
        height=600,
    )

    return fig


# =============================================================================
# INTERNAL MESSAGE STRUCTURE FOR UI QUEUE
# =============================================================================


@dataclass
class _UiMsg:
    """Queue message used for thread-safe UI updates."""

    type: str
    payload: dict[str, Any]


# =============================================================================
# PUBLIC PANEL RENDERER
# =============================================================================


def render_load_forecasting_urbanopt_panel() -> None:
    """
    Render the residential URBANopt load forecasting panel.

    This function contains the detailed URBANopt-specific UI implementation
    and is intended to be called from the top-level load forecasting tab.
    """
    ui.markdown("### Residential Load Forecasting (URBANopt)")

    active = app.storage.tab.get("active_project")

    if not active or not active.get("workspace_path"):
        ui.notify("No active project selected", color="negative")
        return

    workspace = Path(active["workspace_path"])
    projects_root = workspace / "load_forecasting" / "residential" / "runs"
    projects_root.mkdir(parents=True, exist_ok=True)

    # =========================================================================
    # INPUT CONFIGURATION PANEL
    # =========================================================================
    with ui.card().classes("w-full"):
        ui.markdown("### Inputs")
        ui.label(f"URBANopt projects root: {projects_root}").classes(
            "text-xs text-slate-600 break-all"
        )

        ui.markdown("### Dwelling Design")

        with ui.grid(columns=2).classes("w-full gap-4"):
            num_buildings = ui.number("Number of houses", value=1).classes("w-full")

            building_type = ui.select(
                ["Single-Family Detached", "Single-Family Attached", "Multifamily"],
                label="Building type",
            ).classes("w-full")

            parking = ui.select(["yes", "no"], label="Onsite parking").classes("w-full")

            floor_area = ui.number("Floor area (sq.ft.)").classes("w-full")
            floor_area_1 = ui.number("First floor area (sq.ft.)").classes("w-full")
            occupants = ui.number("Number of occupants", value=4).classes("w-full")
            stories = ui.number("Total stories", value=2).classes("w-full")
            stories_above = ui.number("Stories above ground", value=2).classes("w-full")
            bedrooms = ui.number("Number of bedrooms", value=3).classes("w-full")

        foundation = ui.select(
            [
                "slab",
                "crawlspace - vented",
                "crawlspace - unvented",
                "crawlspace - conditioned",
                "basement - unconditioned",
                "basement - conditioned",
                "ambient",
            ],
            label="Foundation type",
        ).classes("w-full")

        attic = ui.select(
            ["attic - vented", "attic - unvented", "attic - conditioned", "flat roof"],
            label="Attic type",
        ).classes("w-full")

        ui.separator()
        ui.markdown("### HVAC Systems")

        with ui.grid(columns=2).classes("w-full gap-4"):
            heating_type = ui.select(
                [
                    "electric resistance",
                    "furnace",
                    "boiler",
                    "air-to-air heat pump",
                    "mini-split heat pump",
                ],
                label="Heating system",
            ).classes("w-full")

            cooling_type = ui.select(
                [
                    "central air conditioner",
                    "room air conditioner",
                    "evaporative cooler",
                    "air-to-air heat pump",
                ],
                label="Cooling system",
            ).classes("w-full")

            heating_fuel = ui.select(
                ["electricity", "natural gas", "propane", "wood"],
                label="Heating fuel",
            ).classes("w-full")

        ui.separator()
        ui.markdown("### Appliance Fuel")

        with ui.grid(columns=2).classes("w-full gap-4"):
            range_fuel = ui.select(
                ["electricity", "natural gas", "propane", "wood", "None"],
                label="Cooking range fuel",
            ).classes("w-full")

            water_heater = ui.select(
                ["electricity", "natural gas", "propane", "wood", "None"],
                label="Water heater fuel",
            ).classes("w-full")

            dryer_fuel = ui.select(
                ["electricity", "natural gas", "propane", "wood", "None"],
                label="Dryer fuel",
            ).classes("w-full")

            num_evs = ui.number("Number of EVs", value=0).classes("w-full")

        ui.separator()
        ui.markdown("### Appliances")

        with ui.grid(columns=3).classes("w-full gap-4"):
            ui.checkbox("Refrigerator")
            ui.checkbox("Laptop")
            ui.checkbox("Television")
            ui.checkbox("Freezer")
            ui.checkbox("Dishwasher")
            ui.checkbox("Washing machine")
            ui.checkbox("Microwave oven")
            ui.checkbox("Electric kettle")
            ui.checkbox("Electric Vehicle")

        ui.separator()
        ui.markdown("### Microgeneration")

        with ui.grid(columns=2).classes("w-full gap-4"):
            pv = ui.checkbox("Photovoltaic")
            bess = ui.checkbox("Battery storage")
            v2g = ui.checkbox("Vehicle to grid")
            pv_rating = ui.number("PV rating (kW)", value=0).classes("w-full")
            bess_rating = ui.number("BESS rating (kW)", value=0).classes("w-full")
            v2g_power = ui.number("V2G power (kW)", value=0).classes("w-full")

        ui.separator()

        with ui.grid(columns=2).classes("w-full gap-4"):
            project_prefix_in = ui.input(
                "Project prefix (for new run)",
                value="uo_example",
            ).classes("w-full")

        with ui.row().classes("w-full items-center justify-between"):
            btn_run_new = ui.button("RUN LOAD FORECASTING CORE", color="primary")
            btn_clear = ui.button("CLEAR PLOTS/LOG", color="secondary")

    # =========================================================================
    # EXISTING RUN SELECTION PANEL
    # =========================================================================
    with ui.card().classes("w-full mt-4"):
        ui.markdown("### Plot an existing run (no rerun)")

        project_select = ui.select(
            options=[],
            label="Select URBANopt project (uo_*)",
            value=None,
        ).classes("w-full")

        scenario_select = ui.select(
            options=[],
            label="Select scenario (run/<scenario>)",
            value=None,
        ).classes("w-full")

        with ui.row().classes("w-full items-end gap-3"):
            auto_features = ui.checkbox("Auto-detect feature count", value=True)
            features_in = ui.number(
                "Expected features", value=1, min=1, step=1
            ).classes("w-48")
            btn_refresh_lists = ui.button("↻ Refresh lists", color="secondary")
            btn_plot_existing = ui.button("PLOT SELECTED RUN", color="primary")

        def _refresh_projects_and_scenarios() -> None:
            projects = _list_urbanopt_projects(projects_root)

            project_select.options = list(projects.keys())
            project_select.project_map = projects

            if (
                project_select.options
                and project_select.value not in project_select.options
            ):
                project_select.value = project_select.options[0]

        def _auto_detect_feature_count(project_path: Path, scenario: str) -> int:
            try:
                base = project_path / "run" / scenario
                return len([d for d in base.iterdir() if d.is_dir()])
            except Exception:
                return 0

        def _refresh_scenarios_only() -> None:
            if not project_select.value:
                scenario_select.options = []
                scenario_select.value = None
                return

            proj_path = project_select.project_map.get(project_select.value)
            scenarios = _list_run_scenarios(proj_path)
            scenario_select.options = scenarios
            if scenarios and scenario_select.value not in scenarios:
                scenario_select.value = scenarios[0]

            if auto_features.value and scenario_select.value:
                n = _auto_detect_feature_count(proj_path, str(scenario_select.value))
                if n > 0:
                    features_in.value = n

        btn_refresh_lists.on("click", _refresh_projects_and_scenarios)
        project_select.on("update:model-value", lambda e: _refresh_scenarios_only())
        scenario_select.on("update:model-value", lambda e: _refresh_scenarios_only())

        _refresh_projects_and_scenarios()
        _refresh_scenarios_only()

    # =========================================================================
    # STATUS + LOG PANEL
    # =========================================================================
    with ui.card().classes("w-full mt-4"):
        ui.markdown("### Status")

        status_icon = ui.label("").classes("text-xl")
        status_text = ui.label("Ready").classes("text-base")

        progress = ui.linear_progress(value=0.0).classes("w-full")
        progress.set_visibility(False)

        details = ui.expansion("Details (click to open)", icon="info").classes("w-full")
        with details:
            detail_box = (
                ui.textarea("Log (short)", value="")
                .classes("w-full")
                .props("rows=12 outlined")
            )
            detail_box.props("readonly")
            full_log_label = ui.label("").classes("text-xs text-gray-600 break-all")

    # =========================================================================
    # PLOT RENDERING PANEL
    # =========================================================================
    with ui.card().classes("w-full mt-4"):
        ui.markdown("### Plots")

        plot_area_container = ui.column().classes("w-full")
        plot_state: dict[str, Any] = {"plot": None}

        with ui.row().classes("w-full gap-3"):
            feature_selector = ui.column().classes("w-full")
            column_select = ui.select([], label="Select Variable").classes("w-64")
            btn_plot = ui.button("Plot")
            btn_clear_plot = ui.button("Clear")
            btn_save = ui.button("Save Figure")
            btn_weather = ui.button("Plot Weather")

        feature_cache: list[dict[str, Any]] = []
        current_project: dict[str, Any] = {"path": None, "scenario": None}
        selected_features: dict[str, bool] = {}

    # =========================================================================
    # THREAD-SAFE UI MESSAGE QUEUE
    # =========================================================================
    q: Queue[_UiMsg] = Queue()

    def _set_status(icon: str, text: str) -> None:
        status_icon.text = icon
        status_text.text = text

    def _append_log(msg: str) -> None:
        detail_box.value = (detail_box.value or "") + msg + "\n"

    def _clear_plots() -> None:
        plot_area_container.clear()
        plot_state["plot"] = None

    def _render_plot(fig: go.Figure) -> None:
        plot_area_container.clear()
        with plot_area_container:
            plot_state["plot"] = ui.plotly(fig).classes("w-full h-[600px]")

    def _clear_all() -> None:
        _set_status("", "Ready")
        progress.value = 0.0
        progress.set_visibility(False)
        detail_box.value = ""
        full_log_label.text = ""
        _clear_plots()

    def _disable_buttons(disable: bool) -> None:
        if disable:
            btn_run_new.disable()
            btn_plot_existing.disable()
            btn_refresh_lists.disable()
            btn_clear.disable()
        else:
            btn_run_new.enable()
            btn_plot_existing.enable()
            btn_refresh_lists.enable()
            btn_clear.enable()

    def _plot_weather(epw_path: Path) -> go.Figure:
        df = pd.read_csv(epw_path, skiprows=8, header=None)
        temp = df.iloc[:, 6]

        fig = go.Figure()
        fig.add_trace(go.Scatter(y=temp, mode="lines", name="Temperature (°C)"))

        fig.update_layout(
            title="Weather: Outdoor Dry Bulb Temperature",
            xaxis_title="Hour",
            yaxis_title="°C",
            template="plotly_white",
        )

        return fig

    def _drain_queue() -> None:
        try:
            while True:
                msg = q.get_nowait()
                msg_type = msg.type
                payload = msg.payload

                if msg_type == "status":
                    _set_status(
                        payload.get("icon", " "),
                        payload.get("text", "Working..."),
                    )
                    progress.set_visibility(True)
                    progress.value = float(payload.get("progress", 0.0))

                elif msg_type == "detail":
                    _append_log(str(payload.get("text", "")))

                elif msg_type == "result":
                    progress.value = 1.0
                    progress.set_visibility(True)
                    _set_status(" ", payload.get("status_text", "Done"))
                    full_log_label.text = payload.get("full_log_path", "")
                    _append_log("Run complete. Select variable to plot.")

                elif msg_type == "error":
                    progress.set_visibility(True)
                    progress.value = float(payload.get("progress", 0.0))
                    _set_status(" ", "ERROR")
                    _append_log(str(payload.get("error", "")))

        except Empty:
            return

    def cb_status(progress_value: float, text: str) -> None:
        q.put(
            _UiMsg(
                "status",
                {"icon": " ", "text": text, "progress": progress_value},
            )
        )

    def cb_detail(text: str) -> None:
        q.put(_UiMsg("detail", {"text": text}))

    def _on_plot_click() -> None:
        if not feature_cache:
            ui.notify("No data loaded", color="negative")
            return

        if not column_select.value:
            ui.notify("Select a variable", color="warning")
            return

        filtered = [
            feature
            for feature in feature_cache
            if selected_features.get(feature["name"], True)
            and column_select.value in feature["df"].columns
        ]

        if not filtered:
            ui.notify(
                "Selected variable is not available in the checked features",
                color="negative",
            )
            return

        fig = _build_plotly_figure(filtered, str(column_select.value))
        print("[DEBUG] Selected column:", column_select.value)
        print("[DEBUG] Sample values:", filtered[0]["df"][column_select.value].head())

        _render_plot(fig)

    def _clear_plot() -> None:
        _clear_plots()

    def _save_plot() -> None:
        plot_widget = plot_state.get("plot")

        if plot_widget is None:
            ui.notify("No plot available to save", color="warning")
            return

        if not column_select.value or not current_project["path"]:
            ui.notify("Missing plot context", color="warning")
            return

        safe_name = (
            str(column_select.value).replace(":", "_").replace("(", "").replace(")", "")
        )
        out = current_project["path"] / f"{safe_name}.html"

        plot_widget.figure.write_html(str(out))
        ui.notify(f"Saved: {out}")

    def _on_weather() -> None:
        if not current_project["path"]:
            ui.notify("No project loaded", color="warning")
            return

        weather_dir = current_project["path"] / "weather"
        epw_files = list(weather_dir.glob("*.epw"))

        if not epw_files:
            ui.notify("No weather file found", color="negative")
            return

        epw = next((f for f in epw_files if "CAN_" in f.name), epw_files[0])
        fig = _plot_weather(epw)
        _render_plot(fig)

    btn_plot.on("click", _on_plot_click)
    btn_clear_plot.on("click", _clear_plot)
    btn_save.on("click", _save_plot)
    btn_weather.on("click", _on_weather)

    async def _on_run_new() -> None:
        _clear_all()
        _disable_buttons(True)

        try:
            run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
            run_dir = projects_root / run_id
            run_dir.mkdir(parents=True, exist_ok=True)

            shared_state = {
                "lat": active["latitude"],
                "lon": active["longitude"],
                "begin_date": "2020-01-01",
                "end_date": "2020-12-31",
                "timesteps_per_hour": 1,
                "template": "ResidentialTemplate",
                "climate_zone": "5A",
                "weather_filename": "",
                "dwellings": [],
            }

            dwelling_data = {
                "num_buildings": num_buildings.value,
                "Archetype_house_1": building_type.value,
                "parking_entry": parking.value,
                "Floor_area": floor_area.value,
                "Floor_area_1": floor_area_1.value,
                "Occupants_entry": occupants.value,
                "No_floors": stories.value,
                "No_floors_above": stories_above.value,
                "No_bedrooms": bedrooms.value,
                "Basement_type": foundation.value,
                "Attic_type": attic.value,
                "Heating_type": heating_type.value,
                "Cooling_type": cooling_type.value,
                "Fuel_type_heating": heating_fuel.value,
                "Range_fuel": range_fuel.value,
                "Water_heater_fuel": water_heater.value,
                "Dryer_fuel": dryer_fuel.value,
                "No_EVs": num_evs.value,
                "photovoltaic_var": pv.value,
                "bess_var": bess.value,
                "v2g_var": v2g.value,
                "PV_rating": pv_rating.value,
                "BESS_rating": bess_rating.value,
                "V2G_power": v2g_power.value,
            }

            shared_state["dwellings"].append(dwelling_data)

            shared_state_file = run_dir / "shared_state.json"
            with open(shared_state_file, "w", encoding="utf-8") as f:
                json.dump(shared_state, f, indent=2)

            print("Shared state saved to:", shared_state_file)

            result = await run.io_bound(
                run_load_forecasting_and_collect,
                project_prefix_in.value.strip(),
                run_dir,
                cb_status,
                cb_detail,
            )

            q.put(
                _UiMsg(
                    "result",
                    {
                        "status_text": "Load forecasting done",
                        "full_log_path": f"Full log: {result.get('full_log_path', '')}",
                        "series": result["series"],
                    },
                )
            )

        except Exception as e:
            q.put(_UiMsg("error", {"error": repr(e)}))
        finally:
            _disable_buttons(False)

    async def _on_plot_existing() -> None:
        _clear_all()
        _disable_buttons(True)

        try:
            if not project_select.value or not scenario_select.value:
                raise ValueError("Select both a project and a scenario first.")

            proj_path = project_select.project_map.get(project_select.value)
            scen = str(scenario_select.value)

            cb_status(0.6, "Loading feature data...")

            features = await run.io_bound(_load_features_from_run, proj_path, scen)

            if not features:
                raise RuntimeError("No feature data found")

            feature_cache.clear()
            feature_cache.extend(features)
            selected_features.clear()
            feature_selector.clear()

            for feature in features:
                selected_features[feature["name"]] = True

                with feature_selector:
                    ui.checkbox(
                        feature["name"],
                        value=True,
                        on_change=lambda e,
                        name=feature["name"]: selected_features.__setitem__(
                            name, e.value
                        ),
                    ).classes("block")

            all_cols = set()
            for feature in features:
                all_cols.update(feature["columns"])

            column_select.options = sorted(all_cols)
            column_select.value = None
            column_select.update()
            print("[DEBUG] Columns loaded:", sorted(all_cols))

            current_project["path"] = proj_path
            current_project["scenario"] = scen
            print("[DEBUG] current_project set to:", proj_path)

            _append_log(f"{len(features)} features loaded — ready to plot")
            _set_status(" ", "Ready to plot")

        except Exception as e:
            q.put(_UiMsg("error", {"error": repr(e)}))
        finally:
            _disable_buttons(False)

    btn_run_new.on("click", _on_run_new)
    btn_plot_existing.on("click", _on_plot_existing)
    btn_clear.on("click", _clear_all)
    ui.timer(0.1, _drain_queue)
