"""
MODULE: URBANopt Execution Runner
FILE: runner.py
LOCATION:
src/col/platform/cores/load_forecasting/urbanopt/runner.py

PURPOSE
-------
This module provides a complete execution pipeline for running URBANopt
simulations from within the Energy Systems Research Framework.

It automates the full workflow including:
- environment validation
- project creation
- resource installation
- GeoJSON preparation and correction
- weather configuration
- scenario creation
- simulation execution
- output verification

This module acts as the primary bridge between Energy Systems Research Framework inputs and
URBANopt simulation outputs.

RESPONSIBILITIES
----------------
1. Validate URBANopt CLI environment
2. Ensure urbanopt-cli repository is available (auto-clone if missing)
3. Create new URBANopt project
4. Install required resources and mappers
5. Copy and fix GeoJSON inputs
6. Copy and validate weather files
7. Create simulation scenario
8. Execute URBANopt run
9. Validate output generation

EXECUTION FLOW
--------------
1. Verify environment and CLI availability
2. Ensure urbanopt-cli repository exists
3. Create project folder
4. Clean default template weather files
5. Install resources and mappers
6. Copy latest GeoJSON from COL pipeline
7. Apply GeoJSON fixes (geometry, fields, dates)
8. Copy weather data and clean invalid files
9. Synchronize GeoJSON with selected weather file
10. Create scenario and install dependencies
11. Run URBANopt simulation
12. Validate output files

TYPICAL CALLER
--------------
- Load forecasting pipeline
- Energy Systems Research Framework orchestration layer

IMPORTANT NOTES
---------------
- Designed for robust execution with auto-recovery mechanisms
- Includes extensive debug prints for traceability
- Automatically fixes common URBANopt input issues
- Uses PowerShell-based execution for environment activation
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import json
import shutil
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------
# Internal imports
# ---------------------------------------------------------------------

from col.config.config_loader import load_app_config
from col.platform.utils.powershell import run_powershell

# ---------------------------------------------------------------------
# Configuration containers
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class UrbanOptConfig:
    """
    Configuration for URBANopt execution environment.
    """

    projects_root: Path
    uo_env_ps1: Path


@dataclass
class UrbanOptRunResult:
    """
    Output container for URBANopt run results.
    """

    project_path: Path
    scenario_csv: Path
    scenario_stem: str
    full_log_path: Path


# ---------------------------------------------------------------------
# PowerShell execution utility
# ---------------------------------------------------------------------
# Executes URBANopt CLI commands inside activated environment
# ---------------------------------------------------------------------


def run_ps(cmd: str, cwd: Path, cfg: UrbanOptConfig):
    """
    Execute a PowerShell command with URBANopt environment activated.
    """

    full = f'. "{cfg.uo_env_ps1}"; {cmd}'

    print("\n================================================")
    print("[RUN COMMAND]", cmd)
    print("[CWD]", cwd)
    print("[ENV]", cfg.uo_env_ps1)
    print("================================================\n")

    proc = subprocess.Popen(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", full],
        cwd=str(cwd),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    logs = []

    # Stream output for real-time debugging
    for line in proc.stdout:
        print(line, end="")
        logs.append(line)

    code = proc.wait()

    print("\n[EXIT CODE]", code)

    if code != 0:
        print("\n FULL LOG:\n", "".join(logs))
        raise RuntimeError(f"FAILED: {cmd}")


# ---------------------------------------------------------------------
# Ensure urbanopt-cli repository exists
# ---------------------------------------------------------------------


def ensure_urbanopt_repo(base_dir: Path) -> Path:
    """
    Ensure urbanopt-cli repository is available locally.

    If missing, it is cloned automatically.
    """

    repo = base_dir / "urbanopt-cli"

    print("\n[CHECK] urbanopt-cli repo:", repo)

    if repo.exists():
        print("[OK] Repo exists")
        return repo

    print("[INFO] Repo missing  cloning...")

    subprocess.run(
        ["git", "clone", "https://github.com/urbanopt/urbanopt-cli.git"],
        cwd=str(base_dir),
        check=True,
    )

    if not repo.exists():
        raise RuntimeError("Failed to clone urbanopt-cli")

    print("[OK] Repo cloned successfully")

    return repo


def ensure_urbanopt_cli_bundle(cfg: UrbanOptConfig, urbanopt_cli_repo: Path):
    """
    Ensure the local cloned urbanopt-cli repo has its Ruby dependencies installed.
    """
    ps = f"""
    & '{cfg.uo_env_ps1}';
    cd '{urbanopt_cli_repo}';
    bundle install --gemfile '{urbanopt_cli_repo / "Gemfile"}'
    """
    code = run_powershell(ps, urbanopt_cli_repo, print)
    if code != 0:
        raise RuntimeError("FAILED: urbanopt-cli bundle install")


# ---------------------------------------------------------------------
# Verify URBANopt environment
# ---------------------------------------------------------------------


def verify_environment(cfg: UrbanOptConfig):
    """
    Verify that URBANopt CLI environment is correctly configured.
    """

    print("\n[STEP] Verifying URBANopt environment")

    if not cfg.uo_env_ps1.exists():
        raise RuntimeError(f"uo_env.ps1 not found: {cfg.uo_env_ps1}")

    # Test CLI availability
    run_ps("uo --help", cfg.projects_root, cfg)

    print("[OK] URBANopt CLI verified")


# ---------------------------------------------------------------------
# Install required resources and mappers
# ---------------------------------------------------------------------


def install_required_files(project_dir: Path, repo: Path):
    """
    Copy required URBANopt resources and mappers into project directory.
    """

    print("\n[STEP] Checking resources in project")

    dst_resources = project_dir / "resources"
    src_resources = repo / "example_files/resources"

    if not src_resources.exists():
        raise RuntimeError("residential-measures missing in repo")

    shutil.copytree(src_resources, dst_resources, dirs_exist_ok=True)

    # Ensure HPXML dependency file exists
    target = (
        project_dir
        / "resources/residential-measures/resources/hpxml-measures/HPXMLtoOpenStudio/resources/data"
    )
    target.mkdir(parents=True, exist_ok=True)

    critical_file = target / "zipcode_weather_stations.csv"

    if not critical_file.exists():
        # Fallback path relative to repository
        fallback = (
            Path(__file__).resolve().parents[5]
            / "weather/data/zipcode_weather_stations.csv"
        )

        if not fallback.exists():
            raise RuntimeError("Fallback zipcode_weather_stations.csv NOT FOUND")

        shutil.copy(fallback, critical_file)

    # ---------------- Mapper ----------------
    src_mapper = repo / "example_files/mappers/residential"
    dst_mapper = project_dir / "mappers/residential"

    shutil.copytree(src_mapper, dst_mapper, dirs_exist_ok=True)

    util = dst_mapper / "util.rb"

    if not util.exists():
        raise RuntimeError("util.rb missing after copy")


# ---------------------------------------------------------------------
# GeoJSON fix engine
# ---------------------------------------------------------------------
# Automatically corrects common URBANopt input issues
# ---------------------------------------------------------------------


def convert_point_to_polygon(coords, size=0.0001):
    """
    Convert point geometry to square polygon footprint.
    """
    x, y = coords

    return [
        [
            [x - size, y - size],
            [x + size, y - size],
            [x + size, y + size],
            [x - size, y + size],
            [x - size, y - size],
        ]
    ]


def fix_geojson(feature_file: Path):
    """
    Apply corrections to GeoJSON input:
    - Convert Point to Polygon
    - Ensure required fields exist
    - Fix geometry consistency
    - Normalize simulation dates
    """

    with open(feature_file) as f:
        data = json.load(f)

    for ftr in data["features"]:
        props = ftr["properties"]
        geom = ftr["geometry"]

        # Geometry fix
        if geom["type"] == "Point":
            polygon = convert_point_to_polygon(geom["coordinates"])
            geom["type"] = "Polygon"
            geom["coordinates"] = polygon

        # Required fields
        if "footprint_area" not in props:
            props["footprint_area"] = props.get("floor_area", 100)

        if "number_of_stories_above_ground" not in props:
            props["number_of_stories_above_ground"] = props.get("number_of_stories", 1)

        # Geometry consistency
        floor = props.get("floor_area", 100)
        stories = props.get("number_of_stories_above_ground", 1)
        footprint = props.get("footprint_area", 100)

        if abs((footprint * stories) - floor) > 0.1:
            props["floor_area"] = footprint * stories

        # Normalize simulation year (avoid leap year issues)
        props["begin_date"] = "2019-01-01"
        props["end_date"] = "2019-12-31"

    with open(feature_file, "w") as f:
        json.dump(data, f, indent=2)


# ---------------------------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------------------------


def create_and_run_urbanopt(
    cfg: UrbanOptConfig,
    workspace_project_path: Path,
    project_prefix: str | None = None,
):
    # STEP 1: Environment verification
    verify_environment(cfg)

    # STEP 2: Ensure CLI repo
    base_dir = cfg.projects_root.parent
    repo = ensure_urbanopt_repo(base_dir)

    base_cfg = load_app_config()
    urbanopt_cli_repo = base_cfg.urbanopt_run_root / "urbanopt-cli"
    ensure_urbanopt_cli_bundle(cfg, urbanopt_cli_repo)

    # STEP 3: Create project
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"{project_prefix}_{stamp}" if project_prefix else f"uo_{stamp}"
    proj = cfg.projects_root / name
    run_ps(f'uo create --project-folder "{proj}"', cfg.projects_root, cfg)

    # STEP 4: Clean default weather
    default_weather = proj / "weather"

    if default_weather.exists():
        for f in default_weather.glob("*"):
            f.unlink()

    (proj / "resources").mkdir(exist_ok=True)
    (proj / "mappers").mkdir(exist_ok=True)

    # STEP 5: Install resources
    install_required_files(proj, repo)

    # STEP 6: Copy GeoJSON
    runs_root = workspace_project_path / "load_forecasting/residential/runs"
    latest_run = max(runs_root.iterdir(), key=lambda d: d.stat().st_mtime)

    geojson_src = max(
        (latest_run / "geojson").glob("*.json"), key=lambda f: f.stat().st_mtime
    )
    feature_file = proj / "generated_project.json"

    shutil.copy(geojson_src, feature_file)

    # STEP 7: Fix GeoJSON
    fix_geojson(feature_file)

    # STEP 8: Copy weather
    weather_src = latest_run / "weather"
    weather_dst = proj / "weather"

    shutil.copytree(weather_src, weather_dst, dirs_exist_ok=True)

    # STEP 9: Select correct EPW (Canada)
    epw_files = list(weather_dst.glob("*.epw"))

    valid_epw = next((f for f in epw_files if "CAN_" in f.name), None)

    if not valid_epw:
        raise RuntimeError("No CAN weather file found")

    for f in epw_files:
        if f != valid_epw:
            f.unlink()

    # STEP 10: Synchronize GeoJSON weather
    with open(feature_file) as f:
        data = json.load(f)

    data["project"]["weather_filename"] = valid_epw.name

    for ftr in data["features"]:
        ftr["properties"]["weather_filename"] = valid_epw.name

    with open(feature_file, "w") as f:
        json.dump(data, f, indent=2)

    # STEP 11: Install project-local Ruby dependencies
    run_ps("bundle install", proj, cfg)

    # STEP 12: Create scenario using local urbanopt-cli repo
    # base_cfg = load_app_config()
    # urbanopt_cli_repo = base_cfg.urbanopt_run_root / "urbanopt-cli"

    ps_create = f"""
    & '{cfg.uo_env_ps1}';
    $env:BUNDLE_GEMFILE = '{urbanopt_cli_repo / "Gemfile"}';
    $env:BUNDLE_PATH = 'C:\\COL\\ruby_gems';
    cd '{proj}';
    bundle exec ruby -I '{urbanopt_cli_repo / "lib"}' '{urbanopt_cli_repo / "bin" / "uo"}' create -s generated_project.json
    """
    code = run_powershell(ps_create, proj, print)
    if code != 0:
        raise RuntimeError(
            "FAILED: local urbanopt-cli create -s generated_project.json"
        )

    scenario = proj / "baseline_scenario.csv"

    if not scenario.exists():
        raise RuntimeError("Scenario creation failed")

    # STEP 13: Run simulation using local urbanopt-cli repo
    ps_run = f"""
    & '{cfg.uo_env_ps1}';
    $env:BUNDLE_GEMFILE = '{urbanopt_cli_repo / "Gemfile"}';
    $env:BUNDLE_PATH = 'C:\\COL\\ruby_gems';
    cd '{proj}';
    bundle exec ruby -I '{urbanopt_cli_repo / "lib"}' '{urbanopt_cli_repo / "bin" / "uo"}' run -s baseline_scenario.csv -f generated_project.json
    """
    code = run_powershell(ps_run, proj, print)
    if code != 0:
        raise RuntimeError(
            "FAILED: local urbanopt-cli run -s baseline_scenario.csv -f generated_project.json"
        )

    # STEP 14: Validate outputs
    reports = list((proj / "run").rglob("default_feature_reports.csv"))

    if not reports:
        raise RuntimeError("No results generated")

    return UrbanOptRunResult(
        project_path=proj,
        scenario_csv=scenario,
        scenario_stem="baseline_scenario",
        full_log_path=proj / "urbanopt.log",
    )
