"""
src/col/platform/cores/load_forecasting/urbanopt/__init__.py

URBANopt-based load forecasting core module.

This package contains the implementation of load forecasting
workflows using URBANopt within the COL platform. It provides
core logic and utilities to generate, manage, and process
simulation scenarios for building-level and aggregated load analysis.

Typical Usage:
- Execute URBANopt simulations for load forecasting
- Interface with orchestration and UI layers
- Provide simulation outputs for downstream analysis
"""
