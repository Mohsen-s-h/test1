"""
MODULE: URBANopt Configuration Loader
FILE: config.py
LOCATION:
src/col/platform/cores/load_forecasting/urbanopt/config.py

PURPOSE
-------
This module provides a centralized configuration interface for accessing
URBANopt installation paths and project directories.

It retrieves required paths from environment variables and converts them
into structured Python objects usable across the Energy Systems Research Framework.

This ensures that all URBANopt-related modules use a consistent and
validated configuration source.

RESPONSIBILITIES
----------------
1. Read URBANopt-related environment variables
2. Convert environment values into pathlib Path objects
3. Validate required configuration inputs
4. Provide a structured configuration container
5. Offer convenient access to URBANopt environment scripts

EXECUTION FLOW
--------------
Typical workflow:

1. load_urbanopt_config() is called by a module
2. Required environment variables are read:
   - URBANOPT_CLI_ROOT
   - URBANOPT_PROJECTS_ROOT
3. Paths are validated and converted into Path objects
4. If environment variables are missing:
   - Fallback configuration is loaded from application config
5. A UrbanOptConfig object is returned
6. Downstream modules use this object for:
   - CLI execution
   - project directory access
   - environment activation

TYPICAL CALLER
--------------
- URBANopt runner modules
- Load forecasting pipeline
- CLI execution wrappers

IMPORTANT NOTES
---------------
- Environment variables are the primary configuration source
- Fallback to application config ensures robustness
- Paths are always handled as pathlib.Path objects
- Configuration is immutable (frozen dataclass)
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import os
from dataclasses import dataclass
from pathlib import Path

# ---------------------------------------------------------------------
# Internal configuration loader
# ---------------------------------------------------------------------
# Provides fallback configuration when environment variables are missing
# ---------------------------------------------------------------------

from col.config.config_loader import load_app_config

# ---------------------------------------------------------------------
# Helper: read required environment variable as a Path
# ---------------------------------------------------------------------
# Converts environment variable string into Path object
# and validates its existence.
# ---------------------------------------------------------------------


def _env_path(name: str) -> Path:
    """
    Retrieve a filesystem path from an environment variable.

    Parameters
    ----------
    name : str
        Name of the required environment variable.

    Returns
    -------
    Path
        Path constructed from the environment variable value.

    Raises
    ------
    RuntimeError
        If the environment variable is not defined.
    """
    v = os.getenv(name)

    if not v:
        raise RuntimeError(
            f"Missing environment variable {name}. "
            f'Set it (e.g., in Windows: setx {name} "C:\\..."), then restart terminal.'
        )

    return Path(v)


# ---------------------------------------------------------------------
# Configuration container
# ---------------------------------------------------------------------
# Immutable structure holding URBANopt paths.
#
# Fields:
# - cli_root: location of URBANopt CLI installation
# - projects_root: directory containing project workspaces
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class UrbanOptConfig:
    """
    Immutable configuration describing URBANopt installation paths.
    """

    cli_root: Path
    projects_root: Path

    @property
    def uo_env_ps1(self) -> Path:
        """
        Returns path to URBANopt environment activation script.

        Typically used to initialize Ruby/GEM environment before
        executing URBANopt CLI commands.
        """
        return self.projects_root / "uo_env.ps1"


# ---------------------------------------------------------------------
# Public API: load configuration
# ---------------------------------------------------------------------
# Primary entry point for obtaining URBANopt configuration.
#
# Priority:
#   1. Environment variables
#   2. Application configuration fallback
# ---------------------------------------------------------------------


def load_urbanopt_config() -> UrbanOptConfig:
    """
    Load URBANopt configuration from environment variables.

    Expected environment variables
    ------------------------------
    URBANOPT_CLI_ROOT
        Root directory of the URBANopt CLI installation.

    URBANOPT_PROJECTS_ROOT
        Directory containing URBANopt project workspaces.

    Returns
    -------
    UrbanOptConfig
        Configuration object used by Energy Systems Research Framework modules.
    """

    try:
        # Primary configuration source: environment variables
        return UrbanOptConfig(
            cli_root=_env_path("URBANOPT_CLI_ROOT"),
            projects_root=_env_path("URBANOPT_PROJECTS_ROOT"),
        )

    except RuntimeError:
        # Fallback: application-level configuration
        cfg = load_app_config()

        return UrbanOptConfig(
            cli_root=cfg.urbanopt_projects_root,
            projects_root=cfg.urbanopt_projects_root,
        )
