"""
MODULE: URBANopt Output Reader
FILE: output_reader.py
LOCATION:
src/col/platform/cores/load_forecasting/urbanopt/output_reader.py

PURPOSE
-------
This module provides utilities for discovering and reading URBANopt
feature-level simulation outputs.

It enables programmatic access to time-series data stored in
default_feature_reports files, such as:
- building electricity demand
- onsite PV production

This module acts as a low-level data access layer for URBANopt outputs.

RESPONSIBILITIES
----------------
1. Discover feature report directories within a run scenario
2. Identify the latest report folder for each feature
3. Locate CSV and optional JSON report files
4. Automatically detect timestamp columns in CSV data
5. Extract specific power-related columns
6. Return clean pandas Series objects for downstream use

EXECUTION FLOW
--------------
Typical workflow:

1. A URBANopt run scenario directory is provided:
   <project>/run/<scenario_stem>/
2. Feature directories (numeric folder names) are identified
3. For each feature:
   - Latest *_default_feature_reports folder is selected
   - CSV and JSON report paths are collected
4. CSV files are read and indexed by timestamp
5. Required columns (e.g., load or PV) are extracted
6. Clean time series are returned

TYPICAL CALLER
--------------
- Load aggregation modules
- DER optimization modules
- Data analysis and visualization pipelines

OUTPUT FORMAT
-------------
pandas Series:
- index: DatetimeIndex (if timestamp column detected)
- values: numeric power values (kW)

IMPORTANT NOTES
---------------
- Feature directories must be numeric (e.g., "1", "2", "3")
- Latest report folder is selected based on modification time
- Timestamp column names are detected automatically
- Missing numeric values are safely converted to zero
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from dataclasses import dataclass
from pathlib import Path

# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import pandas as pd

# ---------------------------------------------------------------------
# Data container: feature report paths
# ---------------------------------------------------------------------
# Represents file locations for a single feature.
#
# Fields:
# - feature_id: identifier of the feature (folder name)
# - csv_path: path to default_feature_reports.csv
# - json_path: optional JSON report path (if exists)
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class FeatureReportPaths:
    feature_id: str
    csv_path: Path
    json_path: Path | None


# ---------------------------------------------------------------------
# Discover feature report files in scenario directory
# ---------------------------------------------------------------------
# Identifies all features and their corresponding report files.
# ---------------------------------------------------------------------


def find_feature_reports(run_scenario_dir: Path) -> list[FeatureReportPaths]:
    """
    Locate URBANopt feature report files within a run scenario.

    Parameters
    ----------
    run_scenario_dir : Path
        Directory:
        <project>/run/<scenario_stem>

    Returns
    -------
    list[FeatureReportPaths]
        Collection of report file paths for each feature
    """
    out: list[FeatureReportPaths] = []

    # Select numeric feature directories only
    feature_dirs = [
        p for p in run_scenario_dir.iterdir() if p.is_dir() and p.name.isdigit()
    ]

    # Sort features numerically
    feature_dirs.sort(key=lambda p: int(p.name))

    for feature_dir in feature_dirs:
        # Locate report directories
        reports_dirs = [
            d
            for d in feature_dir.iterdir()
            if d.is_dir() and d.name.endswith("_default_feature_reports")
        ]

        if not reports_dirs:
            continue

        # Select latest report directory
        reports_dir = max(reports_dirs, key=lambda d: d.stat().st_mtime)

        csv_path = reports_dir / "default_feature_reports.csv"

        if not csv_path.exists():
            continue

        # Optional JSON report
        json_path = reports_dir / "default_feature_reports.json"

        out.append(
            FeatureReportPaths(
                feature_id=feature_dir.name,
                csv_path=csv_path,
                json_path=(json_path if json_path.exists() else None),
            )
        )

    return out


# ---------------------------------------------------------------------
# Helper: detect timestamp column
# ---------------------------------------------------------------------
# Converts detected timestamp column into DataFrame index.
#
# Supports multiple naming conventions:
# - Datetime
# - Date_Time
# - Time
# - Timestamp
# ---------------------------------------------------------------------


def _find_time_index(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect timestamp column and set as index.

    If no timestamp column is found, original index is retained.
    """

    for c in df.columns:
        cl = c.lower().strip()

        if cl in ("datetime", "date_time", "time", "timestamp"):
            df[c] = pd.to_datetime(df[c], errors="coerce")
            return df.set_index(c)

    return df  # fallback: no time index


# ---------------------------------------------------------------------
# Generic column reader
# ---------------------------------------------------------------------
# Reads a specified column from report CSV and returns clean Series.
# ---------------------------------------------------------------------


def read_column_kw(report_csv: Path, column_name: str) -> pd.Series:
    """
    Read a power column from URBANopt report CSV.

    Parameters
    ----------
    report_csv : Path
        Path to default_feature_reports.csv

    column_name : str
        Name of column to extract

    Returns
    -------
    pd.Series
        Numeric time series (kW), indexed by datetime if available
    """

    df = pd.read_csv(report_csv)

    # Set time index if available
    df = _find_time_index(df)

    if column_name not in df.columns:
        raise ValueError(
            f"Missing column '{column_name}' in {report_csv}\n"
            f"Available columns: {list(df.columns)}"
        )

    # Convert values to numeric
    s = pd.to_numeric(df[column_name], errors="coerce").fillna(0.0)
    s.name = column_name

    return s


# ---------------------------------------------------------------------
# Read total building electricity demand
# ---------------------------------------------------------------------


def read_load_kw(report_csv: Path) -> pd.Series:
    """
    Extract total facility electricity demand (kW).

    Uses:
    "Electricity:Facility Power(kW)"
    """
    return read_column_kw(report_csv, "Electricity:Facility Power(kW)")


# ---------------------------------------------------------------------
# Read PV production (optional)
# ---------------------------------------------------------------------


def read_pv_kw_optional(report_csv: Path) -> pd.Series:
    """
    Extract onsite PV production (kW), if available.

    Column:
    "ElectricityProduced:Facility Power(kW)"

    Note:
    - May not exist for all simulations
    - Caller should handle missing cases
    """
    return read_column_kw(report_csv, "ElectricityProduced:Facility Power(kW)")
