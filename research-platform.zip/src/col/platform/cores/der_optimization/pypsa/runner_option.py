"""
MODULE: DER Optimization Runner (PyPSA)
FILE: runner_option.py
LOCATION:
src/col/platform/cores/der_optimization/pypsa/runner_option.py

PURPOSE
-------
This module orchestrates the complete DER optimization workflow using PyPSA.

It acts as the main execution pipeline that connects:
- URBANopt simulation outputs (load data)
- Weather-driven PV modeling (EPW → capacity factor)
- DER configuration (PV, battery, diesel, grid constraints)
- PyPSA network construction
- Optimization solver execution
- Result extraction and export

RESPONSIBILITIES
----------------
1. Read and aggregate load profiles from URBANopt outputs
2. Generate PV capacity factor from EPW weather data
3. Configure DER scenario (case selection)
4. Build PyPSA microgrid network
5. Execute optimization solver (HiGHS)
6. Extract capacities, dispatch, and performance metrics
7. Export results to CSV and return structured outputs

EXECUTION FLOW
--------------
Typical workflow:

1. Load aggregated demand from URBANopt CSV outputs
2. (Optional) Truncate time horizon for faster solving
3. Compute PV capacity factor using EPW weather data
4. Build weak-grid availability profile (if enabled)
5. Parse DER case configuration from UI input
6. Construct PyPSA network model
7. Run optimization solver
8. Extract key results (capacities, objective, metrics)
9. Export results (optional)
10. Return structured dictionary for UI / API use

TYPICAL CALLER
--------------
- Platform UI (DER tab)
- Batch scenario evaluation scripts
- Automated optimization pipelines

IMPORTANT NOTES
---------------
- Load input is expected in kW
- PV capacity factor is normalized between [0,1]
- Weak-grid scenarios simulate outages using availability profiles
- Optimization uses HiGHS solver with controlled threading for stability
- Time horizon may be truncated (default: 168 hours) for fast testing
"""

from __future__ import annotations


# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from pathlib import Path
from typing import Any, Callable


# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import pandas as pd


# ---------------------------------------------------------------------
# Internal module imports
# ---------------------------------------------------------------------

from col.platform.cores.der_optimization.pypsa.model_microgrid_option import (
    TechCosts,
    build_microgrid_network,
    case_from_ui_option,
)
from col.platform.cores.der_optimization.pypsa.pv_from_epw import (
    pv_cf_from_project,
)


# ---------------------------------------------------------------------
# Aggregate load from URBANopt CSV outputs
# ---------------------------------------------------------------------
# Reads all building-level CSV reports and aggregates them into a single
# total load time series.
#
# Expected structure:
#   <project_path>/run/<scenario>/<building_id>/025_default_feature_reports/default_feature_reports.csv
#
# Returns:
#   pandas Series (kW) indexed by DatetimeIndex
# ---------------------------------------------------------------------


def aggregate_load_from_csv(project_path: Path, scenario: str) -> pd.Series:
    scenario_path = project_path / "run" / scenario

    if not scenario_path.exists():
        raise RuntimeError(f"Scenario not found: {scenario_path}")

    # Identify all building folders inside the scenario
    building_dirs = [p for p in scenario_path.iterdir() if p.is_dir()]
    if not building_dirs:
        raise RuntimeError("No building folders found")

    total_series = None

    for bldg in building_dirs:
        report_dir = bldg / "025_default_feature_reports"
        csv_path = report_dir / "default_feature_reports.csv"

        # Skip buildings with missing reports
        if not csv_path.exists():
            print(f"[WARN] Missing CSV, skipping: {csv_path}")
            continue

        df = pd.read_csv(csv_path)

        # Validate required columns
        if "Datetime" not in df.columns:
            raise RuntimeError(f"'Datetime' column missing in {csv_path}")

        if "Electricity:Facility Power(kW)" not in df.columns:
            continue

        # Convert datetime safely
        df["Datetime"] = pd.to_datetime(df["Datetime"], errors="coerce")
        if df["Datetime"].isna().any():
            raise RuntimeError(f"Invalid datetime values in {csv_path}")

        df = df.set_index("Datetime")

        # Convert load values to numeric
        series = pd.to_numeric(
            df["Electricity:Facility Power(kW)"], errors="coerce"
        ).fillna(0.0)

        # Aggregate across buildings
        if total_series is None:
            total_series = series.copy()
        else:
            total_series = total_series.add(series, fill_value=0.0)

    if total_series is None:
        raise RuntimeError("No valid load data found (no CSVs read)")

    if not isinstance(total_series.index, pd.DatetimeIndex):
        raise RuntimeError("Final aggregated series has no valid DatetimeIndex")

    return total_series.sort_index()


# ---------------------------------------------------------------------
# Weak-grid availability profile generator
# ---------------------------------------------------------------------
# Creates a time-series representing grid availability:
#   1.0 → grid available
#   0.0 → grid outage
#
# Outages repeat daily with configurable start hour and duration.
# ---------------------------------------------------------------------


def _weak_grid_profile(
    snapshots: pd.DatetimeIndex,
    *,
    outage_start_hour: int,
    outage_hours_per_day: int,
    outage_start_date: pd.Timestamp | None = None,
) -> pd.Series:
    s = pd.Series(1.0, index=snapshots)

    if len(s) == 0:
        return s

    # Clamp inputs to valid ranges
    outage_start_hour = int(max(0, min(23, outage_start_hour)))
    outage_hours_per_day = int(max(0, min(24, outage_hours_per_day)))

    if outage_hours_per_day == 0:
        return s

    start_date_norm = None
    if outage_start_date is not None:
        start_date_norm = pd.Timestamp(outage_start_date).normalize()

    # Apply outage pattern per day
    by_day = s.groupby(s.index.normalize())

    for day, idx in by_day.groups.items():
        day_ts = pd.Timestamp(day)

        # Skip days before outage start date
        if start_date_norm is not None and day_ts < start_date_norm:
            continue

        day_hours = s.loc[idx].index

        start = outage_start_hour
        end = outage_start_hour + outage_hours_per_day
        outage_hours = [(h % 24) for h in range(start, end)]

        mask = day_hours.hour.isin(outage_hours)
        s.loc[day_hours[mask]] = 0.0

    return s


# ---------------------------------------------------------------------
# Export optimization results to CSV
# ---------------------------------------------------------------------
# Extracts:
# - capacities (generators + storage)
# - dispatch time series
# - state of charge (battery)
# - load profile
# - key performance metrics
#
# Returns dictionary of file paths
# ---------------------------------------------------------------------


def export_results_option(
    n,
    out_dir: Path,
    case_name: str,
    *,
    plot_start: pd.Timestamp | None = None,
    plot_days: int = 7,
) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)

    caps = pd.DataFrame(index=[])

    # Extract generator capacities
    if hasattr(n, "generators") and len(n.generators.index) > 0:
        caps = pd.concat(
            [
                caps,
                n.generators[["p_nom_opt"]].rename(
                    columns={"p_nom_opt": "p_nom_opt_MW"}
                ),
            ],
            axis=0,
        )

    # Extract storage capacities
    if hasattr(n, "storage_units") and len(n.storage_units.index) > 0:
        batt_caps = n.storage_units[["p_nom_opt", "max_hours"]].copy()
        batt_caps["e_nom_opt_MWh"] = batt_caps["p_nom_opt"] * batt_caps["max_hours"]
        batt_caps = batt_caps.rename(columns={"p_nom_opt": "p_nom_opt_MW"})
        caps = pd.concat([caps, batt_caps], axis=0)

    caps_path = out_dir / f"{case_name}_capacities.csv"
    caps.to_csv(caps_path)

    # Generator dispatch
    gen_dispatch_path = None
    if hasattr(n, "generators_t") and hasattr(n.generators_t, "p"):
        if len(getattr(n.generators_t.p, "columns", [])) > 0:
            gen_dispatch_path = out_dir / f"{case_name}_dispatch_generators_MW.csv"
            n.generators_t.p.to_csv(gen_dispatch_path)

    # Storage dispatch
    storage_dispatch_path = None
    if hasattr(n, "storage_units_t") and hasattr(n.storage_units_t, "p"):
        if len(getattr(n.storage_units_t.p, "columns", [])) > 0:
            storage_dispatch_path = out_dir / f"{case_name}_dispatch_storage_MW.csv"
            n.storage_units_t.p.to_csv(storage_dispatch_path)

    # Battery SOC
    soc_path = None
    if hasattr(n, "storage_units_t") and hasattr(n.storage_units_t, "state_of_charge"):
        if len(getattr(n.storage_units_t.state_of_charge, "columns", [])) > 0:
            soc_path = out_dir / f"{case_name}_battery_soc_MWh.csv"
            n.storage_units_t.state_of_charge.to_csv(soc_path)

    # Load
    load_path = None
    if hasattr(n, "loads_t") and hasattr(n.loads_t, "p_set"):
        if "load" in n.loads_t.p_set.columns:
            load_path = out_dir / f"{case_name}_load_MW.csv"
            n.loads_t.p_set[["load"]].to_csv(load_path)

    # Metrics
    load_mwh = (
        float(n.loads_t.p_set.sum(axis=1).sum()) if hasattr(n, "loads_t") else 0.0
    )
    obj = float(n.objective) if hasattr(n, "objective") else float("nan")

    metrics = {
        "case": case_name,
        "objective_$": obj,
        "total_load_MWh": load_mwh,
        "LCOE_$_per_MWh": (obj / load_mwh) if load_mwh > 0 else None,
    }

    metrics_path = out_dir / f"{case_name}_metrics.csv"
    pd.DataFrame([metrics]).to_csv(metrics_path, index=False)

    return {
        "out_dir": str(out_dir),
        "capacities_csv": str(caps_path),
        "metrics_csv": str(metrics_path),
        "dispatch_generators_csv": str(gen_dispatch_path)
        if gen_dispatch_path
        else None,
        "dispatch_storage_csv": str(storage_dispatch_path)
        if storage_dispatch_path
        else None,
        "soc_csv": str(soc_path) if soc_path else None,
        "load_csv": str(load_path) if load_path else None,
    }


# ---------------------------------------------------------------------
# MAIN RUNNER FUNCTION
# ---------------------------------------------------------------------
# Executes full DER optimization pipeline
# ---------------------------------------------------------------------


def run_der_optimization_option(
    *,
    project_path: Path,
    scenario_stem: str,
    der_case_name: str,
    battery_hours: float = 4.0,
    grid_import_limit_kw: float | None = None,
    pv_tilt: float | None = None,
    pv_azimuth: float = 180.0,
    costs: TechCosts | None = None,
    cb_status: Callable[[float, str], None] | None = None,
    cb_detail: Callable[[str], None] | None = None,
    export_dir: Path | None = None,
    return_timeseries: bool = False,
    outage_start_hour: int = 0,
    outage_hours_per_day: int = 4,
    outage_start_date: pd.Timestamp | None = None,
    plot_start: pd.Timestamp | None = None,
    plot_days: int = 7,
) -> dict[str, Any]:
    # ------------------------------------------------------------------
    # Internal helper callbacks (UI progress reporting)
    # ------------------------------------------------------------------

    def status(p: float, t: str) -> None:
        if cb_status:
            try:
                cb_status(p, t)
            except Exception:
                pass

    def detail(t: str) -> None:
        if cb_detail:
            try:
                cb_detail(t)
            except Exception:
                pass

    # Validate required inputs
    if not scenario_stem:
        raise ValueError("scenario_stem is required")

    if not der_case_name:
        raise ValueError("der_case_name is required")

    # ------------------------------------------------------------------
    # STEP 1: Load aggregation
    # ------------------------------------------------------------------

    status(0.05, "Reading aggregated load from CSV reports")

    load_kw = aggregate_load_from_csv(
        project_path=project_path,
        scenario=scenario_stem,
    )

    # Optional truncation for fast testing
    MAX_HOURS = 168
    if len(load_kw) > MAX_HOURS:
        load_kw = load_kw.iloc[:MAX_HOURS]
        detail(f"Load truncated to {MAX_HOURS} hours for fast solve")

    # Logging statistics
    detail(f"Peak load: {float(load_kw.max()):.2f} kW")
    detail(f"Mean load: {float(load_kw.mean()):.2f} kW")
    detail(f"Timestep count: {len(load_kw)}")

    # ------------------------------------------------------------------
    # STEP 2: PV capacity factor
    # ------------------------------------------------------------------

    status(0.25, "Computing PV capacity factor from EPW")

    pv_cf, pv_debug = pv_cf_from_project(
        project_path=project_path,
        snapshots=load_kw.index,
        tilt=pv_tilt,
        azimuth=pv_azimuth,
        return_debug=True,
    )

    # ------------------------------------------------------------------
    # STEP 3: Weak grid configuration
    # ------------------------------------------------------------------

    grid_available_pu = None
    weakgrid_enabled = der_case_name.strip().lower().endswith("+weakgrid")

    if weakgrid_enabled:
        od = (
            pd.Timestamp(outage_start_date).normalize()
            if outage_start_date is not None
            else None
        )
        grid_available_pu = _weak_grid_profile(
            load_kw.index,
            outage_start_hour=int(outage_start_hour),
            outage_hours_per_day=int(outage_hours_per_day),
            outage_start_date=od,
        )

    # ------------------------------------------------------------------
    # STEP 4: Build network
    # ------------------------------------------------------------------

    status(0.45, "Building PyPSA network")

    costs = costs or TechCosts()

    case = case_from_ui_option(
        der_case_name,
        grid_import_limit_kw=grid_import_limit_kw,
        grid_available_pu=grid_available_pu,
    )

    n = build_microgrid_network(
        load_kw=load_kw,
        pv_cf=pv_cf,
        costs=costs,
        case=case,
        battery_hours=battery_hours,
    )

    # ------------------------------------------------------------------
    # STEP 5: Solve optimization
    # ------------------------------------------------------------------

    status(0.75, "Solving PyPSA optimization")

    n.optimize(
        solver_name="highs",
        solver_options={
            "time_limit": 120,
            "output_flag": False,
            "presolve": "on",
            "threads": 1,
            "parallel": "off",
            "simplex_max_concurrency": 1,
        },
    )

    # ------------------------------------------------------------------
    # STEP 6: Extract results
    # ------------------------------------------------------------------

    status(0.90, "Preparing summary")

    pv_kw = (
        float(n.generators.loc["pv", "p_nom_opt"]) * 1000.0
        if "pv" in n.generators.index
        else 0.0
    )
    diesel_kw = (
        float(n.generators.loc["diesel", "p_nom_opt"]) * 1000.0
        if "diesel" in n.generators.index
        else 0.0
    )
    batt_kw = (
        float(n.storage_units.loc["battery", "p_nom_opt"]) * 1000.0
        if "battery" in n.storage_units.index
        else 0.0
    )
    obj = float(n.objective)

    # ------------------------------------------------------------------
    # STEP 7: Export (optional)
    # ------------------------------------------------------------------

    export = None
    if export_dir:
        export = export_results_option(
            n,
            Path(export_dir),
            case.name,
        )

    status(1.0, "DER optimization complete")

    # ------------------------------------------------------------------
    # Final output structure
    # ------------------------------------------------------------------

    result = {
        "objective": obj,
        "pv_kw": pv_kw,
        "battery_kw": batt_kw,
        "diesel_kw": diesel_kw,
        "der_case": case.name,
        "pv_debug": pv_debug,
        "export": export,
    }

    if return_timeseries:
        result["timeseries"] = {
            "load_index_start": str(load_kw.index.min()) if len(load_kw) else None,
            "load_index_end": str(load_kw.index.max()) if len(load_kw) else None,
        }

    return result
