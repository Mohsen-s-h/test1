# src/col/platform/cores/der_optimization/pypsa/pypsa_ui_panel.py

"""
PyPSA DER Optimization UI Panel
-------------------------------

Purpose
-------
This module contains the full PyPSA-specific DER optimization UI panel logic
used by the DER Optimization tab.

Responsibilities
----------------
1. Read available load-forecasting runs from the active project workspace
2. Let the user configure DER optimization inputs
3. Launch the DER optimization core through the orchestration boundary
4. Stream status and detail messages back into the UI through a queue
5. Let the user explicitly inspect existing DER result folders
6. Let the user explicitly generate a static DER result plot

Design Note
-----------
This module is an intermediate refactor target that moves the heavy PyPSA UI
implementation out of the top-level tab module so the tab layer remains thin,
clean, and easier to maintain.

Important Design Rule
---------------------
This module must never auto-load DER summary CSVs or auto-generate DER plots
immediately after solver completion. That work is explicit and user-triggered.

Debug Philosophy
----------------
This module emits structured terminal traces so that backend progress can be
correlated with frontend disconnects or websocket loss.
"""

from __future__ import annotations

# =============================================================================
# IMPORTS
# =============================================================================

# Standard library imports
import json
import traceback
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from queue import Empty, Queue
from typing import Any

# Third-party imports
import pandas as pd
import plotly.graph_objects as go
from nicegui import app, run, ui

# =============================================================================
# DEBUG CONFIGURATION
# =============================================================================

DEBUG_PREFIX = "[DER_UI]"
MAX_LOG_LINES = 200
MAX_LOG_CHARS = 20000


# =============================================================================
# DEBUG HELPERS
# =============================================================================


def _safe_repr(value: Any, max_len: int = 240) -> str:
    """Return a shortened repr for stable terminal diagnostics."""
    try:
        text = repr(value)
    except Exception:
        text = f"<unreprable:{type(value).__name__}>"

    if len(text) > max_len:
        return text[:max_len] + "...<truncated>"
    return text


def _dbg(tag: str, **kwargs: Any) -> None:
    """
    Structured terminal debug printer.

    Example
    -------
    [DER_UI] 2026-03-20 13:18:17.123 RUN_START | project='20260317_152820' | case='pv+battery'
    """
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    if kwargs:
        payload = " | ".join(f"{k}={_safe_repr(v)}" for k, v in kwargs.items())
        print(f"{DEBUG_PREFIX} {ts} {tag} | {payload}", flush=True)
    else:
        print(f"{DEBUG_PREFIX} {ts} {tag}", flush=True)


def _qsize_safe(q: Queue[Any]) -> int | str:
    """Best-effort queue size for diagnostics."""
    try:
        return q.qsize()
    except Exception:
        return "unknown"


# =============================================================================
# FILE / DATA HELPERS
# =============================================================================


def _read_csv_ts(path: str | Path) -> pd.DataFrame:
    """
    Read a time-series CSV using the first column as datetime index.

    Returns
    -------
    pd.DataFrame
        DataFrame with cleaned DatetimeIndex.
    """
    p = Path(path)
    _dbg("READ_CSV_ENTER", path=str(p))

    if not p.exists():
        _dbg("READ_CSV_MISSING", path=str(p))
        raise FileNotFoundError(str(p))

    df = pd.read_csv(p, index_col=0)
    _dbg(
        "READ_CSV_RAW",
        path=str(p),
        rows=len(df),
        cols=list(df.columns),
    )

    df.index = pd.to_datetime(df.index, errors="coerce")
    invalid_count = int(df.index.isna().sum())
    if invalid_count:
        _dbg("READ_CSV_INVALID_INDEX", path=str(p), invalid_count=invalid_count)

    df = df[~df.index.isna()]

    _dbg(
        "READ_CSV_DONE",
        path=str(p),
        rows=len(df),
        min_index=str(df.index.min()) if not df.empty else None,
        max_index=str(df.index.max()) if not df.empty else None,
    )
    return df


def list_load_forecasting_runs(root: Path) -> list[str]:
    """
    Return valid load forecasting timestamp folders that contain at least one
    URBANopt project folder whose name starts with 'uo_'.
    """
    _dbg("LIST_LF_RUNS_ENTER", root=str(root))

    if not root.exists():
        _dbg("LIST_LF_RUNS_ROOT_MISSING", root=str(root))
        return []

    results: list[str] = []

    for ts_dir in root.iterdir():
        if not ts_dir.is_dir():
            continue

        if any(p.is_dir() and p.name.startswith("uo_") for p in ts_dir.iterdir()):
            results.append(ts_dir.name)

    results = sorted(results)
    _dbg("LIST_LF_RUNS_DONE", count=len(results), runs=results)
    return results


def list_der_result_runs(root: Path) -> list[str]:
    """Return DER result run folders."""
    _dbg("LIST_DER_RUNS_ENTER", root=str(root))

    if not root.exists():
        _dbg("LIST_DER_RUNS_ROOT_MISSING", root=str(root))
        return []

    runs = sorted([p.name for p in root.iterdir() if p.is_dir()])
    _dbg("LIST_DER_RUNS_DONE", count=len(runs), runs=runs)
    return runs


def _find_latest_uo_project(ts_folder: Path) -> Path | None:
    """Return the most recently modified uo_* project folder under a timestamp folder."""
    _dbg("FIND_LATEST_UO_ENTER", ts_folder=str(ts_folder))

    if not ts_folder.exists():
        _dbg("FIND_LATEST_UO_TS_MISSING", ts_folder=str(ts_folder))
        return None

    uo_folders = [
        p for p in ts_folder.iterdir() if p.is_dir() and p.name.startswith("uo_")
    ]

    if not uo_folders:
        _dbg("FIND_LATEST_UO_NONE", ts_folder=str(ts_folder))
        return None

    latest = sorted(uo_folders, key=lambda p: p.stat().st_mtime, reverse=True)[0]
    _dbg("FIND_LATEST_UO_DONE", latest=str(latest))
    return latest


def _find_first_scenario_name(project_path: Path) -> str | None:
    """Return the first scenario folder name under <project>/run."""
    _dbg("FIND_FIRST_SCENARIO_ENTER", project_path=str(project_path))

    run_dir = project_path / "run"
    if not run_dir.exists():
        _dbg("FIND_FIRST_SCENARIO_RUN_DIR_MISSING", run_dir=str(run_dir))
        return None

    scenarios = sorted([p.name for p in run_dir.iterdir() if p.is_dir()])
    if not scenarios:
        _dbg("FIND_FIRST_SCENARIO_NONE", run_dir=str(run_dir))
        return None

    _dbg("FIND_FIRST_SCENARIO_DONE", scenario=scenarios[0], all_scenarios=scenarios)
    return scenarios[0]


def _get_run_date_range(load_forecasting_ts_folder: Path) -> tuple[str, str] | None:
    """
    Scan the first building report CSV inside the selected load forecasting run
    and return (min_date, max_date).
    """
    _dbg("GET_RUN_DATE_RANGE_ENTER", folder=str(load_forecasting_ts_folder))

    try:
        proj = _find_latest_uo_project(load_forecasting_ts_folder)
        if proj is None:
            _dbg(
                "GET_RUN_DATE_RANGE_NO_PROJECT", folder=str(load_forecasting_ts_folder)
            )
            return None

        run_dir = proj / "run"
        scenarios = [p for p in run_dir.iterdir() if p.is_dir()]
        if not scenarios:
            _dbg("GET_RUN_DATE_RANGE_NO_SCENARIOS", run_dir=str(run_dir))
            return None

        scen = scenarios[0]
        buildings = [p for p in scen.iterdir() if p.is_dir()]
        if not buildings:
            _dbg("GET_RUN_DATE_RANGE_NO_BUILDINGS", scenario=str(scen))
            return None

        sample_csv = (
            buildings[0] / "025_default_feature_reports" / "default_feature_reports.csv"
        )

        if not sample_csv.exists():
            _dbg("GET_RUN_DATE_RANGE_CSV_MISSING", sample_csv=str(sample_csv))
            return None

        df = pd.read_csv(sample_csv)
        if "Datetime" not in df.columns:
            _dbg("GET_RUN_DATE_RANGE_NO_DATETIME_COL", sample_csv=str(sample_csv))
            return None

        dt = pd.to_datetime(df["Datetime"], errors="coerce").dropna()
        if dt.empty:
            _dbg("GET_RUN_DATE_RANGE_EMPTY_DATETIME", sample_csv=str(sample_csv))
            return None

        result = str(dt.min().date()), str(dt.max().date())
        _dbg("GET_RUN_DATE_RANGE_DONE", start=result[0], end=result[1])
        return result

    except Exception as e:
        _dbg(
            "GET_RUN_DATE_RANGE_ERROR", error=repr(e), traceback=traceback.format_exc()
        )
        return None


def _safe_series(df: pd.DataFrame | None, col: str, index: pd.Index) -> pd.Series:
    """Return numeric series aligned to index, or zeros if missing."""
    if df is None:
        _dbg("SAFE_SERIES_DF_NONE", column=col, index_len=len(index))
        return pd.Series(0.0, index=index)

    if col not in getattr(df, "columns", []):
        _dbg("SAFE_SERIES_COL_MISSING", column=col, available=list(df.columns))
        return pd.Series(0.0, index=index)

    series = pd.to_numeric(df[col].reindex(index), errors="coerce").fillna(0.0)
    _dbg("SAFE_SERIES_DONE", column=col, len=len(series))
    return series


# =============================================================================
# STATIC PLOT GENERATION
# =============================================================================


def _build_der_png_file(
    export: dict[str, Any],
    case_name: str,
    output_png: Path,
    start_date: str | None = None,
    start_hour: int = 0,
    days: int = 7,
) -> None:
    """
    Build a static PNG plot using matplotlib.

    Notes
    -----
    - No Plotly is used in this tab.
    - This function is intended to run in a worker thread via run.io_bound(...).
    """
    _dbg(
        "BUILD_DER_PNG_ENTER",
        case_name=case_name,
        output_png=str(output_png),
        start_date=start_date,
        start_hour=start_hour,
        days=days,
    )

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    load_df = _read_csv_ts(export["load_csv"])
    gen_df = (
        _read_csv_ts(export["dispatch_generators_csv"])
        if export.get("dispatch_generators_csv")
        else None
    )
    stor_df = (
        _read_csv_ts(export["dispatch_storage_csv"])
        if export.get("dispatch_storage_csv")
        else None
    )
    soc_df = _read_csv_ts(export["soc_csv"]) if export.get("soc_csv") else None

    idx_min = load_df.index.min()
    idx_max = load_df.index.max()

    if start_date:
        try:
            t0 = pd.Timestamp(start_date) + pd.Timedelta(hours=int(start_hour or 0))
        except Exception as e:
            _dbg("BUILD_DER_PNG_BAD_START_DATE", start_date=start_date, error=repr(e))
            t0 = pd.Timestamp(idx_min)
    else:
        t0 = pd.Timestamp(idx_min)

    t0 = max(pd.Timestamp(idx_min), t0)

    days = max(1, int(days or 1))
    t1 = t0 + pd.Timedelta(days=days)

    if t0 > pd.Timestamp(idx_max):
        _dbg(
            "BUILD_DER_PNG_RESET_WINDOW", requested_start=str(t0), idx_min=str(idx_min)
        )
        t0 = pd.Timestamp(idx_min)
        t1 = t0 + pd.Timedelta(days=days)

    load_df = load_df.loc[(load_df.index >= t0) & (load_df.index < t1)]
    if gen_df is not None:
        gen_df = gen_df.loc[(gen_df.index >= t0) & (gen_df.index < t1)]
    if stor_df is not None:
        stor_df = stor_df.loc[(stor_df.index >= t0) & (stor_df.index < t1)]
    if soc_df is not None:
        soc_df = soc_df.loc[(soc_df.index >= t0) & (soc_df.index < t1)]

    t = load_df.index
    _dbg("BUILD_DER_PNG_WINDOW", t0=str(t0), t1=str(t1), points=len(t))

    load = _safe_series(load_df, "load", t)
    pv = _safe_series(gen_df, "pv", t)
    diesel = _safe_series(gen_df, "diesel", t)
    grid = _safe_series(gen_df, "grid_import", t)
    shed = _safe_series(gen_df, "load_shed", t)

    batt_p = _safe_series(stor_df, "battery", t)
    batt_soc = _safe_series(soc_df, "battery", t)

    batt_dis = batt_p.clip(lower=0.0)
    batt_ch = (-batt_p).clip(lower=0.0)

    fig, ax1 = plt.subplots(figsize=(13, 5.5))
    ax2 = ax1.twinx()

    ax1.plot(t, load, label="load")
    ax1.plot(t, grid, label="grid_import")
    ax1.plot(t, pv, label="pv")
    ax1.plot(t, diesel, label="diesel")
    ax1.plot(t, shed, label="load_shed")
    ax1.plot(t, batt_dis, label="battery_discharge")
    ax1.plot(t, batt_ch, label="battery_charge")

    ax2.plot(t, batt_soc, label="battery_soc", linestyle="--")

    ax1.set_title(
        f"DER dispatch - {case_name} - {t0} to {min(t1, pd.Timestamp(idx_max))}"
    )
    ax1.set_xlabel("Time")
    ax1.set_ylabel("Power (MW)")
    ax2.set_ylabel("Energy (MWh)")
    ax1.grid(True, alpha=0.3)

    lines_1, labels_1 = ax1.get_legend_handles_labels()
    lines_2, labels_2 = ax2.get_legend_handles_labels()
    ax1.legend(lines_1 + lines_2, labels_1 + labels_2, loc="upper center", ncol=4)

    output_png.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(output_png, format="png", dpi=110, bbox_inches="tight")
    plt.close(fig)

    _dbg("BUILD_DER_PNG_DONE", output_png=str(output_png), exists=output_png.exists())


def _build_der_plotly_figure(
    export: dict[str, Any],
    case_name: str,
    start_date: str | None = None,
    start_hour: int = 0,
    days: int = 7,
) -> go.Figure:
    """
    Build an interactive Plotly figure from DER CSV exports.
    """
    _dbg(
        "BUILD_DER_PLOTLY_ENTER",
        case_name=case_name,
        start_date=start_date,
        start_hour=start_hour,
        days=days,
    )

    load_df = _read_csv_ts(export["load_csv"])
    gen_df = (
        _read_csv_ts(export["dispatch_generators_csv"])
        if export.get("dispatch_generators_csv")
        else None
    )
    stor_df = (
        _read_csv_ts(export["dispatch_storage_csv"])
        if export.get("dispatch_storage_csv")
        else None
    )
    soc_df = _read_csv_ts(export["soc_csv"]) if export.get("soc_csv") else None

    idx_min = load_df.index.min()
    idx_max = load_df.index.max()

    if start_date:
        try:
            t0 = pd.Timestamp(start_date) + pd.Timedelta(hours=int(start_hour or 0))
        except Exception as e:
            _dbg(
                "BUILD_DER_PLOTLY_BAD_START_DATE", start_date=start_date, error=repr(e)
            )
            t0 = pd.Timestamp(idx_min)
    else:
        t0 = pd.Timestamp(idx_min)

    t0 = max(pd.Timestamp(idx_min), t0)

    days = max(1, int(days or 1))
    t1 = t0 + pd.Timedelta(days=days)

    if t0 > pd.Timestamp(idx_max):
        _dbg(
            "BUILD_DER_PLOTLY_RESET_WINDOW",
            requested_start=str(t0),
            idx_min=str(idx_min),
        )
        t0 = pd.Timestamp(idx_min)
        t1 = t0 + pd.Timedelta(days=days)

    load_df = load_df.loc[(load_df.index >= t0) & (load_df.index < t1)]
    if gen_df is not None:
        gen_df = gen_df.loc[(gen_df.index >= t0) & (gen_df.index < t1)]
    if stor_df is not None:
        stor_df = stor_df.loc[(stor_df.index >= t0) & (stor_df.index < t1)]
    if soc_df is not None:
        soc_df = soc_df.loc[(soc_df.index >= t0) & (soc_df.index < t1)]

    t = load_df.index
    _dbg("BUILD_DER_PLOTLY_WINDOW", t0=str(t0), t1=str(t1), points=len(t))

    load = _safe_series(load_df, "load", t)
    pv = _safe_series(gen_df, "pv", t)
    diesel = _safe_series(gen_df, "diesel", t)
    grid = _safe_series(gen_df, "grid_import", t)
    shed = _safe_series(gen_df, "load_shed", t)

    batt_p = _safe_series(stor_df, "battery", t)
    batt_soc = _safe_series(soc_df, "battery", t)

    batt_dis = batt_p.clip(lower=0.0)
    batt_ch = (-batt_p).clip(lower=0.0)

    fig = go.Figure()

    fig.add_trace(go.Scatter(x=t, y=load, mode="lines", name="load", yaxis="y1"))
    fig.add_trace(go.Scatter(x=t, y=grid, mode="lines", name="grid_import", yaxis="y1"))
    fig.add_trace(go.Scatter(x=t, y=pv, mode="lines", name="pv", yaxis="y1"))
    fig.add_trace(go.Scatter(x=t, y=diesel, mode="lines", name="diesel", yaxis="y1"))
    fig.add_trace(go.Scatter(x=t, y=shed, mode="lines", name="load_shed", yaxis="y1"))
    fig.add_trace(
        go.Scatter(x=t, y=batt_dis, mode="lines", name="battery_discharge", yaxis="y1")
    )
    fig.add_trace(
        go.Scatter(x=t, y=batt_ch, mode="lines", name="battery_charge", yaxis="y1")
    )

    fig.add_trace(
        go.Scatter(
            x=t,
            y=batt_soc,
            mode="lines",
            name="battery_soc",
            yaxis="y2",
            line=dict(dash="dash"),
        )
    )

    fig.update_layout(
        title=f"DER dispatch - {case_name} - {t0} to {min(t1, pd.Timestamp(idx_max))}",
        xaxis=dict(title="Time"),
        yaxis=dict(title="Power (MW)"),
        yaxis2=dict(
            title="Energy (MWh)",
            overlaying="y",
            side="right",
        ),
        legend=dict(orientation="h"),
        margin=dict(l=40, r=40, t=60, b=40),
        height=520,
        template="plotly_white",
    )

    _dbg("BUILD_DER_PLOTLY_DONE", traces=len(fig.data))
    return fig


# =============================================================================
# DER RESULT FOLDER SCAN / SUMMARY
# =============================================================================


def _load_der_export_from_result_folder(
    der_run_dir: Path,
) -> tuple[str | None, dict[str, Any] | None]:
    """
    Build export dictionary from an existing DER result folder by scanning files.
    """
    _dbg("LOAD_EXPORT_FROM_RUN_DIR_ENTER", der_run_dir=str(der_run_dir))

    if not der_run_dir.exists():
        _dbg("LOAD_EXPORT_FROM_RUN_DIR_MISSING", der_run_dir=str(der_run_dir))
        return None, None

    run_config_path = der_run_dir / "run_config.json"
    case_name = None

    if run_config_path.exists():
        try:
            with open(run_config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            case_name = cfg.get("der_case")
            _dbg("LOAD_EXPORT_FROM_RUN_DIR_CASE_FROM_CONFIG", case_name=case_name)
        except Exception as e:
            _dbg("LOAD_EXPORT_FROM_RUN_DIR_CONFIG_ERROR", error=repr(e))
            case_name = None

    load_csv = None
    gen_csv = None
    stor_csv = None
    soc_csv = None

    for p in der_run_dir.glob("*.csv"):
        name = p.name.lower()

        if name.endswith("_load_mw.csv"):
            load_csv = str(p)
        elif "dispatch_generators" in name:
            gen_csv = str(p)
        elif "dispatch_storage" in name:
            stor_csv = str(p)
        elif "battery_soc" in name:
            soc_csv = str(p)

    if load_csv is None:
        _dbg("LOAD_EXPORT_FROM_RUN_DIR_NO_LOAD_CSV", der_run_dir=str(der_run_dir))
        return case_name, None

    export = {
        "out_dir": str(der_run_dir),
        "load_csv": load_csv,
        "dispatch_generators_csv": gen_csv,
        "dispatch_storage_csv": stor_csv,
        "soc_csv": soc_csv,
    }

    _dbg("LOAD_EXPORT_FROM_RUN_DIR_DONE", case_name=case_name, export=export)
    return case_name, export


def _build_der_result_summary(der_run_dir: Path) -> str:
    """
    Build a human-readable DER result summary text from a result folder.
    """
    _dbg("BUILD_SUMMARY_ENTER", der_run_dir=str(der_run_dir))

    lines: list[str] = [f"DER result folder: {der_run_dir}"]

    run_config_path = der_run_dir / "run_config.json"
    if run_config_path.exists():
        try:
            with open(run_config_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)

            lines.append("")
            lines.append("Run configuration")
            lines.append(f"Scenario: {cfg.get('scenario', '')}")
            lines.append(f"DER case: {cfg.get('der_case', '')}")
            lines.append(f"Battery hours: {cfg.get('battery_hours', '')}")
            lines.append(
                f"Grid import limit (kW): {cfg.get('grid_import_limit_kw', '')}"
            )
            lines.append(f"Weak-grid enabled: {cfg.get('weakgrid_enabled', '')}")
            lines.append(f"Outage start date: {cfg.get('outage_start_date', '')}")
            lines.append(f"Outage start hour: {cfg.get('outage_start_hour', '')}")
            lines.append(f"Outage hours/day: {cfg.get('outage_hours', '')}")

        except Exception as e:
            _dbg(
                "BUILD_SUMMARY_CONFIG_ERROR",
                error=repr(e),
                traceback=traceback.format_exc(),
            )
            lines.append("")
            lines.append(f"Could not read run_config.json: {repr(e)}")
    else:
        lines.append("")
        lines.append("run_config.json not found")

    case_name, export = _load_der_export_from_result_folder(der_run_dir)
    if export is None:
        _dbg("BUILD_SUMMARY_NO_EXPORT", der_run_dir=str(der_run_dir))
        lines.append("")
        lines.append("No DER CSV exports found")
        return "\n".join(lines)

    try:
        load_df = _read_csv_ts(export["load_csv"])

        lines.append("")
        lines.append("Data summary")
        lines.append(f"Case name: {case_name or '(unknown)'}")
        lines.append(f"Time range: {load_df.index.min()} to {load_df.index.max()}")
        lines.append(f"Row count: {len(load_df)}")

        if "load" in load_df.columns:
            s = pd.to_numeric(load_df["load"], errors="coerce").fillna(0.0)
            lines.append(f"Load min (MW): {s.min():.6f}")
            lines.append(f"Load max (MW): {s.max():.6f}")
            lines.append(f"Load mean (MW): {s.mean():.6f}")

        summary_text = "\n".join(lines)
        _dbg("BUILD_SUMMARY_DONE", chars=len(summary_text))
        return summary_text

    except Exception as e:
        _dbg(
            "BUILD_SUMMARY_DATA_ERROR", error=repr(e), traceback=traceback.format_exc()
        )
        lines.append("")
        lines.append(f"Could not read DER CSV summary: {repr(e)}")
        return "\n".join(lines)


# =============================================================================
# PUBLIC PANEL RENDERER
# =============================================================================


def render_der_optimization_pypsa_panel() -> None:
    """
    Render the PyPSA panel for DER optimization.

    Notes
    -----
    This function owns:
    - input widgets
    - status widgets
    - queue/timer update mechanism
    - explicit result summary loading
    - explicit static plot generation
    """
    _dbg("TAB_RENDER_ENTER")

    # -------------------------------------------------------------------------
    # STATE
    # -------------------------------------------------------------------------
    tab = app.storage.tab
    q: Queue[dict[str, Any]] = Queue()

    last_der_export: dict[str, Any] | None = None
    last_der_case_name: str | None = None
    last_der_run_dir: Path | None = None

    log_lines: list[str] = []

    active = app.storage.tab.get("active_project")
    _dbg("ACTIVE_PROJECT", active=active)

    if not active or not active.get("workspace_path"):
        _dbg("ACTIVE_PROJECT_MISSING")
        ui.notify("No active project. Please load a project first.", color="negative")
        return

    workspace = Path(active["workspace_path"])
    lf_runs_root = workspace / "load_forecasting" / "residential" / "runs"
    lf_runs_root.mkdir(parents=True, exist_ok=True)

    der_runs_root = workspace / "der_optimization" / "residential" / "runs"
    der_runs_root.mkdir(parents=True, exist_ok=True)

    _dbg(
        "WORKSPACE_PATHS",
        workspace=str(workspace),
        lf_runs_root=str(lf_runs_root),
        der_runs_root=str(der_runs_root),
    )

    # -------------------------------------------------------------------------
    # INPUTS
    # -------------------------------------------------------------------------
    ui.markdown("### PyPSA")
    ui.markdown("### Forecasting model input (from URBANopt runs)")

    ui.label(f"Load forecasting runs root: {lf_runs_root}").classes(
        "text-xs text-slate-600 break-all"
    )

    project_select = ui.select(
        [],
        label="Select load forecasting run (timestamp)",
        value=None,
    ).classes("w-full")

    selected_run_label = ui.label("Selected: None").classes("text-sm text-blue-700")

    with ui.row().classes("gap-2"):
        btn_clear_selection = ui.button("Clear selection", color="warning")
        btn_refresh_runs = ui.button("Refresh load forecasting runs", color="secondary")

    saved_der = tab.get("inputs_der")
    _dbg("RESTORE_INPUTS_RAW", saved_der=saved_der)

    ui.separator()
    ui.markdown("### DER optimization scenario")

    der_case_base = ui.select(
        ["pv", "pv+battery", "pv+battery+diesel"],
        label="DER scenario (base)",
        value="pv+battery",
    ).classes("w-full")

    enable_weakgrid = ui.checkbox(
        "Enable weak-grid constraints (user-controlled)"
    ).classes("w-full")

    battery_hours = ui.number(
        "Battery hours",
        value=4.0,
        min=1.0,
        step=1.0,
    ).classes("w-full")

    grid_import_limit_kw = ui.number(
        "Grid import limit (kW) (blank = unlimited)",
        value=None,
        step=100,
    ).classes("w-full")

    ui.separator()
    ui.markdown("### Weak-grid timing (only used if weak-grid is enabled)")

    weak_outage_start_date = ui.input(label="Outage start date (YYYY-MM-DD)").classes(
        "w-full"
    )
    weak_outage_start_date.value = ""

    weak_outage_start_hour = ui.number(
        "Outage start hour (0-23)",
        value=0,
        min=0,
        max=23,
        step=1,
    ).classes("w-full")

    weak_outage_hours = ui.number(
        "Outage duration (hours/day)",
        value=4,
        min=0,
        max=24,
        step=1,
    ).classes("w-full")

    ui.separator()
    ui.markdown("### Tech / economic inputs")

    pv_capex = ui.number("PV capex ($/kW-year)", value=120.0, step=10).classes("w-full")
    batt_power_capex = ui.number(
        "Battery power capex ($/kW-year)", value=450.0, step=25
    ).classes("w-full")
    batt_energy_capex = ui.number(
        "Battery energy capex ($/kWh-year)", value=200.0, step=10
    ).classes("w-full")
    diesel_capex = ui.number("Diesel capex ($/kW-year)", value=350.0, step=25).classes(
        "w-full"
    )
    grid_price = ui.number("Grid price ($/kWh)", value=0.12, step=0.01).classes(
        "w-full"
    )
    diesel_fuel = ui.number("Diesel fuel cost ($/kWh)", value=0.45, step=0.01).classes(
        "w-full"
    )
    batt_marg = ui.number("Battery marginal ($/kWh)", value=0.005, step=0.001).classes(
        "w-full"
    )
    load_shed_cost = ui.number(
        "Load shedding penalty ($/kWh)", value=10.0, step=1.0
    ).classes("w-full")

    # -------------------------------------------------------------------------
    # STATUS + LOG
    # -------------------------------------------------------------------------
    ui.separator()

    with ui.card().classes("w-full mt-2 max-w-full"):
        ui.markdown("## Status")

        status_text = ui.label("Ready").classes("text-base")

        progress = ui.linear_progress(value=0.0).classes("w-full")
        progress.set_visibility(False)

        details = ui.expansion("Details (click to open)", icon="info").classes("w-full")
        with details:
            detail_box = (
                ui.textarea("Log (last lines)", value="")
                .classes("w-full")
                .props("rows=12 outlined readonly")
            )

    # -------------------------------------------------------------------------
    # EXISTING RESULTS + EXPLICIT STATIC PLOT
    # -------------------------------------------------------------------------
    with ui.card().classes("w-full mt-4 max-w-full"):
        ui.markdown("## Existing DER results")
        ui.markdown("### No automatic plotting in this tab")

        der_result_select = ui.select(
            [],
            label="Select DER result run folder",
            value=None,
        ).classes("w-full")

        with ui.row().classes("w-full gap-3"):
            btn_refresh_der_results = ui.button(
                "Refresh DER result folders", color="secondary"
            )
            btn_load_der_summary = ui.button(
                "Load selected DER result summary", color="primary"
            )

        der_result_summary = (
            ui.textarea(
                "Selected DER result summary",
                value="",
            )
            .classes("w-full")
            .props("rows=12 outlined readonly")
        )

        ui.separator()
        ui.markdown("### Static plot from selected DER result")

        with ui.row().classes("w-full items-end gap-3"):
            der_plot_start_date = ui.input(
                label="Plot start date (YYYY-MM-DD)"
            ).classes("w-full")
            der_plot_start_date.value = ""

            der_plot_start_hour = ui.number(
                "Start hour (0-23)",
                value=0,
                min=0,
                max=23,
                step=1,
            ).classes("w-40")

            der_plot_days = ui.number(
                "Days",
                value=7,
                min=1,
                step=1,
            ).classes("w-40")

            btn_generate_plot = ui.button("Generate selected DER plot", color="primary")

        der_plot_hint = ui.label("").classes("text-xs text-gray-600")
        der_plot_status = ui.label("Plot status: idle").classes("text-xs text-gray-600")

        der_plotly = ui.plotly(go.Figure()).classes("w-full")
        der_plotly.set_visibility(False)

        # Keep old image widget logic commented for fallback/debug
        # der_plot_image = ui.image().classes("w-full max-w-full")
        # der_plot_image.set_visibility(False)

    run_button = ui.button(
        "RUN DER Optimization Core",
        color="primary",
    ).classes("w-full mt-4")

    # -------------------------------------------------------------------------
    # UI HELPERS
    # -------------------------------------------------------------------------
    def ui_set_status(text: str) -> None:
        _dbg("UI_SET_STATUS", text=text)
        status_text.text = text

    def _render_log() -> None:
        text = "\n".join(log_lines)
        if len(text) > MAX_LOG_CHARS:
            text = text[-MAX_LOG_CHARS:]
        detail_box.value = text

    def ui_append_detail_lines(messages: list[str]) -> None:
        _dbg("UI_APPEND_DETAIL_LINES_ENTER", count=len(messages))
        for msg in messages:
            text = str(msg).replace("\r\n", "\n").replace("\r", "\n")
            parts = text.split("\n")
            for part in parts:
                if part == "":
                    continue
                log_lines.append(part)

        if len(log_lines) > MAX_LOG_LINES:
            del log_lines[:-MAX_LOG_LINES]

        _render_log()
        _dbg("UI_APPEND_DETAIL_LINES_DONE", total_lines=len(log_lines))

    def clear_detail_log() -> None:
        _dbg("CLEAR_DETAIL_LOG")
        log_lines.clear()
        detail_box.value = ""

    def clear_static_plot() -> None:
        _dbg("CLEAR_STATIC_PLOT")

        der_plotly.figure = go.Figure()
        der_plotly.update()
        der_plotly.set_visibility(False)

        # Old image fallback kept commented
        # der_plot_image.source = ""
        # der_plot_image.set_visibility(False)

        der_plot_status.text = "Plot status: idle"

    def update_selected_label() -> None:
        if project_select.value:
            selected_run_label.text = f"Selected: {project_select.value}"
        else:
            selected_run_label.text = "Selected: None"
        _dbg("UPDATE_SELECTED_LABEL", selected=project_select.value)

    def validate_run_button() -> None:
        if project_select.value:
            run_button.enable()
            _dbg("VALIDATE_RUN_BUTTON", enabled=True, project=project_select.value)
        else:
            run_button.disable()
            _dbg("VALIDATE_RUN_BUTTON", enabled=False, project=project_select.value)

    def refresh_plot_date_limits() -> None:
        _dbg("REFRESH_PLOT_DATE_LIMITS_ENTER", project=project_select.value)

        if not project_select.value:
            der_plot_hint.text = ""
            _dbg("REFRESH_PLOT_DATE_LIMITS_NO_PROJECT")
            return

        ts_folder = lf_runs_root / Path(str(project_select.value))
        rng = _get_run_date_range(ts_folder)

        if not rng:
            der_plot_hint.text = "Available dates: unknown"
            _dbg("REFRESH_PLOT_DATE_LIMITS_UNKNOWN")
            return

        min_d, max_d = rng
        der_plot_hint.text = f"Available dates: {min_d} to {max_d}"

        if not weak_outage_start_date.value:
            weak_outage_start_date.value = min_d

        if not der_plot_start_date.value:
            der_plot_start_date.value = min_d

        _dbg(
            "REFRESH_PLOT_DATE_LIMITS_DONE",
            min_date=min_d,
            max_date=max_d,
            weak_outage_start_date=weak_outage_start_date.value,
            der_plot_start_date=der_plot_start_date.value,
        )

    def auto_fill_inputs_from_load() -> None:
        _dbg("AUTO_FILL_INPUTS_ENTER", project=project_select.value)

        if not project_select.value:
            _dbg("AUTO_FILL_INPUTS_NO_PROJECT")
            return

        try:
            ts_folder = lf_runs_root / Path(str(project_select.value))
            proj = _find_latest_uo_project(ts_folder)
            if proj is None:
                _dbg("AUTO_FILL_INPUTS_NO_UO_PROJECT", ts_folder=str(ts_folder))
                return

            scen = _find_first_scenario_name(proj)
            if scen is None:
                _dbg("AUTO_FILL_INPUTS_NO_SCENARIO", project=str(proj))
                return

            from col.platform.cores.der_optimization.pypsa.runner_option import (
                aggregate_load_from_csv,
            )

            load = aggregate_load_from_csv(proj, scen)
            peak = float(load.max())

            grid_import_limit_kw.value = round(peak * 1.2, 1)
            battery_hours.value = 4.0
            pv_capex.value = 120.0
            batt_power_capex.value = 450.0
            batt_energy_capex.value = 200.0

            _dbg(
                "AUTO_FILL_INPUTS_DONE",
                scenario=scen,
                peak_kw=peak,
                grid_import_limit_kw=grid_import_limit_kw.value,
                battery_hours=battery_hours.value,
            )

            ui.notify(
                f"Auto-filled from selected run. Peak load = {peak:.1f} kW",
                color="positive",
            )

        except Exception as e:
            _dbg(
                "AUTO_FILL_INPUTS_ERROR",
                error=repr(e),
                traceback=traceback.format_exc(),
            )

    def refresh_projects() -> None:
        _dbg("REFRESH_PROJECTS_ENTER")
        opts = list_load_forecasting_runs(lf_runs_root)
        project_select.options = opts

        if opts and project_select.value not in opts:
            project_select.value = opts[0]

        update_selected_label()
        refresh_plot_date_limits()
        validate_run_button()

        _dbg(
            "REFRESH_PROJECTS_DONE",
            options=opts,
            selected=project_select.value,
        )

    def on_project_change(e: Any = None) -> None:
        _dbg(
            "ON_PROJECT_CHANGE_ENTER",
            selected=project_select.value,
            event=_safe_repr(e),
        )
        auto_fill_inputs_from_load()
        update_selected_label()
        refresh_plot_date_limits()
        validate_run_button()
        _dbg("ON_PROJECT_CHANGE_DONE", selected=project_select.value)

    def clear_selection() -> None:
        _dbg("CLEAR_SELECTION_ENTER", current=project_select.value)
        project_select.value = None
        update_selected_label()
        refresh_plot_date_limits()
        validate_run_button()
        _dbg("CLEAR_SELECTION_DONE")

    def refresh_der_result_folders() -> None:
        _dbg("REFRESH_DER_RESULT_FOLDERS_ENTER")
        opts = list_der_result_runs(der_runs_root)
        der_result_select.options = opts
        if opts and der_result_select.value not in opts:
            der_result_select.value = opts[-1]

        _dbg(
            "REFRESH_DER_RESULT_FOLDERS_DONE",
            options=opts,
            selected=der_result_select.value,
        )

    def _build_der_result_summary_safe(run_dir: Path) -> str:
        _dbg("BUILD_SUMMARY_SAFE_ENTER", run_dir=str(run_dir))
        try:
            result = _build_der_result_summary(run_dir)
            _dbg("BUILD_SUMMARY_SAFE_DONE", chars=len(result))
            return result
        except BaseException as e:
            _dbg(
                "BUILD_SUMMARY_SAFE_ERROR",
                error=repr(e),
                traceback=traceback.format_exc(),
            )
            return f"Failed to build DER result summary: {type(e).__name__}: {e}"

    async def load_selected_der_summary() -> None:
        _dbg("LOAD_SELECTED_SUMMARY_ENTER", selected=der_result_select.value)

        if not der_result_select.value:
            ui.notify("Select a DER result run folder first", color="warning")
            _dbg("LOAD_SELECTED_SUMMARY_NO_SELECTION")
            return

        der_result_summary.value = "Loading summary..."

        try:
            run_dir = der_runs_root / str(der_result_select.value)
            _dbg("LOAD_SELECTED_SUMMARY_IO_BOUND_START", run_dir=str(run_dir))

            summary = await run.io_bound(_build_der_result_summary_safe, run_dir)

            _dbg("LOAD_SELECTED_SUMMARY_IO_BOUND_DONE", chars=len(summary))
            der_result_summary.value = summary
            _dbg("LOAD_SELECTED_SUMMARY_UI_DONE")

        except Exception as e:
            _dbg(
                "LOAD_SELECTED_SUMMARY_ERROR",
                error=repr(e),
                traceback=traceback.format_exc(),
            )
            der_result_summary.value = f"Failed to load summary: {repr(e)}"

    def _generate_selected_der_plot_data(
        run_dir: Path,
        start_date: str | None,
        start_hour: int,
        days: int,
    ) -> tuple[go.Figure, str, dict[str, Any]]:
        _dbg(
            "GENERATE_PLOT_DATA_ENTER",
            run_dir=str(run_dir),
            start_date=start_date,
            start_hour=start_hour,
            days=days,
        )

        case_name, export = _load_der_export_from_result_folder(run_dir)
        if export is None:
            _dbg("GENERATE_PLOT_DATA_NO_EXPORT", run_dir=str(run_dir))
            raise RuntimeError(f"No DER CSV export files found in {run_dir}")

        fig = _build_der_plotly_figure(
            export=export,
            case_name=case_name or run_dir.name,
            start_date=start_date,
            start_hour=start_hour,
            days=days,
        )

        # Keep old PNG path generation commented, do not delete
        # output_png = run_dir / "selected_der_plot.png"
        # _build_der_png_file(
        #     export=export,
        #     case_name=case_name or run_dir.name,
        #     output_png=output_png,
        #     start_date=start_date,
        #     start_hour=start_hour,
        #     days=days,
        # )

        _dbg("GENERATE_PLOT_DATA_DONE", case_name=case_name or run_dir.name)
        return fig, str(case_name or run_dir.name), export

    async def generate_selected_der_plot() -> None:
        nonlocal last_der_export, last_der_case_name, last_der_run_dir

        _dbg("GENERATE_SELECTED_PLOT_ENTER", selected=der_result_select.value)

        if not der_result_select.value:
            ui.notify("Select a DER result run folder first", color="warning")
            _dbg("GENERATE_SELECTED_PLOT_NO_SELECTION")
            return

        der_plot_status.text = "Generating plot..."
        der_plotly.set_visibility(False)

        # Old image fallback kept commented
        # der_plot_image.set_visibility(False)

        try:
            run_dir = der_runs_root / str(der_result_select.value)
            _dbg("GENERATE_SELECTED_PLOT_IO_BOUND_START", run_dir=str(run_dir))

            fig, case_name, export = await run.io_bound(
                _generate_selected_der_plot_data,
                run_dir,
                (str(der_plot_start_date.value).strip() or None),
                int(der_plot_start_hour.value or 0),
                int(der_plot_days.value or 7),
            )

            _dbg(
                "GENERATE_SELECTED_PLOT_IO_BOUND_DONE",
                case_name=case_name,
                trace_count=len(fig.data),
            )

            der_plotly.figure = fig
            der_plotly.update()
            der_plotly.set_visibility(True)
            der_plot_status.text = f"Plot generated for: {case_name}"

            last_der_export = export
            last_der_case_name = case_name
            last_der_run_dir = run_dir

            _dbg(
                "GENERATE_SELECTED_PLOT_UI_DONE",
                last_der_case_name=last_der_case_name,
                last_der_run_dir=str(last_der_run_dir),
            )

        except Exception as e:
            _dbg(
                "GENERATE_SELECTED_PLOT_ERROR",
                error=repr(e),
                traceback=traceback.format_exc(),
            )
            der_plot_status.text = f"Plot failed: {repr(e)}"

    # -------------------------------------------------------------------------
    # QUEUE DRAIN
    # -------------------------------------------------------------------------
    def drain_queue() -> None:
        """
        Drain queued status/detail/result messages into the UI.

        This callback must remain lightweight and must not auto-load CSV summary
        files or auto-generate plots after solver completion.
        """
        nonlocal last_der_export, last_der_case_name, last_der_run_dir

        detail_batch: list[str] = []
        processed_count = 0

        try:
            for _ in range(100):
                item = q.get_nowait()
                processed_count += 1

                item_type = item.get("type", "unknown")
                _dbg(
                    "DRAIN_QUEUE_ITEM",
                    item_type=item_type,
                    qsize_after_get=_qsize_safe(q),
                )

                if item_type == "status":
                    ui_set_status(str(item["text"]))
                    progress.set_visibility(True)
                    progress.value = float(item["progress"])

                    _dbg(
                        "DRAIN_QUEUE_STATUS_APPLIED",
                        text=item["text"],
                        progress=item["progress"],
                    )

                elif item_type == "detail":
                    detail_batch.append(str(item["text"]))

                elif item_type == "result_der":
                    _dbg("DRAIN_QUEUE_RESULT_RECEIVED", item=item)

                    progress.value = 1.0
                    ui_set_status("DER optimization complete")

                    summary = str(item.get("summary", ""))
                    if summary:
                        detail_batch.append(summary)

                    export = item.get("export")
                    case_name = item.get("der_case")
                    run_dir_str = item.get("out_dir")

                    if isinstance(export, dict) and case_name:
                        last_der_export = export
                        last_der_case_name = str(case_name)

                        if run_dir_str:
                            last_der_run_dir = Path(str(run_dir_str))

                        detail_batch.append("DER export stored successfully.")
                        refresh_der_result_folders()

                        if last_der_run_dir and last_der_run_dir.exists():
                            der_result_select.value = last_der_run_dir.name
                            detail_batch.append(
                                f"DER result folder selected: {last_der_run_dir.name}"
                            )
                            detail_batch.append(
                                "Use 'Load selected DER result summary' to inspect the result."
                            )

                        _dbg(
                            "DRAIN_QUEUE_RESULT_APPLIED",
                            last_der_case_name=last_der_case_name,
                            last_der_run_dir=str(last_der_run_dir)
                            if last_der_run_dir
                            else None,
                            export=last_der_export,
                        )
                    else:
                        detail_batch.append("No export information returned.")
                        _dbg(
                            "DRAIN_QUEUE_RESULT_NO_EXPORT",
                            export=export,
                            case_name=case_name,
                        )

                elif item_type == "error":
                    progress.set_visibility(True)
                    progress.value = float(item.get("progress", 0.0))
                    ui_set_status("ERROR")
                    detail_batch.append(str(item["error"]))

                    _dbg("DRAIN_QUEUE_ERROR_APPLIED", error=item.get("error"))

                else:
                    detail_batch.append(f"Unknown queue item type: {item_type}")
                    _dbg("DRAIN_QUEUE_UNKNOWN_ITEM", item=item)

        except Empty:
            pass
        except Exception as e:
            _dbg(
                "DRAIN_QUEUE_EXCEPTION", error=repr(e), traceback=traceback.format_exc()
            )
            detail_batch.append(f"[DER DRAIN_QUEUE ERROR] {repr(e)}")

        if detail_batch:
            ui_append_detail_lines(detail_batch)

        if processed_count:
            _dbg(
                "DRAIN_QUEUE_DONE",
                processed_count=processed_count,
                qsize_remaining=_qsize_safe(q),
                progress_value=progress.value,
                status_text=status_text.text,
            )

    ui.timer(0.25, drain_queue)

    # -------------------------------------------------------------------------
    # CALLBACKS PASSED INTO CORE
    # -------------------------------------------------------------------------
    def cb_status(progress_value: float, text: str) -> None:
        _dbg("CB_STATUS_QUEUE_PUT", progress_value=progress_value, text=text)
        q.put(
            {
                "type": "status",
                "text": text,
                "progress": progress_value,
            }
        )
        _dbg("CB_STATUS_QUEUE_SIZE", qsize=_qsize_safe(q))

    def cb_detail(text: str) -> None:
        _dbg("CB_DETAIL_QUEUE_PUT", text=text)
        q.put(
            {
                "type": "detail",
                "text": text,
            }
        )
        _dbg("CB_DETAIL_QUEUE_SIZE", qsize=_qsize_safe(q))

    # -------------------------------------------------------------------------
    # RUN DER OPTIMIZATION
    # -------------------------------------------------------------------------
    @dataclass
    class TechCosts:
        pv_capex_per_kw_yr: float
        batt_power_capex_per_kw_yr: float
        batt_energy_capex_per_kwh_yr: float
        diesel_capex_per_kw_yr: float
        grid_price_per_kwh: float
        diesel_fuel_cost_per_kwh: float
        batt_marginal_per_kwh: float
        load_shed_cost_per_kwh: float

    async def on_run_der_optimization() -> None:
        """
        Launch DER optimization in a worker thread and return result to queue.
        """
        nonlocal last_der_export, last_der_case_name, last_der_run_dir

        _dbg("RUN_CLICK_ENTER", selected_project=project_select.value)

        if not project_select.value:
            ui.notify("Please select a load forecasting run first", color="negative")
            q.put({"type": "error", "error": "Select a load forecasting run first"})
            _dbg("RUN_CLICK_ABORT_NO_PROJECT")
            return

        last_der_export = None
        last_der_case_name = None
        last_der_run_dir = None
        clear_static_plot()
        clear_detail_log()

        base = str(der_case_base.value).strip()
        der_case_name = base + ("+weakgrid" if bool(enable_weakgrid.value) else "")

        tab["inputs_der"] = {
            "project": project_select.value,
            "case_base": der_case_base.value,
            "enable_weakgrid": bool(enable_weakgrid.value),
            "battery_hours": float(battery_hours.value),
            "grid_limit_kw": grid_import_limit_kw.value,
            "weak_outage_start_date": weak_outage_start_date.value,
            "weak_outage_start_hour": int(weak_outage_start_hour.value or 0),
            "weak_outage_hours": int(weak_outage_hours.value or 0),
            "pv_capex": float(pv_capex.value),
            "batt_power_capex": float(batt_power_capex.value),
            "batt_energy_capex": float(batt_energy_capex.value),
            "diesel_capex": float(diesel_capex.value),
            "grid_price": float(grid_price.value),
            "diesel_fuel": float(diesel_fuel.value),
            "batt_marg": float(batt_marg.value),
            "load_shed_cost_per_kwh": float(load_shed_cost.value),
        }

        _dbg(
            "RUN_INPUTS_CAPTURED",
            der_case_name=der_case_name,
            inputs=tab["inputs_der"],
        )

        ui_set_status("Starting DER optimization")
        progress.value = 0.0
        progress.set_visibility(True)
        ui_append_detail_lines(
            [
                f"Selected load forecasting run: {project_select.value}",
                "DER run started",
            ]
        )

        try:
            ts_folder = lf_runs_root / Path(str(project_select.value))
            proj = _find_latest_uo_project(ts_folder)

            if proj is None:
                raise RuntimeError(f"No uo_* folder found inside {ts_folder}")

            scen = _find_first_scenario_name(proj)
            if scen is None:
                raise RuntimeError(f"No scenarios found inside {proj / 'run'}")

            _dbg(
                "RUN_PROJECT_RESOLVED",
                ts_folder=str(ts_folder),
                project=str(proj),
                scenario=scen,
            )

            costs = TechCosts(
                pv_capex_per_kw_yr=float(pv_capex.value),
                batt_power_capex_per_kw_yr=float(batt_power_capex.value),
                batt_energy_capex_per_kwh_yr=float(batt_energy_capex.value),
                diesel_capex_per_kw_yr=float(diesel_capex.value),
                grid_price_per_kwh=float(grid_price.value),
                diesel_fuel_cost_per_kwh=float(diesel_fuel.value),
                batt_marginal_per_kwh=float(batt_marg.value),
                load_shed_cost_per_kwh=float(load_shed_cost.value),
            )

            _dbg("RUN_COSTS_OBJECT", costs=costs)

            outage_start_date = None
            if weak_outage_start_date.value:
                outage_start_date = pd.Timestamp(
                    pd.to_datetime(weak_outage_start_date.value).date()
                )

            _dbg("RUN_OUTAGE_WINDOW", outage_start_date=outage_start_date)

            run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
            der_run_dir = der_runs_root / run_id
            der_run_dir.mkdir(parents=True, exist_ok=True)

            run_config = {
                "project_path": str(proj),
                "scenario": scen,
                "der_case": der_case_name,
                "battery_hours": battery_hours.value,
                "grid_import_limit_kw": grid_import_limit_kw.value,
                "weakgrid_enabled": bool(enable_weakgrid.value),
                "outage_start_date": str(outage_start_date),
                "outage_start_hour": weak_outage_start_hour.value,
                "outage_hours": weak_outage_hours.value,
                "costs": {
                    "pv_capex": pv_capex.value,
                    "batt_power_capex": batt_power_capex.value,
                    "batt_energy_capex": batt_energy_capex.value,
                    "diesel_capex": diesel_capex.value,
                    "grid_price": grid_price.value,
                    "diesel_fuel": diesel_fuel.value,
                    "batt_marg": batt_marg.value,
                    "load_shed": load_shed_cost.value,
                },
            }

            config_path = der_run_dir / "run_config.json"
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(run_config, f, indent=2)

            ui_append_detail_lines([f"Run config saved: {config_path}"])
            _dbg(
                "RUN_CONFIG_WRITTEN",
                config_path=str(config_path),
                run_config=run_config,
            )

            io_bound_args = {
                "project_path": proj,
                "scenario_stem": scen,
                "der_case_name": der_case_name,
                "battery_hours": float(battery_hours.value),
                "grid_import_limit_kw": (
                    None
                    if grid_import_limit_kw.value in ("", None)
                    else float(grid_import_limit_kw.value)
                ),
                "costs": costs,
                "cb_status": cb_status,
                "cb_detail": cb_detail,
                "export_dir": der_run_dir,
                "outage_start_hour": int(weak_outage_start_hour.value or 0),
                "outage_hours_per_day": int(weak_outage_hours.value or 0),
                "outage_start_date": outage_start_date,
                "return_timeseries": False,
            }

            _dbg("RUN_IO_BOUND_START", io_args=io_bound_args)

            result = await run.io_bound(
                _run_der_core,
                **io_bound_args,
            )

            _dbg("RUN_IO_BOUND_RETURNED", result=result)

            if isinstance(result, dict) and result.get("__error__"):
                _dbg("RUN_IO_BOUND_RETURNED_ERROR_PAYLOAD", payload=result)
                raise RuntimeError(str(result["__error__"]))

            summary = (
                f"DER case: {result.get('der_case')}\n"
                f"Objective: {result.get('objective'):.2f}\n"
                f"PV: {result.get('pv_kw'):.2f} kW | "
                f"Battery: {result.get('battery_kw'):.2f} kW | "
                f"Diesel: {result.get('diesel_kw'):.2f} kW"
            )

            payload = dict(result)
            payload["type"] = "result_der"
            payload["summary"] = summary
            payload["out_dir"] = str(der_run_dir)

            _dbg("RUN_QUEUE_RESULT_PUT", payload=payload)
            q.put(payload)
            _dbg("RUN_QUEUE_RESULT_SIZE", qsize=_qsize_safe(q))

        except Exception as e:
            _dbg("RUN_CLICK_ERROR", error=repr(e), traceback=traceback.format_exc())
            q.put({"type": "error", "error": repr(e)})
            _dbg("RUN_QUEUE_ERROR_SIZE", qsize=_qsize_safe(q))

    # -------------------------------------------------------------------------
    # WIRE EVENTS
    # -------------------------------------------------------------------------
    _dbg("WIRE_EVENTS_START")
    btn_clear_selection.on("click", clear_selection)
    btn_refresh_runs.on("click", refresh_projects)
    btn_refresh_der_results.on("click", refresh_der_result_folders)
    btn_load_der_summary.on("click", load_selected_der_summary)
    btn_generate_plot.on("click", generate_selected_der_plot)
    run_button.on("click", on_run_der_optimization)
    project_select.on("update:model-value", on_project_change)
    _dbg("WIRE_EVENTS_DONE")

    # -------------------------------------------------------------------------
    # RESTORE SAVED VALUES
    # -------------------------------------------------------------------------
    if isinstance(saved_der, dict):
        _dbg("RESTORE_INPUTS_APPLY_START")
        project_select.value = saved_der.get("project", project_select.value)
        der_case_base.value = saved_der.get("case_base", der_case_base.value)
        enable_weakgrid.value = bool(
            saved_der.get("enable_weakgrid", enable_weakgrid.value)
        )
        battery_hours.value = saved_der.get("battery_hours", battery_hours.value)
        grid_import_limit_kw.value = saved_der.get(
            "grid_limit_kw", grid_import_limit_kw.value
        )
        weak_outage_start_date.value = saved_der.get(
            "weak_outage_start_date", weak_outage_start_date.value
        )
        weak_outage_start_hour.value = saved_der.get(
            "weak_outage_start_hour", weak_outage_start_hour.value
        )
        weak_outage_hours.value = saved_der.get(
            "weak_outage_hours", weak_outage_hours.value
        )
        pv_capex.value = saved_der.get("pv_capex", pv_capex.value)
        batt_power_capex.value = saved_der.get(
            "batt_power_capex", batt_power_capex.value
        )
        batt_energy_capex.value = saved_der.get(
            "batt_energy_capex", batt_energy_capex.value
        )
        diesel_capex.value = saved_der.get("diesel_capex", diesel_capex.value)
        grid_price.value = saved_der.get("grid_price", grid_price.value)
        diesel_fuel.value = saved_der.get("diesel_fuel", diesel_fuel.value)
        batt_marg.value = saved_der.get("batt_marg", batt_marg.value)
        load_shed_cost.value = saved_der.get(
            "load_shed_cost_per_kwh", load_shed_cost.value
        )
        _dbg("RESTORE_INPUTS_APPLY_DONE")

    refresh_projects()
    refresh_der_result_folders()
    update_selected_label()
    validate_run_button()

    _dbg("TAB_RENDER_DONE")


# =============================================================================
# CORE WRAPPER
# =============================================================================


def _run_der_core(
    *,
    project_path: Path,
    scenario_stem: str,
    der_case_name: str,
    battery_hours: float,
    grid_import_limit_kw: float | None,
    costs: Any,
    cb_status,
    cb_detail,
    export_dir: Path,
    outage_start_hour: int,
    outage_hours_per_day: int,
    outage_start_date: Any,
    return_timeseries: bool,
) -> dict[str, Any]:
    """
    Thin wrapper that calls the existing orchestrator.

    Notes
    -----
    This function runs in a worker thread. It catches BaseException so that
    an unexpected worker-side failure is returned as a normal dictionary
    instead of tearing down the UI task boundary.
    """
    _dbg(
        "RUN_DER_CORE_ENTER",
        project_path=str(project_path),
        scenario_stem=scenario_stem,
        der_case_name=der_case_name,
        battery_hours=battery_hours,
        grid_import_limit_kw=grid_import_limit_kw,
        export_dir=str(export_dir),
        outage_start_hour=outage_start_hour,
        outage_hours_per_day=outage_hours_per_day,
        outage_start_date=outage_start_date,
        return_timeseries=return_timeseries,
    )

    try:
        from col.platform.orchestration.der_optimization_orchestrator import (
            run_der_optimization,
        )

        result = run_der_optimization(
            project_path=project_path,
            scenario_stem=scenario_stem,
            der_case_name=der_case_name,
            battery_hours=battery_hours,
            grid_import_limit_kw=grid_import_limit_kw,
            costs=costs,
            cb_status=cb_status,
            cb_detail=cb_detail,
            export_dir=export_dir,
            outage_start_hour=outage_start_hour,
            outage_hours_per_day=outage_hours_per_day,
            outage_start_date=outage_start_date,
            return_timeseries=return_timeseries,
        )

        _dbg("RUN_DER_CORE_DONE", result=result)
        return result

    except BaseException as e:
        _dbg(
            "RUN_DER_CORE_BASE_EXCEPTION",
            error=repr(e),
            traceback=traceback.format_exc(),
        )
        return {"__error__": f"{type(e).__name__}: {e}"}
