"""
src/col/platform/cores/der_optimization/pypsa/__init__.py

PyPSA-based DER optimization core module.

This package contains the implementation of distributed energy
resource (DER) optimization using PyPSA within the COL platform.
It provides core logic, interfaces, and utilities required to
build, run, and manage DER optimization workflows.

Typical Usage:
- Execute DER optimization scenarios using PyPSA
- Interface with orchestration and UI layers
- Provide results for visualization and analysis
"""
