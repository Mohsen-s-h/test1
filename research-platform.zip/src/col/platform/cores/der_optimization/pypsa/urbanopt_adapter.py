"""
MODULE: URBANopt Load Extraction Adapter
FILE: urbanopt_adapter.py
LOCATION:
src/col/platform/cores/der_optimization/pypsa/urbanopt_adapter.py

PURPOSE
-------
This module provides utilities for extracting and aggregating electricity
load data from URBANopt simulation outputs.

It serves as a clean interface between:
- URBANopt simulation results (feature-level CSVs)
- DER optimization core (PyPSA)

The module converts raw feature-level building load outputs into a
single aggregated site-level load profile suitable for optimization.

RESPONSIBILITIES
----------------
1. Locate feature-level simulation output folders
2. Identify the latest report directory for each feature
3. Read electricity demand from default_feature_reports.csv
4. Convert data into structured pandas time series
5. Aggregate load across multiple features
6. Perform sanity checks on time resolution and data integrity

EXECUTION FLOW
--------------
Typical workflow:

1. A URBANopt run scenario directory is provided:
   <project>/run/<scenario_stem>/
2. Feature directories (e.g., "1", "2", "3", ...) are identified
3. For each feature:
   - Latest *_default_feature_reports directory is selected
   - Load CSV is read and parsed
4. Individual feature load profiles are combined
5. Aggregated load is returned as a pandas Series

TYPICAL CALLER
--------------
- DER optimization runner
- Load forecasting module
- Scenario evaluation pipelines

OUTPUT FORMAT
-------------
pandas Series:
- index: DatetimeIndex (hourly resolution)
- values: electricity demand in kW

IMPORTANT NOTES
---------------
- Only numeric folder names are treated as feature directories
- Load aggregation defaults to first N features (default = 3)
- Missing values are safely converted to zero
- Time consistency must be hourly (~8760 samples/year)
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from dataclasses import dataclass
from pathlib import Path

# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import pandas as pd


# ---------------------------------------------------------------------
# Constants: URBANopt CSV column definitions
# ---------------------------------------------------------------------
# These column names must match URBANopt output exactly.
# ---------------------------------------------------------------------

LOAD_COL = "Electricity:Facility Power(kW)"
TIME_COL = "Datetime"


# ---------------------------------------------------------------------
# Data container: scenario-level load
# ---------------------------------------------------------------------
# Represents aggregated load for a given URBANopt scenario.
#
# Fields:
# - scenario_stem: scenario identifier (folder name)
# - total_load_kw: aggregated load time series (kW)
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class ScenarioLoad:
    scenario_stem: str
    total_load_kw: pd.Series


# ---------------------------------------------------------------------
# Helper: locate latest report directory for a feature
# ---------------------------------------------------------------------
# URBANopt may generate multiple report folders (e.g., reruns).
# This function selects the most recently modified one.
# ---------------------------------------------------------------------


def _latest_reports_dir(feature_dir: Path) -> Path:
    """
    Identify the most recent URBANopt report folder.

    Expected folder naming:
    - 025_default_feature_reports
    - similar variants with timestamps or indices

    Returns:
        Path to most recently modified report directory
    """
    candidates = [
        d
        for d in feature_dir.iterdir()
        if d.is_dir() and d.name.endswith("_default_feature_reports")
    ]

    if not candidates:
        raise FileNotFoundError(f"No *_default_feature_reports folder in {feature_dir}")

    # Select directory with latest modification time
    return max(candidates, key=lambda p: p.stat().st_mtime)


# ---------------------------------------------------------------------
# Read load profile for a single feature
# ---------------------------------------------------------------------
# Extracts electricity demand time series from CSV.
# Performs validation and conversion.
# ---------------------------------------------------------------------


def read_feature_load_kw(feature_dir: Path) -> pd.Series:
    """
    Read hourly electricity load for one URBANopt feature.

    Parameters
    ----------
    feature_dir : Path
        Directory representing a feature (building)

    Returns
    -------
    pd.Series
        Hourly electricity demand (kW), indexed by datetime
    """
    reports_dir = _latest_reports_dir(feature_dir)
    csv_path = reports_dir / "default_feature_reports.csv"

    df = pd.read_csv(csv_path)

    # Validate required columns
    if TIME_COL not in df.columns:
        raise ValueError(
            f"Missing '{TIME_COL}' in {csv_path}. Columns={list(df.columns)}"
        )

    if LOAD_COL not in df.columns:
        raise ValueError(
            f"Missing '{LOAD_COL}' in {csv_path}. Columns={list(df.columns)}"
        )

    # Convert datetime column
    dt = pd.to_datetime(df[TIME_COL], errors="coerce")

    if dt.isna().any():
        raise ValueError(f"Some Datetime values could not be parsed in {csv_path}")

    # Convert load values to numeric
    s = pd.to_numeric(df[LOAD_COL], errors="coerce").fillna(0.0)

    # Assign datetime index and feature name
    s.index = dt
    s.name = feature_dir.name

    return s


# ---------------------------------------------------------------------
# Aggregate load across multiple features
# ---------------------------------------------------------------------
# Combines load from the first N features (ordered numerically).
# ---------------------------------------------------------------------


def aggregate_first_n_features(run_scenario_dir: Path, n: int = 3) -> pd.Series:
    """
    Aggregate load from first N URBANopt features.

    Parameters
    ----------
    run_scenario_dir : Path
        Directory: <project>/run/<scenario_stem>

    n : int
        Number of features to include

    Returns
    -------
    pd.Series
        Aggregated electricity demand (kW)
    """

    # Select feature directories with numeric names only
    feature_dirs = [
        p for p in run_scenario_dir.iterdir() if p.is_dir() and p.name.isdigit()
    ]

    # Sort features numerically (1, 2, 3, ...)
    feature_dirs.sort(key=lambda p: int(p.name))

    if len(feature_dirs) < n:
        raise RuntimeError(
            f"Need >= {n} feature folders in {run_scenario_dir}, "
            f"found {len(feature_dirs)}"
        )

    # Read load for selected features
    series = [read_feature_load_kw(d) for d in feature_dirs[:n]]

    # Aggregate across features (sum across columns)
    total = pd.concat(series, axis=1).fillna(0.0).sum(axis=1)
    total.name = "total_load_kw"

    return total


# ---------------------------------------------------------------------
# Sanity check: validate hourly time series
# ---------------------------------------------------------------------
# Ensures:
# - Expected yearly size (~8760 hours)
# - Consistent hourly timestep
# ---------------------------------------------------------------------


def sanity_check_hourly_one_year(load_kw: pd.Series) -> None:
    """
    Validate load time series structure.

    Checks:
    - Length approximately equal to one year (8760 hours)
    - Hourly timestep consistency

    Raises:
        ValueError if validation fails
    """

    # Check approximate yearly length
    if len(load_kw) < 8000 or len(load_kw) > 9000:
        raise ValueError(
            f"Unexpected length={len(load_kw)}. Expected ~8760 hourly samples."
        )

    # Verify first 48 timesteps are hourly spaced
    diffs = load_kw.index.to_series().diff().dropna().head(48)

    if not (diffs == pd.Timedelta(hours=1)).all():
        raise ValueError(
            "Timestep is not consistently hourly (first 48 steps check failed)."
        )
