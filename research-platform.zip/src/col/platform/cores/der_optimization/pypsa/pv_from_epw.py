"""
MODULE: PV Capacity Factor Generator from EPW
FILE: pv_from_epw.py
LOCATION:
src/col/platform/cores/der_optimization/pypsa/pv_from_epw.py

PURPOSE
-------
This module generates a photovoltaic (PV) capacity factor time series
using weather data from an EPW (EnergyPlus Weather) file.

It converts raw meteorological data (irradiance + location metadata)
into a normalized PV production profile compatible with PyPSA-based
DER optimization models.

RESPONSIBILITIES
----------------
1. Locate EPW weather files within a project directory
2. Read irradiance data (GHI, DNI, DHI) and metadata (lat/lon/alt/tz)
3. Align EPW weather data with simulation time snapshots
4. Compute solar position and plane-of-array irradiance
5. Estimate PV output using PVWatts model
6. Convert PV output into a capacity factor (0–1)

EXECUTION FLOW
--------------
Typical workflow:

1. A project directory is provided (contains /weather/*.epw)
2. Simulation snapshots (DatetimeIndex) are passed from the model
3. EPW file is read and metadata extracted
4. EPW timestamps are aligned to simulation timestamps using
   (month, day, hour) matching
5. Solar position is computed using pvlib
6. Plane-of-array irradiance is calculated
7. PVWatts model estimates DC power output
8. Output is normalized to capacity factor (0–1)
9. Result is returned as a pandas Series aligned with snapshots

TYPICAL CALLER
--------------
- DER optimization runner
- PyPSA network builder (for PV generation profile)

IMPORTANT MODELING NOTES
------------------------
- EPW files use a fixed reference year → alignment is done using
  (month, day, hour) matching instead of exact timestamps
- Two hour conventions are tested (0–23 vs 1–24), and the best match is selected
- Missing irradiance values after alignment are filled with zero
- Default PV tilt is set equal to absolute latitude if not specified
- Output is always clipped between 0 and 1
"""

from __future__ import annotations


# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple, Dict, Any
import inspect


# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import pandas as pd
import pvlib


# ---------------------------------------------------------------------
# EPW metadata container
# ---------------------------------------------------------------------
# Stores location and timezone information extracted from EPW file.
#
# Fields:
# - lat: latitude (degrees)
# - lon: longitude (degrees)
# - alt: altitude (meters)
# - tz_hours: timezone offset from UTC (hours)
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class EPWMeta:
    lat: float
    lon: float
    alt: float
    tz_hours: float


# ---------------------------------------------------------------------
# Locate EPW file in project directory
# ---------------------------------------------------------------------
# Expected structure:
#   <project_path>/weather/*.epw
#
# Returns the first EPW file found.
# Raises FileNotFoundError if none exists.
# ---------------------------------------------------------------------


def find_epw_in_project(project_path: Path) -> Path:
    weather_dir = project_path / "weather"
    epws = sorted(weather_dir.glob("*.epw"))

    if not epws:
        raise FileNotFoundError(f"No EPW found in {weather_dir}")

    return epws[0]


# ---------------------------------------------------------------------
# Read EPW data and extract required fields
# ---------------------------------------------------------------------
# Returns:
# - DataFrame with irradiance data
# - EPWMeta object with location info
#
# Validates presence of:
#   ghi, dni, dhi
# ---------------------------------------------------------------------


def _read_epw(epw_path: Path) -> tuple[pd.DataFrame, EPWMeta]:
    df, meta = pvlib.iotools.read_epw(epw_path)

    lat = float(meta["latitude"])
    lon = float(meta["longitude"])
    alt = float(meta.get("altitude", 0.0))
    tz_hours = float(meta.get("TZ", meta.get("tz", 0.0)))

    needed = ["ghi", "dni", "dhi"]
    missing = [c for c in needed if c not in df.columns]

    if missing:
        raise KeyError(
            f"EPW is missing required columns {missing}. Found columns: {list(df.columns)}"
        )

    return df, EPWMeta(lat=lat, lon=lon, alt=alt, tz_hours=tz_hours)


# ---------------------------------------------------------------------
# Public helper to extract EPW metadata only
# ---------------------------------------------------------------------


def read_epw_meta(epw_path: Path) -> EPWMeta:
    """Used by higher-level modules for logging or validation."""
    _, m = _read_epw(epw_path)
    return m


# ---------------------------------------------------------------------
# Convert EPW UTC offset to IANA timezone
# ---------------------------------------------------------------------
# Example:
#   -7 → Etc/GMT+7
#   +2 → Etc/GMT-2
# ---------------------------------------------------------------------


def _iana_tz_from_utc_offset_hours(offset_hours: float) -> str:
    off = int(round(float(offset_hours)))
    return f"Etc/GMT{(-off):+d}"


# ---------------------------------------------------------------------
# Build alignment key (month, day, hour)
# ---------------------------------------------------------------------
# Used to match EPW data with simulation snapshots.
#
# Two hour conventions supported:
#   - h0_23: 0–23
#   - h1_24: 1–24 (EPW standard)
# ---------------------------------------------------------------------


def _mdh_key(index: pd.DatetimeIndex, hour_mode: str) -> pd.MultiIndex:
    if hour_mode not in ("h0_23", "h1_24"):
        raise ValueError("hour_mode must be 'h0_23' or 'h1_24'")

    if hour_mode == "h0_23":
        h = index.hour
    else:
        h = index.hour + 1

    return pd.MultiIndex.from_arrays(
        [index.month, index.day, h],
        names=["month", "day", "hour"],
    )


# ---------------------------------------------------------------------
# Core function: compute PV capacity factor
# ---------------------------------------------------------------------
# Steps:
# 1. Read EPW
# 2. Normalize timezone
# 3. Align EPW data with simulation snapshots
# 4. Compute solar position
# 5. Compute irradiance on panel
# 6. Apply PVWatts model
# 7. Normalize to capacity factor
# ---------------------------------------------------------------------


def pv_capacity_factor_from_epw(
    epw_path: Path,
    snapshots: pd.DatetimeIndex,
    tilt: Optional[float] = None,
    azimuth: float = 180.0,
    return_debug: bool = False,
) -> pd.Series | Tuple[pd.Series, Dict[str, Any]]:
    # Read EPW data and metadata
    epw_df, m = _read_epw(epw_path)

    # Convert EPW timezone to IANA format
    tz = _iana_tz_from_utc_offset_hours(m.tz_hours)

    # ------------------------------------------------------------------
    # Normalize snapshot timezone
    # ------------------------------------------------------------------

    if snapshots.tz is None:
        times = snapshots.tz_localize(tz)
    else:
        times = snapshots.tz_convert(tz)

    if epw_df.index.tz is None:
        epw_times = epw_df.index.tz_localize(tz)
    else:
        epw_times = epw_df.index.tz_convert(tz)

    # ------------------------------------------------------------------
    # Align EPW data with simulation snapshots
    # ------------------------------------------------------------------

    # Two alignment strategies tested to handle EPW hour convention
    epw0 = epw_df.copy()
    epw0.index = _mdh_key(epw_times, "h0_23")

    epw1 = epw_df.copy()
    epw1.index = _mdh_key(epw_times, "h1_24")

    snap_key0 = _mdh_key(times, "h0_23")
    snap_key1 = _mdh_key(times, "h1_24")

    w0 = epw0.reindex(snap_key0)[["ghi", "dni", "dhi"]]
    w1 = epw1.reindex(snap_key1)[["ghi", "dni", "dhi"]]

    # Select best alignment (maximum valid data)
    score0 = int(w0.notna().all(axis=1).sum())
    score1 = int(w1.notna().all(axis=1).sum())

    hour_mode = "h1_24" if score1 > score0 else "h0_23"
    w = w1 if score1 > score0 else w0

    # Restore proper datetime index
    w = w.copy()
    w.index = times
    w = w.fillna(0.0)

    # ------------------------------------------------------------------
    # Solar position + irradiance calculation
    # ------------------------------------------------------------------

    # Default tilt = latitude (common engineering assumption)
    used_tilt = float(abs(m.lat)) if tilt is None else float(tilt)

    location = pvlib.location.Location(
        latitude=m.lat,
        longitude=m.lon,
        tz=tz,
        altitude=m.alt,
    )

    solpos = location.get_solarposition(times)

    poa = pvlib.irradiance.get_total_irradiance(
        surface_tilt=used_tilt,
        surface_azimuth=azimuth,
        dni=w["dni"],
        ghi=w["ghi"],
        dhi=w["dhi"],
        solar_zenith=solpos["apparent_zenith"],
        solar_azimuth=solpos["azimuth"],
    )

    effective_irradiance = poa["poa_global"].clip(lower=0.0)

    # ------------------------------------------------------------------
    # PVWatts DC model
    # ------------------------------------------------------------------

    # Handle pvlib API differences across versions
    pvwatts_params = inspect.signature(pvlib.pvsystem.pvwatts_dc).parameters

    if "effective_irradiance" in pvwatts_params:
        p_dc_w = pvlib.pvsystem.pvwatts_dc(
            effective_irradiance=effective_irradiance,
            temp_cell=25.0,
            pdc0=1000.0,
            gamma_pdc=-0.003,
        )
    else:
        p_dc_w = pvlib.pvsystem.pvwatts_dc(
            g_poa_effective=effective_irradiance,
            temp_cell=25.0,
            pdc0=1000.0,
            gamma_pdc=-0.003,
        )

    # ------------------------------------------------------------------
    # Convert to capacity factor
    # ------------------------------------------------------------------

    cf = (p_dc_w / 1000.0).clip(lower=0.0, upper=1.0)

    cf = cf.tz_convert(None)
    cf.index = snapshots
    cf.name = "pv_cf"
    cf = cf.astype(float)

    # Return either CF only or CF + debug metadata
    if not return_debug:
        return cf

    debug = {
        "epw_path": str(epw_path),
        "lat": m.lat,
        "lon": m.lon,
        "alt": m.alt,
        "tz_hours": m.tz_hours,
        "tz_iana": tz,
        "tilt_used_deg": used_tilt,
        "azimuth_deg": float(azimuth),
        "hour_mode_selected": hour_mode,
        "match_score_h0_23": score0,
        "match_score_h1_24": score1,
        "cf_min": float(cf.min()),
        "cf_max": float(cf.max()),
        "cf_nonzero_hours": int((cf > 0).sum()),
    }

    return cf, debug


# ---------------------------------------------------------------------
# Convenience wrapper for project-level usage
# ---------------------------------------------------------------------
# Simplifies workflow:
#   project_path → EPW → PV capacity factor
# ---------------------------------------------------------------------


def pv_cf_from_project(
    project_path: Path,
    snapshots: pd.DatetimeIndex,
    tilt: Optional[float] = None,
    azimuth: float = 180.0,
    return_debug: bool = False,
) -> pd.Series | Tuple[pd.Series, Dict[str, Any]]:
    epw_path = find_epw_in_project(project_path)

    return pv_capacity_factor_from_epw(
        epw_path=epw_path,
        snapshots=snapshots,
        tilt=tilt,
        azimuth=azimuth,
        return_debug=return_debug,
    )
