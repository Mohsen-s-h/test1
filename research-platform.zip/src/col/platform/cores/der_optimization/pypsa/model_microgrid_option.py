"""
MODULE: PyPSA Microgrid Model Builder
FILE: model_microgrid_option.py
LOCATION:
src/col/platform/cores/der_optimization/pypsa/model_microgrid_option.py

PURPOSE
-------
This module defines the microgrid network construction logic used by the
DER optimization core.

Its role is to translate high-level DER configuration choices from the UI
or orchestration layer into a PyPSA-compatible network model that can be
solved for capacity expansion and operational dispatch.

The resulting network is intentionally structured as a simplified
single-bus microgrid representation, which is appropriate for early-stage
DER portfolio evaluation, comparative case studies, and scenario-based
optimization.

RESPONSIBILITIES
----------------
1. Define technology-level economic assumptions through structured data
   containers.
2. Interpret user-selected DER case options and convert them into an
   internal case specification.
3. Build a PyPSA network containing the load and selected DER resources.
4. Apply consistent unit conversions required by PyPSA inputs.
5. Include a feasibility safeguard through high-cost load shedding.

MODEL OVERVIEW
--------------
The constructed network represents a single electrical bus with the
following possible components:

- Fixed electrical demand from aggregated URBANopt load profiles
- Grid import source
- Photovoltaic generation
- Diesel generation
- Battery storage
- Load shedding as an emergency slack option

This design supports comparative DER scenario analysis such as:
- grid only
- PV + grid
- PV + battery + grid
- diesel-backed cases
- weak-grid cases with import availability limitations

EXECUTION FLOW
--------------
Typical execution sequence:

1. The orchestration layer prepares time-series inputs such as:
   - load_kw
   - pv_cf
   - optional grid availability profile
2. A UI-selected case name is passed to `case_from_ui_option(...)`.
3. That selection is converted into a structured `CaseSpec`.
4. `build_microgrid_network(...)` uses:
   - the demand profile,
   - PV capacity factor profile,
   - technology cost assumptions,
   - the selected case definition,
   - battery duration,
   to assemble a PyPSA `Network`.
5. The returned network is then passed to the optimization/solve stage.

TYPICAL CALLER
--------------
This module is typically called by the DER optimization runner after
load profiles and scenario assumptions have already been prepared.

IMPORTANT MODELING NOTES
------------------------
- Load input is expected in kW and converted internally to MW.
- Energy price and marginal cost inputs provided in $/kWh are converted
  internally to $/MWh for PyPSA compatibility.
- If PV time indices do not exactly match load time indices, the PV
  profile is reindexed to the load snapshots and missing values are
  filled with zero.
- A very high-cost load shedding generator is always included so that
  the optimization remains feasible even under undersized supply cases.
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from dataclasses import dataclass
from typing import Optional

# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import pandas as pd
import pypsa


# ---------------------------------------------------------------------
# Economic input container
# ---------------------------------------------------------------------
# This dataclass stores annualized technology cost assumptions and
# operational energy costs used when constructing the PyPSA network.
#
# Notes:
# - Power-related capital costs are expected in $/kW-year
# - Battery energy cost is expected in $/kWh-year
# - Marginal costs are expected in $/kWh and converted later to $/MWh
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class TechCosts:
    pv_capex_per_kw_yr: float = 120.0
    batt_power_capex_per_kw_yr: float = 450.0
    batt_energy_capex_per_kwh_yr: float = 200.0
    diesel_capex_per_kw_yr: float = 350.0
    grid_price_per_kwh: float = 0.12
    diesel_fuel_cost_per_kwh: float = 0.45
    batt_marginal_per_kwh: float = 0.005
    load_shed_cost_per_kwh: float = 10.0


# ---------------------------------------------------------------------
# Scenario / case definition container
# ---------------------------------------------------------------------
# This dataclass represents the resolved modeling case after interpreting
# the UI selection.
#
# Fields indicate:
# - which DER technologies are enabled
# - whether grid import is capped
# - whether a time-varying grid availability profile is enforced
# ---------------------------------------------------------------------


@dataclass(frozen=True)
class CaseSpec:
    name: str
    allow_pv: bool
    allow_battery: bool
    allow_diesel: bool
    grid_import_limit_kw: Optional[float] = None
    grid_available_pu: Optional[pd.Series] = None


# ---------------------------------------------------------------------
# UI case parser
# ---------------------------------------------------------------------
# Converts a UI-visible DER case name into an internal `CaseSpec`.
#
# Expected naming convention:
# - keywords such as "pv", "battery", and "diesel" activate the
#   corresponding technologies
# - suffix "+weakgrid" activates the optional grid availability profile
#
# Example interpretations:
# - "PV + Battery"            -> PV enabled, battery enabled
# - "PV + Diesel + WeakGrid"  -> PV enabled, diesel enabled,
#                                weak-grid profile applied
#
# The function does not validate naming style beyond simple keyword
# detection, so consistency in UI case naming is important.
# ---------------------------------------------------------------------


def case_from_ui_option(
    der_case_name: str,
    *,
    grid_import_limit_kw: float | None,
    grid_available_pu: pd.Series | None,
) -> CaseSpec:
    # Normalize the case name to make parsing case-insensitive.
    s = der_case_name.strip().lower()

    # Detect whether the selected case is marked as a weak-grid case.
    weak = s.endswith("+weakgrid")

    # Remove the weak-grid suffix before parsing DER technology keywords.
    base = s.replace("+weakgrid", "").strip()

    # Technology activation is based on simple keyword presence.
    allow_pv = "pv" in base
    allow_batt = "battery" in base
    allow_diesel = "diesel" in base

    # Build the resolved internal case specification.
    # The grid availability profile is only applied when the case is
    # explicitly marked as weak-grid.
    return CaseSpec(
        name=der_case_name.strip(),
        allow_pv=allow_pv,
        allow_battery=allow_batt,
        allow_diesel=allow_diesel,
        grid_import_limit_kw=grid_import_limit_kw,
        grid_available_pu=grid_available_pu if weak else None,
    )


# ---------------------------------------------------------------------
# PyPSA microgrid network builder
# ---------------------------------------------------------------------
# Constructs a single-bus PyPSA network using:
# - load profile
# - PV capacity factor profile
# - technology cost assumptions
# - resolved case specification
# - battery duration
#
# INPUT EXPECTATIONS
# ------------------
# load_kw:
#   Pandas Series indexed by DatetimeIndex, representing total load in kW
#
# pv_cf:
#   Pandas Series indexed by time, representing PV capacity factor in
#   per-unit form (expected between 0 and 1)
#
# costs:
#   TechCosts dataclass instance containing economic assumptions
#
# case:
#   CaseSpec instance indicating which technologies are enabled
#
# battery_hours:
#   Battery duration in hours; used to convert battery energy cost into
#   an equivalent storage-unit capital cost representation
#
# RETURNS
# -------
# A configured `pypsa.Network` ready for optimization.
#
# ERROR BEHAVIOR
# --------------
# Raises TypeError if `load_kw` is not indexed by `DatetimeIndex`.
#
# MODELING DETAILS
# ----------------
# - The electrical system is represented as a single bus.
# - Load is added as a fixed time-series demand.
# - Grid import is modeled as an extendable generator.
# - PV is modeled as an extendable generator with a time-varying
#   availability profile.
# - Diesel is modeled as an extendable dispatchable generator.
# - Battery is modeled as a `StorageUnit`.
# - Load shedding is always included as a high-cost feasibility option.
# ---------------------------------------------------------------------


def build_microgrid_network(
    *,
    load_kw: pd.Series,
    pv_cf: pd.Series,
    costs: TechCosts,
    case: CaseSpec,
    battery_hours: float,
) -> pypsa.Network:
    # Validate that the main load profile is time-indexed correctly.
    # PyPSA snapshots require a proper DatetimeIndex.
    if not isinstance(load_kw.index, pd.DatetimeIndex):
        raise TypeError("load_kw must have a DatetimeIndex")

    # Ensure the PV availability profile aligns with the load snapshots.
    # Missing timestamps are filled with zero PV production.
    if not load_kw.index.equals(pv_cf.index):
        pv_cf = pv_cf.reindex(load_kw.index).fillna(0.0)

    # Use the load time index as the master simulation snapshot set.
    snapshots = load_kw.index

    # Create the PyPSA network and register the simulation timeline.
    n = pypsa.Network()
    n.set_snapshots(snapshots)

    # Register all carriers used by this model.
    # The existence check avoids duplicate carrier insertion.
    for carrier in ("electricity", "grid", "pv", "diesel", "shed", "battery"):
        if carrier not in n.carriers.index:
            n.add("Carrier", carrier)

    # Create the single electrical bus representing the microgrid node.
    n.add("Bus", "bus0", carrier="electricity")

    # Convert load from kW to MW for PyPSA consistency.
    # Negative values, if any, are clipped to zero.
    load_mw = (load_kw.astype(float) / 1000.0).clip(lower=0.0)

    # Add fixed electrical demand to the bus.
    n.add("Load", "load", bus="bus0", p_set=load_mw)

    # Convert grid price from $/kWh to $/MWh.
    grid_mc = float(costs.grid_price_per_kwh) * 1000.0

    # Prepare the time-varying grid availability profile.
    # If no weak-grid profile is provided, grid is assumed fully available.
    if case.grid_available_pu is not None:
        grid_av = case.grid_available_pu.reindex(snapshots).fillna(1.0).clip(0.0, 1.0)
    else:
        grid_av = pd.Series(1.0, index=snapshots)

    # Convert the grid import capacity limit from kW to MW.
    # If no limit is specified, a very large upper bound is used to
    # approximate an unconstrained grid connection.
    if case.grid_import_limit_kw is None:
        grid_p_nom_max_mw = 1e6
    else:
        grid_p_nom_max_mw = float(case.grid_import_limit_kw) / 1000.0

    # Add the grid import option as an extendable generator.
    # This represents the ability to purchase power from the upstream grid.
    n.add(
        "Generator",
        "grid_import",
        bus="bus0",
        carrier="grid",
        p_nom_extendable=True,
        p_nom_min=0.0,
        p_nom_max=grid_p_nom_max_mw,
        p_max_pu=grid_av,
        marginal_cost=grid_mc,
        capital_cost=0.0,
    )

    # Add PV only when enabled by the selected case.
    if case.allow_pv:
        # Ensure PV profile remains within valid per-unit limits.
        pv_profile = pv_cf.astype(float).clip(0.0, 1.0)

        n.add(
            "Generator",
            "pv",
            bus="bus0",
            carrier="pv",
            p_nom_extendable=True,
            p_nom_min=0.0,
            p_max_pu=pv_profile,
            marginal_cost=0.0,
            capital_cost=float(costs.pv_capex_per_kw_yr) * 1000.0,
        )

    # Add diesel generation only when enabled by the selected case.
    if case.allow_diesel:
        n.add(
            "Generator",
            "diesel",
            bus="bus0",
            carrier="diesel",
            p_nom_extendable=True,
            p_nom_min=0.0,
            marginal_cost=float(costs.diesel_fuel_cost_per_kwh) * 1000.0,
            capital_cost=float(costs.diesel_capex_per_kw_yr) * 1000.0,
        )

    # Always include load shedding as a high-cost emergency option.
    # This helps maintain optimization feasibility in constrained cases.
    n.add(
        "Generator",
        "load_shed",
        bus="bus0",
        carrier="shed",
        p_nom_extendable=True,
        p_nom_min=0.0,
        marginal_cost=float(costs.load_shed_cost_per_kwh) * 1000.0,
        capital_cost=0.0,
    )

    # Add battery storage only when enabled by the selected case.
    if case.allow_battery:
        # Convert battery cost inputs into a single StorageUnit capital cost.
        #
        # PyPSA StorageUnit uses a power capacity variable (`p_nom`) together
        # with `max_hours`, so the energy-related annualized cost is mapped
        # into an equivalent power-based cost using battery duration.
        batt_power_cost_mwyr = float(costs.batt_power_capex_per_kw_yr) * 1000.0
        batt_energy_cost_mwyr = (
            float(costs.batt_energy_capex_per_kwh_yr) * float(battery_hours) * 1000.0
        )
        batt_capital_cost_mwyr = batt_power_cost_mwyr + batt_energy_cost_mwyr

        # Convert battery throughput cost from $/kWh to $/MWh.
        batt_mc = float(costs.batt_marginal_per_kwh) * 1000.0

        n.add(
            "StorageUnit",
            "battery",
            bus="bus0",
            carrier="battery",
            p_nom_extendable=True,
            p_nom_min=0.0,
            max_hours=float(battery_hours),
            efficiency_store=0.95,
            efficiency_dispatch=0.95,
            marginal_cost=batt_mc,
            capital_cost=batt_capital_cost_mwyr,
        )

    # Return the fully assembled PyPSA network for downstream solving.
    return n
