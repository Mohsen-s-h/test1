# DER Optimization Core
