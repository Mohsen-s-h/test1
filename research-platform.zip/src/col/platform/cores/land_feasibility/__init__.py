"""
src/col/platform/cores/land_feasibility/__init__.py

Land feasibility core package for the COL platform.

This package provides core functionalities for evaluating the physical,
environmental, and regulatory suitability of a land parcel for residential
microgrid development. It serves as a container for the analysis engine and
the NiceGUI-based UI panel.

Typical Usage:
- Accept a user-drawn polygon or point location from the UI
- Run environmental constraint analysis (wetlands, wooded, restricted zones)
- Integrate with the orchestration and UI layers
"""
