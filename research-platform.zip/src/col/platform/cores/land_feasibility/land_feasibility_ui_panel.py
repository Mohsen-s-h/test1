"""
src/col/platform/cores/land_feasibility/land_feasibility_ui_panel.py

Land Feasibility UI Panel
--------------------------

Map initialisation pattern (matches project_setup_tab.py exactly)
------------------------------------------------------------------
1. ui.html() renders a bare <div id="lfc-map"> — no <script> allowed.
2. ui.run_javascript() (fire-and-forget, no await) injects a function
   that calls window.COL_init_map() from site_map.js, then adds a
   leaflet-draw toolbar on top of the returned map object.
3. A setTimeout(fn, 500) inside the JS gives the DOM time to settle.
4. A document click listener re-tries init so the map shows even if
   the tab was not visible when the page first loaded.

All Leaflet libs + site_map.js are already on the page via app_main.py.
This file never injects any <script> or additional CSS.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from queue import Empty, Queue
from typing import Any

from nicegui import app, run, ui

from col.platform.cores.land_feasibility.core.land_feasibility_engine import (
    LandFeasibilityResult,
    run_land_feasibility,
)

# =============================================================================
# DEBUG
# =============================================================================

DEBUG_PREFIX = "[LFC_UI]"
MAX_LOG_LINES = 150


def _dbg(tag: str, **kwargs: Any) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    if kwargs:
        payload = " | ".join(f"{k}={v!r}" for k, v in kwargs.items())
        print(f"{DEBUG_PREFIX} {ts} {tag} | {payload}", flush=True)
    else:
        print(f"{DEBUG_PREFIX} {ts} {tag}", flush=True)


# =============================================================================
# QUEUE MESSAGE
# =============================================================================


@dataclass
class _UiMsg:
    type: str          # "status" | "result" | "error"
    payload: dict[str, Any]


# =============================================================================
# PANEL STATE
# =============================================================================


@dataclass
class _State:
    polygon_coords: list[list[float]] | None = None
    running: bool = False


# =============================================================================
# WORKSPACE PERSISTENCE
# =============================================================================

_LF_DIRNAME   = "land_feasibility"
_RESULT_FILE  = "land_feasibility_result.json"


def _lf_dir(workspace_path: str | None) -> Path | None:
    if not workspace_path:
        return None
    p = Path(workspace_path) / _LF_DIRNAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def _save_result(workspace_path: str | None, data: dict[str, Any]) -> str:
    d = _lf_dir(workspace_path)
    if d is None:
        return ""

    # Save the map PNG as a separate file to keep the JSON small,
    # then store the relative filename in the JSON instead of the raw b64.
    map_b64 = data.get("map_image_b64", "")
    if map_b64:
        try:
            import base64 as _b64
            png_path = d / "land_feasibility_map.png"
            png_path.write_bytes(_b64.b64decode(map_b64))
            # Replace the large b64 blob with just the filename in JSON
            data = {**data, "map_image_b64": "", "map_image_file": png_path.name}
        except Exception:
            pass  # fall back to storing b64 inline

    path = d / _RESULT_FILE
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return str(path)


def _load_saved_result(workspace_path: str | None) -> dict[str, Any] | None:
    d = _lf_dir(workspace_path)
    if d is None:
        return None
    path = d / _RESULT_FILE
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        # Re-load the map PNG from its separate file if saved that way
        map_file = data.get("map_image_file", "")
        if map_file and not data.get("map_image_b64"):
            png_path = d / map_file
            if png_path.exists():
                import base64 as _b64
                data["map_image_b64"] = _b64.b64encode(
                    png_path.read_bytes()
                ).decode()
        return data
    except Exception:
        return None


def _update_project_json(
    workspace_path: str | None, result: LandFeasibilityResult
) -> None:
    if not workspace_path:
        return
    pj = Path(workspace_path) / "project.json"
    if not pj.exists():
        return
    try:
        raw: dict[str, Any] = json.loads(pj.read_text(encoding="utf-8"))
        changed = False
        if not raw.get("latitude") and result.centroid_lat:
            raw["latitude"] = result.centroid_lat
            changed = True
        if not raw.get("longitude") and result.centroid_lon:
            raw["longitude"] = result.centroid_lon
            changed = True
        if not raw.get("address") and result.address:
            raw["address"] = result.address
            changed = True
        if changed:
            pj.write_text(json.dumps(raw, indent=2), encoding="utf-8")
            _dbg("PROJECT_JSON_UPDATED")
    except Exception as exc:
        _dbg("PROJECT_JSON_UPDATE_FAIL", error=str(exc))


def _result_to_dict(result: LandFeasibilityResult, result_path: str = "") -> dict[str, Any]:
    return {
        "timestamp":        result.timestamp,
        "overall_feasible": result.overall_feasible,
        "area_ha":          result.area_ha,
        "address":          result.address,
        "centroid_lat":     result.centroid_lat,
        "centroid_lon":     result.centroid_lon,
        "elapsed_seconds":  result.elapsed_seconds,
        "polygon_coords":   result.polygon_coords,
        "error":            result.error,
        "result_path":      result_path,
        "constraints": [
            {
                "name":          c.name,
                "intersects":    c.intersects,
                "feature_count": c.feature_count,
                "details":       c.details,
            }
            for c in result.constraints
        ],
        "map_image_b64": getattr(result, "map_image_b64", ""),
    }


# =============================================================================
# MAP  —  div HTML (no <script> tag allowed inside ui.html)
# =============================================================================

_MAP_DIV_HTML = """
<div id="lfc-map" style="
    width:  100%;
    height: 480px;
    border-radius: 6px;
    position: relative;
    z-index: 0;
"></div>
"""

# JavaScript injected via ui.run_javascript() (fire-and-forget, no await).
# Uses window.COL_init_map from site_map.js — the same function that
# project_setup_tab uses — then layers a leaflet-draw toolbar on top.
_MAP_INIT_JS = """
(function initLfcMap() {
    var el = document.getElementById('lfc-map');
    if (!el) { setTimeout(initLfcMap, 200); return; }
    if (el.__LFC_MAP_INIT__) {
        if (el.__LFC_MAP_OBJ__) el.__LFC_MAP_OBJ__.invalidateSize();
        return;
    }

    if (typeof window.COL_init_map !== 'function') {
        setTimeout(initLfcMap, 200);
        return;
    }

    // Use the same map engine as project_setup_tab
    var map = window.COL_init_map('lfc-map', {
        statusId:  'lfc-map-status',
        center:    [43.65, -79.38],
        zoom:      11,
        enableDraw: false
    });

    el.__LFC_MAP_INIT__ = true;
    el.__LFC_MAP_OBJ__  = map;
    window.__lfcMap     = map;
    window.__lfc_polygon = null;

    // ── Leaflet.draw toolbar ────────────────────────────────────────
    var drawnItems = new L.FeatureGroup();
    map.addLayer(drawnItems);

    var drawControl = new L.Control.Draw({
        edit: { featureGroup: drawnItems },
        draw: {
            polygon: {
                allowIntersection: false,
                showArea: true,
                shapeOptions: { color: '#2563eb', fillOpacity: 0.15 }
            },
            rectangle: {
                shapeOptions: { color: '#2563eb', fillOpacity: 0.15 }
            },
            polyline:     false,
            circle:       false,
            marker:       false,
            circlemarker: false
        }
    });
    map.addControl(drawControl);

    function extractCoords(layer) {
        var lls  = layer.getLatLngs();
        var ring = Array.isArray(lls[0]) ? lls[0] : lls;
        return ring.map(function(ll) { return [ll.lng, ll.lat]; });
    }

    map.on(L.Draw.Event.CREATED, function(e) {
        drawnItems.clearLayers();
        drawnItems.addLayer(e.layer);
        window.__lfc_polygon = extractCoords(e.layer);
    });
    map.on(L.Draw.Event.EDITED, function(e) {
        e.layers.eachLayer(function(layer) {
            window.__lfc_polygon = extractCoords(layer);
        });
    });
    map.on(L.Draw.Event.DELETED, function() {
        window.__lfc_polygon = null;
    });

    // ── Helpers called by Python ────────────────────────────────────
    window.__lfcDrawPolygon = function(coords) {
        drawnItems.clearLayers();
        var lls  = coords.map(function(c) { return [c[1], c[0]]; });
        var poly = L.polygon(lls, { color: '#2563eb', fillOpacity: 0.15 });
        drawnItems.addLayer(poly);
        map.fitBounds(poly.getBounds(), { padding: [40, 40] });
        window.__lfc_polygon = coords;
    };

    window.__lfcPanTo = function(lat, lon, zoom) {
        map.setView([lat, lon], zoom || 14);
    };

    window.__lfcClear = function() {
        drawnItems.clearLayers();
        window.__lfc_polygon = null;
    };

    setTimeout(function() { map.invalidateSize(); }, 400);
})();
"""


# =============================================================================
# RESULTS CARD
# =============================================================================


def _render_results(data: dict[str, Any], container: ui.element) -> None:
    container.clear()
    with container:
        if data.get("error"):
            with ui.card().classes("w-full border border-red-300 bg-red-50 p-4 mb-4"):
                ui.label("Analysis Error").classes("font-bold text-red-700 text-lg")
                ui.label(data["error"]).classes("text-red-600 text-sm mt-1 break-all")
            return

        feasible = data.get("overall_feasible", False)
        v_color  = "bg-green-50 border-green-400" if feasible else "bg-red-50 border-red-400"
        v_icon   = "✅" if feasible else "❌"
        v_text   = "Site appears feasible" if feasible else "Site has constraint conflicts"
        v_cls    = "text-green-700" if feasible else "text-red-700"

        with ui.card().classes(f"w-full border {v_color} p-4 mb-4"):
            ui.label(f"{v_icon}  {v_text}").classes(f"font-bold text-lg {v_cls}")
            ui.label(
                f"Completed in {data.get('elapsed_seconds', 0):.1f} s  •  "
                f"{data.get('timestamp', '')}"
            ).classes("text-xs text-slate-500 mt-1")
            rpath = data.get("result_path", "")
            if rpath:
                ui.label(f"Saved → {rpath}").classes(
                    "text-xs text-slate-400 mt-1 break-all font-mono"
                )

        with ui.card().classes("w-full border border-slate-200 p-4 mb-4"):
            ui.label("📍  Site Summary").classes("font-semibold text-slate-700 mb-2")
            with ui.grid(columns=2).classes("gap-2 text-sm"):
                ui.label("Address:").classes("text-slate-500")
                ui.label(data.get("address") or "—").classes("break-all")

                ui.label("Centroid:").classes("text-slate-500")
                ui.label(
                    f"{data.get('centroid_lat', 0):.6f}°N, "
                    f"{data.get('centroid_lon', 0):.6f}°E"
                ).classes("font-mono")

                ha = data.get("area_ha", 0)
                ui.label("Parcel area:").classes("text-slate-500")
                ui.label(f"{ha:.2f} ha  ({ha * 2.471:.2f} acres)")

                ui.label("Polygon vertices:").classes("text-slate-500")
                ui.label(str(len(data.get("polygon_coords", []))))

        layers = data.get("constraints", [])
        if layers:
            with ui.card().classes("w-full border border-slate-200 p-4"):
                ui.label("🗺️  Environmental & Regulatory Constraints").classes(
                    "font-semibold text-slate-700 mb-3"
                )
                for layer in layers:
                    ok      = not layer.get("intersects", False)
                    badge   = (
                        "bg-green-100 text-green-800 border-green-300" if ok
                        else "bg-red-100 text-red-800 border-red-300"
                    )
                    icon    = "✅" if ok else "⚠️"
                    details = layer.get("details", [])
                    status  = "Clear" if ok else f"Conflict  ({len(details)} feature(s))"

                    with ui.row().classes(
                        "items-center gap-3 py-2 border-b border-slate-100 last:border-0"
                    ):
                        ui.label(f"{icon}  {layer['name']}").classes(
                            "flex-1 text-sm font-medium text-slate-700"
                        )
                        ui.label(status).classes(
                            f"text-xs px-2 py-1 rounded border {badge}"
                        )

                    if details:
                        with ui.expansion(
                            f"View {len(details)} matched feature(s)", value=False
                        ).classes("ml-6 text-xs text-slate-500"):
                            for d in details[:10]:
                                ui.label(
                                    f"  •  {d.get('name','?')}  [{d.get('type','?')}]"
                                ).classes("text-xs text-slate-600")
                            if len(details) > 10:
                                ui.label(f"  … and {len(details) - 10} more").classes(
                                    "text-xs text-slate-400"
                                )

        # ------------------------------------------------------------------
        # Shapefile analysis map  (lfc copy.py output)
        # ------------------------------------------------------------------
        map_b64 = data.get("map_image_b64", "")
        if map_b64:
            with ui.card().classes("w-full border border-slate-200 p-4 mt-4"):
                ui.label("🗺️  Shapefile Analysis Map").classes(
                    "font-semibold text-slate-700 mb-3"
                )
                ui.label(
                    "Parcel boundary (blue) overlaid with protected areas (black), "
                    "wetlands (brown), and forested land (green)."
                ).classes("text-xs text-slate-500 mb-3")
                ui.html(
                    f'<img src="data:image/png;base64,{map_b64}" ' 
                    'style="width:100%;border-radius:6px;display:block;">',
                    sanitize=False,
                ).classes("w-full")


# =============================================================================
# MAIN PANEL ENTRY POINT
# =============================================================================


def render_land_feasibility_panel() -> None:
    """Public entry point — called by land_feasibility_tab()."""

    state = _State()
    q: Queue[_UiMsg] = Queue()

    # ------------------------------------------------------------------
    # Description
    # ------------------------------------------------------------------
    ui.markdown(
        "Draw a polygon on the map to define the land parcel, then click "
        "**Run Feasibility Analysis** to check environmental and regulatory constraints."
    ).classes("text-sm text-slate-600 mb-3")

    # ------------------------------------------------------------------
    # Map div  (no <script> — NiceGUI strips them)
    # ------------------------------------------------------------------
    with ui.card().classes("w-full border border-slate-200 p-0 mb-3 overflow-hidden"):
        ui.html(_MAP_DIV_HTML, sanitize=False).classes("w-full")
        ui.label("").props("id=lfc-map-status").classes("hidden")

    # Fire-and-forget JS — no await, no timeout issues.
    # setTimeout inside the JS gives the DOM 500 ms to settle
    # (same pattern as project_setup_tab.py).
    ui.run_javascript(f"setTimeout(function(){{ {_MAP_INIT_JS} }}, 500);")

    # Re-try on every click so the map appears even if the tab was
    # hidden when the page loaded (same trick as project_setup_tab).
    ui.run_javascript(
        f"""
        document.addEventListener('click', function() {{
            setTimeout(function() {{ {_MAP_INIT_JS} }}, 200);
        }});
        """
    )

    coord_label = ui.label("No polygon drawn yet.").classes(
        "text-xs text-slate-500 mb-3"
    )

    # ------------------------------------------------------------------
    # Location search
    # ------------------------------------------------------------------
    with ui.card().classes("w-full border border-slate-200 p-4 mb-3"):
        ui.label("🔍  Jump to Location").classes("font-semibold text-slate-700 mb-2")
        with ui.row().classes("gap-2 items-center w-full"):
            search_input = ui.input(placeholder="e.g. Hamilton, Ontario").classes("flex-1")
            search_btn   = ui.button("Search", icon="search").classes("bg-slate-700 text-white")
        search_status = ui.label("").classes("text-xs text-slate-500 mt-1")

    async def _on_search() -> None:
        q_text = search_input.value.strip()
        if not q_text:
            search_status.set_text("Please enter an address.")
            return
        search_status.set_text("Searching…")
        try:
            import requests as _req

            resp = await run.io_bound(
                lambda: _req.get(
                    "https://nominatim.openstreetmap.org/search",
                    params={"q": q_text, "format": "json", "limit": 1},
                    timeout=8,
                    headers={"User-Agent": "COL-LandFeasibility/1.0"},
                )
            )
            hits = resp.json()
            if hits:
                lat = float(hits[0]["lat"])
                lon = float(hits[0]["lon"])
                # Fire-and-forget pan — no await avoids the 1 s timeout
                ui.run_javascript(f"if(window.__lfcPanTo) window.__lfcPanTo({lat},{lon},14);")
                search_status.set_text(f"Panned to: {hits[0]['display_name'][:80]}")
            else:
                search_status.set_text("Location not found.")
        except Exception as exc:
            search_status.set_text(f"Search error: {exc}")

    search_btn.on("click", _on_search)
    search_input.on("keydown.enter", _on_search)

    # ------------------------------------------------------------------
    # Manual coordinate input
    # ------------------------------------------------------------------
    with ui.expansion("✏️  Enter coordinates manually", value=False).classes(
        "w-full border border-slate-200 rounded mb-3"
    ):
        ui.label(
            "Paste a JSON array of [longitude, latitude] pairs:\n"
            "[[-79.102, 43.900], [-79.105, 43.896], [-79.101, 43.896]]"
        ).classes("text-xs text-slate-500 mb-2 whitespace-pre-wrap font-mono")
        coord_textarea = (
            ui.textarea(placeholder="[[lon, lat], ...]")
            .classes("w-full font-mono text-xs")
            .props("rows=4")
        )
        coord_parse_status = ui.label("").classes("text-xs text-slate-500 mt-1")

        async def _apply_coords() -> None:
            raw = coord_textarea.value.strip()
            try:
                coords = json.loads(raw)
                if not isinstance(coords, list) or len(coords) < 3:
                    raise ValueError("Need at least 3 [lon, lat] pairs.")
                for c in coords:
                    if not (isinstance(c, (list, tuple)) and len(c) == 2):
                        raise ValueError("Each item must be [lon, lat].")
                state.polygon_coords = coords
                coord_label.set_text(f"Polygon: {len(coords)} vertices (manual)")
                coord_parse_status.set_text("✅ Applied.")
                ui.run_javascript(
                    f"if(window.__lfcDrawPolygon) window.__lfcDrawPolygon({json.dumps(coords)});"
                )
            except Exception as exc:
                coord_parse_status.set_text(f"⚠️  {exc}")

        ui.button("Apply", icon="done").classes("mt-2 bg-slate-700 text-white").on(
            "click", _apply_coords
        )

    # ------------------------------------------------------------------
    # Run controls
    # ------------------------------------------------------------------
    with ui.row().classes("gap-3 items-center mb-2"):
        run_btn   = ui.button("▶  Run Feasibility Analysis", icon="analytics").classes(
            "bg-blue-700 text-white"
        )
        clear_btn = ui.button("Clear", icon="delete").classes("bg-slate-200 text-slate-700")
        spinner   = ui.spinner(size="sm").classes("ml-2")
        spinner.set_visibility(False)

    progress_bar = ui.linear_progress(value=0).classes("w-full mb-1")
    progress_bar.set_visibility(False)
    status_label = ui.label("").classes("text-sm text-slate-600 mb-2")

    # ------------------------------------------------------------------
    # Log
    # ------------------------------------------------------------------
    with ui.card().classes("w-full border border-slate-200 p-2 mb-4"):
        ui.label("Analysis Log").classes("text-xs font-semibold text-slate-500 mb-1")
        log_el = ui.log(max_lines=MAX_LOG_LINES).classes("w-full h-36 font-mono text-xs")

    # ------------------------------------------------------------------
    # Results container
    # ------------------------------------------------------------------
    results_container = ui.column().classes("w-full")

    # ------------------------------------------------------------------
    # Queue drain (0.5 s timer)
    # ------------------------------------------------------------------
    def _drain() -> None:
        try:
            while True:
                msg   = q.get_nowait()
                mtype = msg.type
                p     = msg.payload

                if mtype == "status":
                    progress_bar.set_visibility(True)
                    progress_bar.set_value(float(p.get("progress", 0)))
                    status_label.set_text(p.get("text", ""))
                    ts = datetime.now().strftime("%H:%M:%S")
                    log_el.push(f"[{ts}] {p.get('text', '')}")

                elif mtype == "result":
                    progress_bar.set_value(1.0)
                    data = p["data"]
                    _render_results(data, results_container)
                    ha       = data.get("area_ha", 0)
                    feasible = data.get("overall_feasible", False)
                    status_label.set_text(
                        f"{'✅ Feasible' if feasible else '❌ Constraints found'}"
                        f"  |  {ha:.2f} ha"
                        f"  |  {data.get('elapsed_seconds', 0):.1f} s"
                    )

                elif mtype == "error":
                    progress_bar.set_value(0)
                    status_label.set_text("⚠️  Error — see log")
                    ts = datetime.now().strftime("%H:%M:%S")
                    log_el.push(f"[{ts}] ERROR: {p.get('error', '')}")

        except Empty:
            pass

    ui.timer(0.5, _drain)

    # ------------------------------------------------------------------
    # Map polling — reads polygon from JS global every 800 ms
    # ------------------------------------------------------------------
    async def _poll_map() -> None:
        try:
            coords = await ui.run_javascript(
                "window.__lfc_polygon || null", timeout=5.0
            )
            if isinstance(coords, list) and len(coords) >= 3:
                if coords != state.polygon_coords:
                    state.polygon_coords = coords
                    n    = len(coords)
                    clat = sum(c[1] for c in coords) / n
                    clon = sum(c[0] for c in coords) / n
                    coord_label.set_text(
                        f"Polygon: {n} vertices  |  "
                        f"centroid {clat:.5f}°N, {clon:.5f}°E"
                    )
        except Exception:
            pass

    ui.timer(0.8, _poll_map)

    # ------------------------------------------------------------------
    # Status callback (called from background thread → queue)
    # ------------------------------------------------------------------
    def _cb_status(progress: float, text: str) -> None:
        q.put(_UiMsg("status", {"progress": progress, "text": text}))

    # ------------------------------------------------------------------
    # Run button
    # ------------------------------------------------------------------
    async def _on_run() -> None:
        if state.running:
            return

        # Last-chance read of drawn polygon
        try:
            coords = await ui.run_javascript(
                "window.__lfc_polygon || null", timeout=5.0
            )
            if isinstance(coords, list) and len(coords) >= 3:
                state.polygon_coords = coords
        except Exception:
            pass

        if not state.polygon_coords or len(state.polygon_coords) < 3:
            status_label.set_text("⚠️  Draw a polygon on the map first.")
            return

        active = app.storage.tab.get("active_project")
        workspace_path: str | None = None
        if isinstance(active, dict):
            workspace_path = active.get("workspace_path")

        results_container.clear()
        log_el.clear()
        progress_bar.set_visibility(True)
        progress_bar.set_value(0)
        status_label.set_text("Starting…")
        state.running = True
        spinner.set_visibility(True)
        run_btn.disable()
        clear_btn.disable()

        coords = state.polygon_coords[:]
        _dbg("RUN_START", vertices=len(coords), workspace=workspace_path)

        try:
            result: LandFeasibilityResult = await run.io_bound(
                run_land_feasibility, coords, _cb_status
            )

            data       = _result_to_dict(result)
            saved_path = await run.io_bound(_save_result, workspace_path, data)
            data["result_path"] = saved_path

            await run.io_bound(_update_project_json, workspace_path, result)

            q.put(_UiMsg("result", {"data": data}))
            _dbg("RUN_DONE", feasible=result.overall_feasible, saved=saved_path)

        except Exception as exc:
            q.put(_UiMsg("error", {"error": repr(exc)}))
            _dbg("RUN_ERROR", error=str(exc))

        finally:
            state.running = False
            spinner.set_visibility(False)
            run_btn.enable()
            clear_btn.enable()

    # ------------------------------------------------------------------
    # Clear button
    # ------------------------------------------------------------------
    async def _on_clear() -> None:
        state.polygon_coords = None
        results_container.clear()
        log_el.clear()
        status_label.set_text("")
        coord_label.set_text("No polygon drawn yet.")
        progress_bar.set_value(0)
        progress_bar.set_visibility(False)
        coord_textarea.set_value("")
        coord_parse_status.set_text("")
        ui.run_javascript("if(window.__lfcClear) window.__lfcClear();")

    run_btn.on("click", _on_run)
    clear_btn.on("click", _on_clear)

    # ------------------------------------------------------------------
    # Restore previous result on tab open (once, after 200 ms)
    # ------------------------------------------------------------------
    async def _restore() -> None:
        try:
            active = app.storage.tab.get("active_project")
            workspace_path: str | None = None
            if isinstance(active, dict):
                workspace_path = active.get("workspace_path")

            previous = await run.io_bound(_load_saved_result, workspace_path)
            if not previous:
                return

            _dbg("RESTORE", timestamp=previous.get("timestamp", "?"))
            status_label.set_text(
                f"Loaded previous result from {previous.get('timestamp', '')}"
            )
            _render_results(previous, results_container)

            coords = previous.get("polygon_coords")
            if coords and len(coords) >= 3:
                state.polygon_coords = coords
                ui.run_javascript(
                    f"if(window.__lfcDrawPolygon)"
                    f" window.__lfcDrawPolygon({json.dumps(coords)});"
                )
                coord_label.set_text(f"Polygon: {len(coords)} vertices (restored)")
        except Exception as exc:
            _dbg("RESTORE_FAILED", error=str(exc))

    ui.timer(0.2, _restore, once=True)
