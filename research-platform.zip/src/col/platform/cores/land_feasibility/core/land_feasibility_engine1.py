"""
src/col/platform/cores/land_feasibility/core/land_feasibility_engine.py

Land Feasibility Analysis Engine
---------------------------------

Purpose
-------
This module provides the pure analysis logic for evaluating land parcels as
candidates for residential microgrid development.  It is deliberately free of
any UI or NiceGUI code so that it can be invoked from the orchestration layer,
from tests, or from the UI panel without coupling concerns.

Responsibilities
----------------
1. Accept a polygon geometry (list of [lon, lat] coordinate pairs) that was
   drawn by the user on the interactive map.
2. Resolve the nearest weather station for the site centroid (reuses the
   platform weather module).
3. Query the Overpass API to fetch nearby environmental constraints:
      - Wetlands / water bodies
      - Protected / restricted areas (nature reserves, national parks)
      - Wooded / forested land
4. Compute the area of the parcel in hectares.
5. Determine intersection / proximity flags for every constraint layer.
6. Assemble and return a structured ``LandFeasibilityResult`` dataclass that
   the UI panel can render without further processing.

Design Note
-----------
All network I/O (Overpass queries) is performed synchronously and is intended
to be executed inside ``run.io_bound()`` when called from the NiceGUI UI so
that the event loop is not blocked.

Execution Flow
--------------
UI Panel
    -> run.io_bound(run_land_feasibility, polygon_coords)
        -> LandFeasibilityEngine.run()
            -> _compute_area()
            -> _fetch_overpass_constraints()
            -> _check_intersections()
            -> LandFeasibilityResult
"""

from __future__ import annotations

# =============================================================================
# STANDARD LIBRARY IMPORTS
# =============================================================================

import base64
import io
import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

# =============================================================================
# THIRD-PARTY IMPORTS
# =============================================================================

import requests
from shapely.geometry import Point, Polygon, shape
from shapely.ops import transform
import pyproj

# =============================================================================
# DEBUG CONFIGURATION
# =============================================================================

DEBUG_PREFIX = "[LFC_ENGINE]"


def _dbg(tag: str, **kwargs: Any) -> None:
    """Structured terminal debug printer matching the platform convention."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    if kwargs:
        payload = " | ".join(f"{k}={v!r}" for k, v in kwargs.items())
        print(f"{DEBUG_PREFIX} {ts} {tag} | {payload}", flush=True)
    else:
        print(f"{DEBUG_PREFIX} {ts} {tag}", flush=True)


# =============================================================================
# STATUS CALLBACK TYPE
# =============================================================================

StatusCb = Optional[Callable[[float, str], None]]
"""
Optional callback(progress: float, text: str) used to stream progress
updates back to the UI panel while the engine runs in a background thread.
progress is in [0.0, 1.0].
"""


def _emit(status_cb: StatusCb, progress: float, text: str) -> None:
    """Fire the status callback safely — ignores all exceptions."""
    _dbg("PROGRESS", pct=int(progress * 100), text=text)
    if status_cb is not None:
        try:
            status_cb(progress, text)
        except Exception:
            pass


# =============================================================================
# RESULT DATA STRUCTURES
# =============================================================================


@dataclass
class ConstraintLayer:
    """
    Represents a single environmental or regulatory constraint layer.

    Attributes
    ----------
    name:
        Human-readable layer name shown in the UI (e.g. "Wetlands").
    intersects:
        True if the user polygon overlaps with at least one feature in
        this layer.
    feature_count:
        Number of OSM features returned by the Overpass query.
    details:
        Optional list of dict with {name, type} for matched features.
    overpass_tag:
        The Overpass QL tag string used to fetch this layer (for logging).
    """

    name: str
    intersects: bool
    feature_count: int
    details: list[dict[str, str]] = field(default_factory=list)
    overpass_tag: str = ""


@dataclass
class LandFeasibilityResult:
    """
    Structured output of a completed land feasibility analysis.

    Attributes
    ----------
    polygon_coords:
        Original [[lon, lat], ...] coordinates as supplied by the user.
    centroid_lon, centroid_lat:
        Geographic centroid of the polygon.
    area_ha:
        Parcel area in hectares (computed in metric projection EPSG:3857).
    address:
        Reverse-geocoded address string for the centroid (may be empty if the
        Nominatim call fails).
    constraints:
        Ordered list of ConstraintLayer objects — one per checked layer.
    overall_feasible:
        True only when **none** of the constraint layers report an
        intersection.  The UI may choose to override this with more nuanced
        logic.
    elapsed_seconds:
        Wall-clock time of the analysis run.
    error:
        Non-empty string if the analysis failed; the UI should surface this
        to the user.
    timestamp:
        ISO-8601 timestamp of when the analysis completed.
    """

    polygon_coords: list[list[float]]
    centroid_lon: float
    centroid_lat: float
    area_ha: float
    address: str
    constraints: list[ConstraintLayer]
    overall_feasible: bool
    elapsed_seconds: float
    error: str = ""
    map_image_b64: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds")
    )


# =============================================================================
# OVERPASS QUERY DEFINITIONS
# =============================================================================

# Each entry: (layer_name, overpass_tag_filter)
# The tag filter is inserted verbatim into the Overpass QL body.
_CONSTRAINT_LAYERS: list[tuple[str, str]] = [
    (
        "Wetlands / Water bodies",
        '(way["natural"="wetland"]({{bbox}});way["water"]({{bbox}});relation["natural"="wetland"]({{bbox}}););',
    ),
    (
        "Protected / Restricted areas",
        '(way["boundary"="protected_area"]({{bbox}});relation["boundary"="protected_area"]({{bbox}});way["leisure"="nature_reserve"]({{bbox}});relation["leisure"="nature_reserve"]({{bbox}}););',
    ),
    (
        "Wooded / Forest land",
        '(way["natural"="wood"]({{bbox}});way["landuse"="forest"]({{bbox}});relation["natural"="wood"]({{bbox}});relation["landuse"="forest"]({{bbox}}););',
    ),
    (
        "Agricultural land",
        '(way["landuse"="farmland"]({{bbox}});way["landuse"="meadow"]({{bbox}}););',
    ),
    (
        "Flood risk zones",
        '(way["flood_prone"="yes"]({{bbox}});way["natural"="floodplain"]({{bbox}}););',
    ),
]

_OVERPASS_URL = "https://overpass-api.de/api/interpreter"
_NOMINATIM_URL = "https://nominatim.openstreetmap.org/reverse"

# Overpass query timeout (seconds passed in the query itself)
_OVERPASS_TIMEOUT = 25


# =============================================================================
# INTERNAL HELPERS
# =============================================================================


def _polygon_to_shapely(coords: list[list[float]]) -> Polygon:
    """
    Convert [[lon, lat], ...] list to a Shapely Polygon.

    Raises
    ------
    ValueError
        If fewer than 3 coordinate pairs are supplied.
    """
    if len(coords) < 3:
        raise ValueError(
            f"A polygon requires at least 3 coordinate pairs; got {len(coords)}."
        )
    # Shapely Polygon expects (x, y) = (lon, lat)
    return Polygon([(c[0], c[1]) for c in coords])


def _compute_area_ha(poly_wgs84: Polygon) -> float:
    """
    Return the area of a WGS-84 polygon in hectares.

    The polygon is re-projected to EPSG:3857 (Web Mercator, metres) before
    computing the area, which gives a reasonable approximation for site-scale
    parcels.
    """
    project = pyproj.Transformer.from_crs(
        "EPSG:4326", "EPSG:3857", always_xy=True
    ).transform
    poly_m = transform(project, poly_wgs84)
    return poly_m.area / 10_000.0  # m² → ha


def _bbox_from_poly(poly: Polygon, buffer_deg: float = 0.005) -> tuple[float, float, float, float]:
    """
    Return (south, west, north, east) bounding box with a small buffer.

    The buffer ensures that features that slightly overlap the parcel edges
    are still captured by the Overpass query.
    """
    minx, miny, maxx, maxy = poly.bounds
    return (
        miny - buffer_deg,
        minx - buffer_deg,
        maxy + buffer_deg,
        maxx + buffer_deg,
    )


def _build_overpass_query(tag_filter: str, bbox: tuple[float, float, float, float]) -> str:
    """
    Build an Overpass QL query string.

    Parameters
    ----------
    tag_filter:
        The raw tag filter string with ``{{bbox}}`` placeholders.
    bbox:
        (south, west, north, east) tuple.
    """
    s, w, n, e = bbox
    bbox_str = f"{s:.6f},{w:.6f},{n:.6f},{e:.6f}"
    body = tag_filter.replace("{{bbox}}", bbox_str)
    return f"[out:json][timeout:{_OVERPASS_TIMEOUT}];\n{body}\nout geom;"


def _fetch_overpass(query: str) -> list[dict]:
    """
    Execute an Overpass QL query and return the list of elements.

    Returns an empty list on any network or parsing error (the engine logs the
    exception and continues so that other layers are still checked).
    """
    try:
        resp = requests.post(
            _OVERPASS_URL,
            data={"data": query},
            timeout=_OVERPASS_TIMEOUT + 5,
            headers={"User-Agent": "COL-LandFeasibility/1.0"},
        )
        resp.raise_for_status()
        return resp.json().get("elements", [])
    except Exception as exc:
        _dbg("OVERPASS_ERROR", error=str(exc))
        return []


def _element_to_shapely(element: dict) -> Polygon | None:
    """
    Convert a single Overpass element (way or relation with geometry) to a
    Shapely polygon.  Returns None if the geometry cannot be parsed.
    """
    try:
        if element.get("type") == "way":
            geom_nodes = element.get("geometry", [])
            if len(geom_nodes) < 3:
                return None
            coords = [(n["lon"], n["lat"]) for n in geom_nodes]
            return Polygon(coords)

        if element.get("type") == "relation":
            # Use the first outer member's geometry as an approximation
            members = element.get("members", [])
            for m in members:
                if m.get("role") == "outer" and m.get("geometry"):
                    coords = [(n["lon"], n["lat"]) for n in m["geometry"]]
                    if len(coords) >= 3:
                        return Polygon(coords)
    except Exception:
        pass
    return None


def _check_layer_intersection(
    parcel: Polygon,
    elements: list[dict],
    layer_name: str,
    tag: str,
) -> ConstraintLayer:
    """
    Determine whether any Overpass element intersects the parcel polygon.

    Returns a populated ConstraintLayer.
    """
    details: list[dict[str, str]] = []
    intersects = False

    for el in elements:
        feat_poly = _element_to_shapely(el)
        if feat_poly is None:
            continue
        try:
            if not feat_poly.is_valid:
                feat_poly = feat_poly.buffer(0)
            if parcel.intersects(feat_poly):
                intersects = True
                tags = el.get("tags", {})
                details.append(
                    {
                        "name": tags.get("name", tags.get("ref", "unnamed")),
                        "type": tags.get("natural", tags.get("landuse", tags.get("boundary", "unknown"))),
                    }
                )
        except Exception:
            pass

    return ConstraintLayer(
        name=layer_name,
        intersects=intersects,
        feature_count=len(elements),
        details=details,
        overpass_tag=tag,
    )


def _reverse_geocode(lon: float, lat: float) -> str:
    """
    Return a human-readable address for a coordinate via Nominatim.

    Returns an empty string if the call fails.
    """
    try:
        resp = requests.get(
            _NOMINATIM_URL,
            params={
                "lat": lat,
                "lon": lon,
                "format": "jsonv2",
                "zoom": 16,
                "addressdetails": 1,
            },
            timeout=10,
            headers={"User-Agent": "COL-LandFeasibility/1.0"},
        )
        resp.raise_for_status()
        data = resp.json()
        return data.get("display_name", "")
    except Exception as exc:
        _dbg("NOMINATIM_ERROR", error=str(exc))
        return ""


# =============================================================================
# SHAPEFILE ANALYSIS  (delegates to lfc_analysis.py)
# =============================================================================
# All shapefile logic — loading, intersection checks, map generation —
# lives in lfc_analysis.py. The engine imports only the entry point.

from col.platform.cores.land_feasibility.core.lfc_analysis import (
    run_lfc_analysis,
    LfcResult,
)


def _UNUSED_generate_map_image(
    parcel_gdf: Any,          # kept as tombstone so grep finds old callers
    status_cb: "StatusCb" = None,
) -> str:
    """
    Reproduce the lfc copy.py matplotlib plot and return it as a
    base64-encoded PNG string ready to embed in an HTML <img> tag.

    Layers plotted (matching lfc copy.py exactly):
        • User parcel polygon    — blue outline
        • Federal protected areas — black
        • Wetlands               — brown
        • Wooded / forest land   — green
        • OpenStreetMap basemap  — via contextily

    Returns an empty string if shapefiles are missing or the plot fails,
    so the rest of the analysis always completes even without local data.
    """
    try:
        import geopandas as gpd
        import matplotlib
        matplotlib.use("Agg")          # non-interactive — never calls plt.show()
        import matplotlib.pyplot as plt
        import contextily as ctx
    except ImportError as exc:
        _dbg("MAP_IMPORT_ERROR", error=str(exc))
        return ""

    _emit(status_cb, 0.90, "Generating shapefile map…")

    try:
        wetland    = gpd.read_file(SHAPEFILE_DIR / "wetland.shp").to_crs(epsg=3857)
        wooded     = gpd.read_file(SHAPEFILE_DIR / "woodedland.shp").to_crs(epsg=3857)
        restricted = gpd.read_file(SHAPEFILE_DIR / "Federal_Protected_Area.shp").to_crs(epsg=3857)
    except Exception as exc:
        _dbg("SHAPEFILE_LOAD_ERROR", error=str(exc))
        return ""

    try:
        xmin, ymin, xmax, ymax = parcel_gdf.total_bounds
        buffer = 5000   # metres — matches lfc copy.py

        fig, ax = plt.subplots(figsize=(8, 8))

        # Parcel outline (blue, no fill — matches lfc copy.py)
        parcel_gdf.plot(ax=ax, facecolor="none", edgecolor="blue", linewidth=2)

        ax.set_xlim(xmin - buffer, xmax + buffer)
        ax.set_ylim(ymin - buffer, ymax + buffer)

        # Basemap
        ctx.add_basemap(ax, source=ctx.providers.OpenStreetMap.Mapnik)

        # Constraint layers (same colours as lfc copy.py)
        restricted.plot(ax=ax, color="black",  linewidth=1, label="Protected areas")
        wetland.plot(   ax=ax, color="brown",   linewidth=1, label="Wetlands")
        wooded.plot(    ax=ax, color="green",   linewidth=1, label="Forest / wooded")

        # Legend
        ax.legend(loc="upper right", fontsize=8)
        ax.set_axis_off()

        # Encode as base64 PNG
        buf = io.BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight", dpi=130)
        plt.close(fig)
        buf.seek(0)
        return base64.b64encode(buf.read()).decode()

    except Exception as exc:
        _dbg("MAP_RENDER_ERROR", error=str(exc))
        plt.close("all")
        return ""


# =============================================================================
# PUBLIC ENGINE ENTRY POINT
# =============================================================================


def run_land_feasibility(
    polygon_coords: list[list[float]],
    status_cb: StatusCb = None,
) -> LandFeasibilityResult:
    """
    Run the full land feasibility analysis for a user-drawn polygon.

    Parameters
    ----------
    polygon_coords:
        List of ``[longitude, latitude]`` pairs that form the parcel boundary.
        Must contain at least 3 pairs.  The ring does **not** need to be
        explicitly closed (the engine closes it automatically if needed).

    Returns
    -------
    LandFeasibilityResult
        Fully populated result object.  On fatal error the ``error`` field is
        non-empty and ``overall_feasible`` is False.

    Notes
    -----
    This function performs blocking network I/O (Overpass + Nominatim) and must
    be wrapped in ``run.io_bound()`` when called from NiceGUI.
    """
    t0 = time.monotonic()
    _dbg("RUN_START", coord_count=len(polygon_coords))
    _emit(status_cb, 0.0, "Starting analysis…")

    # ------------------------------------------------------------------
    # 1. Build Shapely geometry
    # ------------------------------------------------------------------
    _emit(status_cb, 0.05, "Building parcel geometry…")
    try:
        parcel = _polygon_to_shapely(polygon_coords)
        if not parcel.is_valid:
            parcel = parcel.buffer(0)
    except Exception as exc:
        return LandFeasibilityResult(
            polygon_coords=polygon_coords,
            centroid_lon=0.0,
            centroid_lat=0.0,
            area_ha=0.0,
            address="",
            constraints=[],
            overall_feasible=False,
            elapsed_seconds=time.monotonic() - t0,
            error=f"Invalid polygon geometry: {exc}",
        )

    centroid = parcel.centroid
    clon, clat = centroid.x, centroid.y

    # ------------------------------------------------------------------
    # 2. Compute area
    # ------------------------------------------------------------------
    try:
        area_ha = _compute_area_ha(parcel)
    except Exception as exc:
        _dbg("AREA_ERROR", error=str(exc))
        area_ha = 0.0

    _dbg("GEOMETRY_READY", centroid_lon=clon, centroid_lat=clat, area_ha=round(area_ha, 4))

    # ------------------------------------------------------------------
    # 3. Reverse-geocode centroid
    # ------------------------------------------------------------------
    _emit(status_cb, 0.10, "Reverse-geocoding location…")
    address = _reverse_geocode(clon, clat)
    _dbg("ADDRESS", value=address[:80] if address else "(none)")

    # ------------------------------------------------------------------
    # 4. Fetch and check each constraint layer
    # ------------------------------------------------------------------
    bbox = _bbox_from_poly(parcel)
    constraints: list[ConstraintLayer] = []
    n_layers = len(_CONSTRAINT_LAYERS)

    for i, (layer_name, tag_filter) in enumerate(_CONSTRAINT_LAYERS):
        progress = 0.15 + (i / n_layers) * 0.80
        _emit(status_cb, progress, f"Checking: {layer_name}…")
        _dbg("LAYER_START", layer=layer_name)
        query = _build_overpass_query(tag_filter, bbox)
        elements = _fetch_overpass(query)
        _dbg("LAYER_FETCHED", layer=layer_name, element_count=len(elements))
        layer_result = _check_layer_intersection(parcel, elements, layer_name, tag_filter)
        constraints.append(layer_result)
        _dbg(
            "LAYER_DONE",
            layer=layer_name,
            intersects=layer_result.intersects,
            matched=len(layer_result.details),
        )

    # ------------------------------------------------------------------
    # 5. Overall feasibility verdict
    # ------------------------------------------------------------------
    overall_feasible = not any(c.intersects for c in constraints)

    # ------------------------------------------------------------------
    # 6. Shapefile analysis (lfc_analysis.py — your lfc copy.py logic)
    # ------------------------------------------------------------------
    _emit(status_cb, 0.85, "Running shapefile analysis…")
    try:
        lfc_result: LfcResult = run_lfc_analysis(
            polygon_coords=polygon_coords,
            status_cb=status_cb,
        )
        map_image_b64 = lfc_result.map_image_b64
        if lfc_result.error:
            _dbg("LFC_ANALYSIS_ERROR", error=lfc_result.error)
        else:
            _dbg(
                "LFC_ANALYSIS_DONE",
                feasible=lfc_result.overall_feasible,
                map_generated=bool(map_image_b64),
            )
    except Exception as exc:
        _dbg("LFC_ANALYSIS_EXCEPTION", error=str(exc))
        map_image_b64 = ""

    elapsed = time.monotonic() - t0
    verdict = "Feasible" if overall_feasible else "Constraints found"
    _emit(status_cb, 1.0, f"Done in {elapsed:.1f} s — {verdict}")
    _dbg(
        "RUN_COMPLETE",
        overall_feasible=overall_feasible,
        elapsed_s=round(elapsed, 2),
        map_generated=bool(map_image_b64),
    )

    return LandFeasibilityResult(
        polygon_coords=polygon_coords,
        centroid_lon=clon,
        centroid_lat=clat,
        area_ha=area_ha,
        address=address,
        constraints=constraints,
        overall_feasible=overall_feasible,
        elapsed_seconds=elapsed,
        map_image_b64=map_image_b64,
    )
