"""
Ontario GeoHub land feasibility analysis engine.

This module keeps the same public interface as the original
``land_feasibility_engine1.py`` used by the NiceGUI panel:

    run_land_feasibility(polygon_coords, status_cb=None) -> LandFeasibilityResult

``polygon_coords`` must be ``[[lon, lat], ...]``.  The engine checks the parcel
against Ontario GeoHub / Land Information Ontario layers, returns the familiar
``ConstraintLayer`` rows for the UI, and includes a base64 PNG map image.
"""

from __future__ import annotations

import base64
import io
import json
import math
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Optional

import requests


# =============================================================================
# DEBUG / STATUS
# =============================================================================

DEBUG_PREFIX = "[LFC_ENGINE]"
StatusCb = Optional[Callable[[float, str], None]]


def _dbg(tag: str, **kwargs: Any) -> None:
    """Structured terminal debug printer matching the platform convention."""

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    if kwargs:
        payload = " | ".join(f"{k}={v!r}" for k, v in kwargs.items())
        print(f"{DEBUG_PREFIX} {ts} {tag} | {payload}", flush=True)
    else:
        print(f"{DEBUG_PREFIX} {ts} {tag}", flush=True)


def _emit(status_cb: StatusCb, progress: float, text: str) -> None:
    """Fire the status callback safely."""

    _dbg("PROGRESS", pct=int(progress * 100), text=text)
    if status_cb is not None:
        try:
            status_cb(progress, text)
        except Exception:
            pass


# =============================================================================
# RESULT DATA STRUCTURES - kept compatible with land_feasibility_engine1.py
# =============================================================================


@dataclass
class ConstraintLayer:
    """One environmental or regulatory constraint row rendered by the UI."""

    name: str
    intersects: bool
    feature_count: int
    details: list[dict[str, str]] = field(default_factory=list)
    overpass_tag: str = ""
    deducted_area_ha: float = 0.0


@dataclass
class LandFeasibilityResult:
    """Structured output of a completed land feasibility analysis."""

    polygon_coords: list[list[float]]
    centroid_lon: float
    centroid_lat: float
    area_ha: float
    address: str
    constraints: list[ConstraintLayer]
    overall_feasible: bool
    elapsed_seconds: float
    error: str = ""
    map_image_b64: str = ""
    constrained_area_ha: float = 0.0
    remaining_area_ha: float = 0.0
    deduction_method: str = ""
    timestamp: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds")
    )


@dataclass(frozen=True)
class _LayerSpec:
    """Ontario GeoHub/LIO layer query definition."""

    group_name: str
    layer_name: str
    layer_url: str
    out_fields: str
    color: str
    fill_color: str


@dataclass
class _FeatureOverlay:
    """GeoJSON features returned for a layer group."""

    group_name: str
    layer_name: str
    color: str
    fill_color: str
    feature_collection: dict[str, Any]
    error: str = ""

    @property
    def features(self) -> list[dict[str, Any]]:
        return list(self.feature_collection.get("features", []))


@dataclass
class _DeductionSummary:
    """Estimated area removed from the parcel by constraint overlaps."""

    constrained_area_ha: float
    remaining_area_ha: float
    by_group_ha: dict[str, float]
    sample_points: list[tuple[float, float]]
    method: str


@dataclass(frozen=True)
class _Parcel:
    """Small geometry container to avoid optional GIS dependencies."""

    coords: list[tuple[float, float]]

    @property
    def bounds(self) -> tuple[float, float, float, float]:
        longitudes = [coord[0] for coord in self.coords]
        latitudes = [coord[1] for coord in self.coords]
        return min(longitudes), min(latitudes), max(longitudes), max(latitudes)

    @property
    def centroid(self) -> tuple[float, float]:
        ring = self.closed_coords
        signed_area = 0.0
        centroid_x = 0.0
        centroid_y = 0.0
        for (x1, y1), (x2, y2) in zip(ring, ring[1:]):
            cross = x1 * y2 - x2 * y1
            signed_area += cross
            centroid_x += (x1 + x2) * cross
            centroid_y += (y1 + y2) * cross
        signed_area *= 0.5
        if abs(signed_area) < 1e-12:
            return (
                sum(coord[0] for coord in self.coords) / len(self.coords),
                sum(coord[1] for coord in self.coords) / len(self.coords),
            )
        return centroid_x / (6 * signed_area), centroid_y / (6 * signed_area)

    @property
    def closed_coords(self) -> list[tuple[float, float]]:
        if self.coords[0] == self.coords[-1]:
            return self.coords
        return [*self.coords, self.coords[0]]


# =============================================================================
# ONTARIO GEOHUB / LIO SERVICES
# =============================================================================

USER_AGENT = "COL-LandFeasibility/1.0"

LIO_OPEN01_MAPSERVER = (
    "https://ws.lioservices.lrc.gov.on.ca/arcgis2/rest/services/"
    "LIO_OPEN_DATA/LIO_Open01/MapServer"
)
LIO_OPEN03_MAPSERVER = (
    "https://ws.lioservices.lrc.gov.on.ca/arcgis2/rest/services/"
    "LIO_OPEN_DATA/LIO_Open03/MapServer"
)
LIO_OPEN05_MAPSERVER = (
    "https://ws.lioservices.lrc.gov.on.ca/arcgis2/rest/services/"
    "LIO_OPEN_DATA/LIO_Open05/MapServer"
)
LIO_OPEN07_MAPSERVER = (
    "https://ws.lioservices.lrc.gov.on.ca/arcgis2/rest/services/"
    "LIO_OPEN_DATA/LIO_Open07/MapServer"
)

ONTARIO_WETLAND_LAYER = f"{LIO_OPEN01_MAPSERVER}/15"
ONTARIO_CONSERVATION_RESERVE_LAYER = f"{LIO_OPEN03_MAPSERVER}/2"
ONTARIO_PROVINCIAL_PARK_LAYER = f"{LIO_OPEN03_MAPSERVER}/4"
ONTARIO_ANSI_LAYER = f"{LIO_OPEN05_MAPSERVER}/3"
ONTARIO_CROWN_GAME_PRESERVE_LAYER = f"{LIO_OPEN05_MAPSERVER}/7"
ONTARIO_WOODED_AREA_LAYER = f"{LIO_OPEN07_MAPSERVER}/29"

_NOMINATIM_URL = "https://nominatim.openstreetmap.org/reverse"

_LAYER_SPECS: list[_LayerSpec] = [
    _LayerSpec(
        group_name="Wetlands / Water bodies",
        layer_name="Ontario Wetland With Significance",
        layer_url=ONTARIO_WETLAND_LAYER,
        out_fields=(
            "WETLAND_TYPE,EVALUATED_WETLAND_NAME,WETLAND_SIGNIFICANCE,"
            "EVALUATED_WETLAND_IND,SYSTEM_CALCULATED_AREA"
        ),
        color="#0284c7",
        fill_color="#38bdf8",
    ),
    _LayerSpec(
        group_name="Wooded / Forest land",
        layer_name="Ontario Wooded Area",
        layer_url=ONTARIO_WOODED_AREA_LAYER,
        out_fields="WOODED_AREA_TYPE,CLASS_SUBTYPE,SYSTEM_CALCULATED_AREA",
        color="#15803d",
        fill_color="#22c55e",
    ),
    _LayerSpec(
        group_name="Protected / Restricted areas",
        layer_name="Provincial Park Regulated",
        layer_url=ONTARIO_PROVINCIAL_PARK_LAYER,
        out_fields=(
            "PROTECTED_AREA_NAME_ENG,TYPE_ENG,STATUS_ENG,MANAGEMENT_ENG,"
            "REGULATED_AREA,SYSTEM_CALCULATED_AREA"
        ),
        color="#dc2626",
        fill_color="#f87171",
    ),
    _LayerSpec(
        group_name="Protected / Restricted areas",
        layer_name="Conservation Reserve Regulated",
        layer_url=ONTARIO_CONSERVATION_RESERVE_LAYER,
        out_fields=(
            "PROTECTED_AREA_NAME_ENG,TYPE_ENG,STATUS_ENG,MANAGEMENT_ENG,"
            "REGULATED_AREA,SYSTEM_CALCULATED_AREA"
        ),
        color="#dc2626",
        fill_color="#f87171",
    ),
    _LayerSpec(
        group_name="Protected / Restricted areas",
        layer_name="Area of Natural and Scientific Interest (ANSI)",
        layer_url=ONTARIO_ANSI_LAYER,
        out_fields="ANSI_NAME,CLASS_SUBTYPE,ANSI_SIGNIFICANCE,SYSTEM_CALCULATED_AREA",
        color="#ca8a04",
        fill_color="#facc15",
    ),
    _LayerSpec(
        group_name="Protected / Restricted areas",
        layer_name="Crown Game Preserve",
        layer_url=ONTARIO_CROWN_GAME_PRESERVE_LAYER,
        out_fields="OFFICIAL_NAME,REGULATED_IND,SYSTEM_CALCULATED_AREA",
        color="#ca8a04",
        fill_color="#facc15",
    ),
]


# =============================================================================
# GEOMETRY / REQUEST HELPERS
# =============================================================================


def _polygon_to_parcel(coords: list[list[float]]) -> _Parcel:
    """Convert ``[[lon, lat], ...]`` to a validated parcel geometry."""

    if len(coords) < 3:
        raise ValueError(
            f"A polygon requires at least 3 coordinate pairs; got {len(coords)}."
        )
    parsed: list[tuple[float, float]] = []
    for coord in coords:
        if len(coord) != 2:
            raise ValueError("Each coordinate must be [longitude, latitude].")
        lon = float(coord[0])
        lat = float(coord[1])
        if not (-180 <= lon <= 180 and -90 <= lat <= 90):
            raise ValueError(f"Coordinate out of range: {coord!r}")
        parsed.append((lon, lat))
    if parsed[0] == parsed[-1]:
        parsed.pop()
    if len(set(parsed)) < 3:
        raise ValueError("A polygon requires at least 3 unique coordinate pairs.")
    return _Parcel(parsed)


def _compute_area_ha(parcel: _Parcel) -> float:
    """Return WGS-84 polygon area in hectares.

    This uses a local equirectangular projection centered on the parcel
    latitude.  It avoids a hard dependency on pyproj while remaining accurate
    enough for parcel-scale screening.
    """

    radius = 6378137.0
    _, centroid_lat = parcel.centroid
    center_lat = math.radians(centroid_lat)
    projected = [
        (
            radius * math.radians(lon) * math.cos(center_lat),
            radius * math.radians(lat),
        )
        for lon, lat in parcel.closed_coords
    ]
    area = 0.0
    for (x1, y1), (x2, y2) in zip(projected, projected[1:]):
        area += x1 * y2 - x2 * y1
    return abs(area) / 2 / 10_000.0


def _arcgis_envelope(parcel: _Parcel, buffer_deg: float = 0.0) -> str:
    """Build an ArcGIS REST envelope around the parcel.

    LIO layers are much more reliable with envelope geometry than exact polygon
    query geometry, while still answering the project question: which Ontario
    layers overlap this parcel area.
    """

    minx, miny, maxx, maxy = parcel.bounds
    return json.dumps(
        {
            "xmin": minx - buffer_deg,
            "ymin": miny - buffer_deg,
            "xmax": maxx + buffer_deg,
            "ymax": maxy + buffer_deg,
            "spatialReference": {"wkid": 4326},
        }
    )


def _http_json(
    url: str,
    params: dict[str, Any],
    *,
    timeout: int = 60,
    method: str = "GET",
    retries: int = 2,
) -> dict[str, Any]:
    """Fetch JSON with small retries for transient GeoHub/network failures."""

    last_error: Exception | None = None
    method = method.upper()
    headers = {
        "Accept": "application/json",
        "User-Agent": USER_AGENT,
    }

    for attempt in range(retries + 1):
        try:
            if method == "POST":
                resp = requests.post(url, data=params, headers=headers, timeout=timeout)
            else:
                resp = requests.get(url, params=params, headers=headers, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except Exception as exc:
            last_error = exc
            if attempt == retries:
                raise
            time.sleep(1.5 * (attempt + 1))

    raise RuntimeError(last_error or "request failed")


def _query_lio_geojson(
    spec: _LayerSpec,
    parcel: _Parcel,
    *,
    record_count: int = 100,
) -> dict[str, Any]:
    """Query an Ontario GeoHub/LIO layer and return intersecting features."""

    params = {
        "f": "geojson",
        "where": "1=1",
        "geometry": _arcgis_envelope(parcel),
        "geometryType": "esriGeometryEnvelope",
        "inSR": 4326,
        "spatialRel": "esriSpatialRelIntersects",
        "outFields": spec.out_fields,
        "returnGeometry": "true",
        "outSR": 4326,
        "geometryPrecision": 6,
        "resultRecordCount": record_count,
    }

    data = _http_json(f"{spec.layer_url}/query", params, timeout=90, method="GET")
    if "error" in data and data["error"].get("message") == "Error performing query operation":
        data = _http_json(f"{spec.layer_url}/query", params, timeout=90, method="POST")
    if "error" in data:
        raise RuntimeError(data["error"].get("message", "ArcGIS query error"))
    if data.get("type") != "FeatureCollection":
        raise RuntimeError(f"Unexpected GeoJSON response from {spec.layer_url}")
    return data


def _format_area_ha(square_meters: Any) -> str:
    try:
        return f"{float(square_meters) / 10000:.2f} ha"
    except (TypeError, ValueError):
        return ""


def _feature_detail(layer_name: str, properties: dict[str, Any]) -> dict[str, str]:
    """Convert LIO attributes to UI-compatible {name, type} details."""

    name = (
        properties.get("EVALUATED_WETLAND_NAME")
        or properties.get("PROTECTED_AREA_NAME_ENG")
        or properties.get("ANSI_NAME")
        or properties.get("OFFICIAL_NAME")
        or properties.get("WOODED_AREA_TYPE")
        or layer_name
    )
    feature_type = (
        properties.get("WETLAND_TYPE")
        or properties.get("WETLAND_SIGNIFICANCE")
        or properties.get("TYPE_ENG")
        or properties.get("CLASS_SUBTYPE")
        or properties.get("ANSI_SIGNIFICANCE")
        or properties.get("REGULATED_IND")
        or layer_name
    )
    area = _format_area_ha(
        properties.get("SYSTEM_CALCULATED_AREA") or properties.get("REGULATED_AREA")
    )
    if area:
        feature_type = f"{feature_type} | {area}"
    return {"name": str(name), "type": str(feature_type)}


def _reverse_geocode(lon: float, lat: float) -> str:
    """Return a human-readable address for a coordinate via Nominatim."""

    try:
        resp = requests.get(
            _NOMINATIM_URL,
            params={
                "lat": lat,
                "lon": lon,
                "format": "jsonv2",
                "zoom": 16,
                "addressdetails": 1,
            },
            timeout=10,
            headers={"User-Agent": USER_AGENT},
        )
        resp.raise_for_status()
        return resp.json().get("display_name", "")
    except Exception as exc:
        _dbg("NOMINATIM_ERROR", error=str(exc))
        return ""


# =============================================================================
# STATIC MAP PNG GENERATION
# =============================================================================


def _lonlat_to_world_pixel(lon: float, lat: float, zoom: int) -> tuple[float, float]:
    tile_size = 256
    scale = tile_size * (2**zoom)
    clamped_lat = max(min(lat, 85.05112878), -85.05112878)
    sin_lat = math.sin(math.radians(clamped_lat))
    x = (lon + 180.0) / 360.0 * scale
    y = (0.5 - math.log((1 + sin_lat) / (1 - sin_lat)) / (4 * math.pi)) * scale
    return x, y


def _lonlat_to_mercator(lon: float, lat: float) -> tuple[float, float]:
    radius = 6378137.0
    clamped_lat = max(min(lat, 85.05112878), -85.05112878)
    x = radius * math.radians(lon)
    y = radius * math.log(math.tan(math.pi / 4 + math.radians(clamped_lat) / 2))
    return x, y


def _tile_mercator_extent(zoom: int, x: int, y: int) -> tuple[float, float, float, float]:
    def tile_to_lon(tile_x: int) -> float:
        return tile_x / (2**zoom) * 360.0 - 180.0

    def tile_to_lat(tile_y: int) -> float:
        n = math.pi - 2.0 * math.pi * tile_y / (2**zoom)
        return math.degrees(math.atan(math.sinh(n)))

    west = tile_to_lon(x)
    east = tile_to_lon(x + 1)
    north = tile_to_lat(y)
    south = tile_to_lat(y + 1)
    west_m, south_m = _lonlat_to_mercator(west, south)
    east_m, north_m = _lonlat_to_mercator(east, north)
    return west_m, east_m, south_m, north_m


def _choose_zoom(bounds: tuple[float, float, float, float]) -> int:
    minx, miny, maxx, maxy = bounds
    lon_span = max(maxx - minx, 0.0001)
    lat_span = max(maxy - miny, 0.0001)
    target_span = max(lon_span, lat_span)
    if target_span < 0.01:
        return 16
    if target_span < 0.03:
        return 15
    if target_span < 0.08:
        return 14
    if target_span < 0.2:
        return 13
    return 12


def _fetch_osm_tile(zoom: int, x: int, y: int) -> bytes | None:
    max_tile = 2**zoom
    if y < 0 or y >= max_tile:
        return None
    x = x % max_tile
    try:
        resp = requests.get(
            f"https://tile.openstreetmap.org/{zoom}/{x}/{y}.png",
            timeout=15,
            headers={"User-Agent": USER_AGENT},
        )
        resp.raise_for_status()
        return resp.content
    except Exception:
        return None


def _iter_positions(geometry: dict[str, Any]) -> list[tuple[float, float]]:
    positions: list[tuple[float, float]] = []

    def walk(value: Any) -> None:
        if (
            isinstance(value, list)
            and len(value) >= 2
            and isinstance(value[0], (int, float))
            and isinstance(value[1], (int, float))
        ):
            positions.append((float(value[0]), float(value[1])))
        elif isinstance(value, list):
            for item in value:
                walk(item)

    if geometry.get("type") == "GeometryCollection":
        for sub_geometry in geometry.get("geometries", []):
            positions.extend(_iter_positions(sub_geometry))
    else:
        walk(geometry.get("coordinates"))
    return positions


def _point_in_ring(lon: float, lat: float, ring: list[Any]) -> bool:
    """Ray-casting point-in-ring test for lon/lat rings."""

    inside = False
    if len(ring) < 3:
        return False
    normalized = [(float(point[0]), float(point[1])) for point in ring]
    x, y = lon, lat
    j = len(normalized) - 1
    for i, (xi, yi) in enumerate(normalized):
        xj, yj = normalized[j]
        intersects = (yi > y) != (yj > y)
        if intersects:
            x_cross = (xj - xi) * (y - yi) / ((yj - yi) or 1e-15) + xi
            if x < x_cross:
                inside = not inside
        j = i
    return inside


def _point_in_polygon_coordinates(lon: float, lat: float, coordinates: list[Any]) -> bool:
    """Return True if a point is inside a GeoJSON Polygon coordinate array."""

    if not coordinates:
        return False
    if not _point_in_ring(lon, lat, coordinates[0]):
        return False
    # Holes subtract from the polygon.
    return not any(_point_in_ring(lon, lat, hole) for hole in coordinates[1:])


def _point_in_geojson_geometry(lon: float, lat: float, geometry: dict[str, Any]) -> bool:
    """Return whether a lon/lat point is inside a GeoJSON polygonal geometry."""

    geometry_type = geometry.get("type")
    coordinates = geometry.get("coordinates")
    if not geometry_type or coordinates is None:
        return False
    if geometry_type == "Polygon":
        return _point_in_polygon_coordinates(lon, lat, coordinates)
    if geometry_type == "MultiPolygon":
        return any(_point_in_polygon_coordinates(lon, lat, polygon) for polygon in coordinates)
    if geometry_type == "GeometryCollection":
        return any(
            _point_in_geojson_geometry(lon, lat, sub_geometry)
            for sub_geometry in geometry.get("geometries", [])
        )
    return False


def _estimate_deductions(
    parcel: _Parcel,
    overlays: list[_FeatureOverlay],
    parcel_area_ha: float,
    target_samples: int = 26000,
) -> _DeductionSummary:
    """Estimate constrained and remaining area inside the parcel.

    The estimate uses a deterministic grid over the parcel bounding box.  This
    keeps the engine compatible with the current project dependencies while
    still deducting only areas that fall inside the user parcel.
    """

    min_lon, min_lat, max_lon, max_lat = parcel.bounds
    lon_span = max(max_lon - min_lon, 1e-9)
    lat_span = max(max_lat - min_lat, 1e-9)
    aspect = lon_span / lat_span
    nx = max(30, min(220, int(math.sqrt(target_samples * aspect))))
    ny = max(30, min(220, int(target_samples / nx)))

    group_features: dict[str, list[dict[str, Any]]] = {}
    for overlay in overlays:
        if overlay.features:
            group_features.setdefault(overlay.group_name, []).extend(overlay.features)

    inside_count = 0
    constrained_count = 0
    by_group_count = {group_name: 0 for group_name in group_features}
    sample_points: list[tuple[float, float]] = []

    for ix in range(nx):
        lon = min_lon + (ix + 0.5) * lon_span / nx
        for iy in range(ny):
            lat = min_lat + (iy + 0.5) * lat_span / ny
            if not _point_in_ring(lon, lat, parcel.closed_coords):
                continue
            inside_count += 1

            hit_groups: list[str] = []
            for group_name, features in group_features.items():
                if any(
                    _point_in_geojson_geometry(lon, lat, feature.get("geometry", {}))
                    for feature in features
                ):
                    hit_groups.append(group_name)

            if hit_groups:
                constrained_count += 1
                if len(sample_points) < 900:
                    sample_points.append((lon, lat))
                for group_name in hit_groups:
                    by_group_count[group_name] += 1

    if inside_count == 0 or parcel_area_ha <= 0:
        return _DeductionSummary(
            constrained_area_ha=0.0,
            remaining_area_ha=max(parcel_area_ha, 0.0),
            by_group_ha={group_name: 0.0 for group_name in group_features},
            sample_points=[],
            method="grid estimate unavailable: no sample points inside parcel",
        )

    constrained_area_ha = parcel_area_ha * constrained_count / inside_count
    by_group_ha = {
        group_name: parcel_area_ha * count / inside_count
        for group_name, count in by_group_count.items()
    }
    return _DeductionSummary(
        constrained_area_ha=constrained_area_ha,
        remaining_area_ha=max(parcel_area_ha - constrained_area_ha, 0.0),
        by_group_ha=by_group_ha,
        sample_points=sample_points,
        method=f"deterministic {nx}x{ny} grid estimate",
    )


def _plot_geojson_geometry(ax: Any, geometry: dict[str, Any], color: str, fill_color: str) -> None:
    geometry_type = geometry.get("type")
    coordinates = geometry.get("coordinates")
    if not geometry_type or coordinates is None:
        return

    def project_ring(ring: list[list[float]]) -> tuple[list[float], list[float]]:
        xy = [_lonlat_to_mercator(float(lon), float(lat)) for lon, lat, *_ in ring]
        return [p[0] for p in xy], [p[1] for p in xy]

    if geometry_type == "Polygon":
        for index, ring in enumerate(coordinates):
            xs, ys = project_ring(ring)
            ax.fill(
                xs,
                ys,
                facecolor=fill_color if index == 0 else "white",
                edgecolor=color,
                linewidth=1.8,
                alpha=0.35 if index == 0 else 0.8,
                zorder=5,
            )
    elif geometry_type == "MultiPolygon":
        for polygon in coordinates:
            _plot_geojson_geometry(
                ax,
                {"type": "Polygon", "coordinates": polygon},
                color,
                fill_color,
            )
    elif geometry_type == "LineString":
        xs, ys = project_ring(coordinates)
        ax.plot(xs, ys, color=color, linewidth=2, zorder=6)
    elif geometry_type == "MultiLineString":
        for line in coordinates:
            _plot_geojson_geometry(
                ax,
                {"type": "LineString", "coordinates": line},
                color,
                fill_color,
            )
    elif geometry_type == "Point":
        x, y = _lonlat_to_mercator(float(coordinates[0]), float(coordinates[1]))
        ax.scatter([x], [y], s=35, c=fill_color, edgecolors=color, zorder=7)
    elif geometry_type == "MultiPoint":
        for point in coordinates:
            _plot_geojson_geometry(
                ax,
                {"type": "Point", "coordinates": point},
                color,
                fill_color,
            )


def _map_bounds(parcel: _Parcel, overlays: list[_FeatureOverlay]) -> tuple[float, float, float, float]:
    minx, miny, maxx, maxy = parcel.bounds
    longitudes = [minx, maxx]
    latitudes = [miny, maxy]
    for overlay in overlays:
        for feature in overlay.features:
            for lon, lat in _iter_positions(feature.get("geometry", {})):
                longitudes.append(lon)
                latitudes.append(lat)
    min_lon, max_lon = min(longitudes), max(longitudes)
    min_lat, max_lat = min(latitudes), max(latitudes)
    lon_pad = max((max_lon - min_lon) * 0.15, 0.003)
    lat_pad = max((max_lat - min_lat) * 0.15, 0.003)
    return min_lon - lon_pad, min_lat - lat_pad, max_lon + lon_pad, max_lat + lat_pad


def _generate_map_image_b64(
    parcel: _Parcel,
    overlays: list[_FeatureOverlay],
    constraints: list[ConstraintLayer],
    deduction: _DeductionSummary,
) -> str:
    """Generate a PNG map image with OSM tiles and GeoHub overlaps."""

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.patches as mpatches
        import matplotlib.pyplot as plt
    except Exception as exc:
        _dbg("MAP_IMPORT_ERROR", error=str(exc))
        return ""

    try:
        bounds = _map_bounds(parcel, overlays)
        zoom = _choose_zoom(bounds)
        min_lon, min_lat, max_lon, max_lat = bounds
        min_x, min_y = _lonlat_to_mercator(min_lon, min_lat)
        max_x, max_y = _lonlat_to_mercator(max_lon, max_lat)

        fig, ax = plt.subplots(figsize=(10, 8), dpi=140)
        ax.set_xlim(min_x, max_x)
        ax.set_ylim(min_y, max_y)

        west_px, north_px = _lonlat_to_world_pixel(min_lon, max_lat, zoom)
        east_px, south_px = _lonlat_to_world_pixel(max_lon, min_lat, zoom)
        start_x = math.floor(west_px / 256)
        end_x = math.floor(east_px / 256)
        start_y = math.floor(north_px / 256)
        end_y = math.floor(south_px / 256)

        for tile_x in range(start_x, end_x + 1):
            for tile_y in range(start_y, end_y + 1):
                tile = _fetch_osm_tile(zoom, tile_x, tile_y)
                if not tile:
                    continue
                image = plt.imread(io.BytesIO(tile), format="png")
                extent = _tile_mercator_extent(zoom, tile_x, tile_y)
                ax.imshow(image, extent=extent, interpolation="bilinear", zorder=0)

        # Returned Ontario GeoHub features.
        legend_patches: list[Any] = []
        for overlay in overlays:
            if not overlay.features:
                continue
            for feature in overlay.features:
                _plot_geojson_geometry(
                    ax,
                    feature.get("geometry", {}),
                    overlay.color,
                    overlay.fill_color,
                )
            legend_patches.append(
                mpatches.Patch(
                    facecolor=overlay.fill_color,
                    edgecolor=overlay.color,
                    alpha=0.5,
                    label=f"{overlay.layer_name} ({len(overlay.features)})",
                )
            )

        # User parcel.
        xs, ys = zip(*[_lonlat_to_mercator(lon, lat) for lon, lat in parcel.closed_coords])
        ax.plot(xs, ys, color="#111827", linewidth=2.8, linestyle="--", zorder=10)
        ax.fill(xs, ys, facecolor="white", alpha=0.08, zorder=9)
        legend_patches.insert(
            0,
            mpatches.Patch(
                facecolor="white",
                edgecolor="#111827",
                alpha=0.8,
                label="Submitted parcel",
            ),
        )

        # Estimated deducted area inside the submitted parcel.
        if deduction.sample_points:
            dx, dy = zip(*[_lonlat_to_mercator(lon, lat) for lon, lat in deduction.sample_points])
            ax.scatter(
                dx,
                dy,
                s=8,
                c="#ef4444",
                marker="s",
                alpha=0.55,
                linewidths=0,
                zorder=11,
                label="Estimated deducted area",
            )
            legend_patches.append(
                mpatches.Patch(
                    facecolor="#ef4444",
                    edgecolor="#b91c1c",
                    alpha=0.55,
                    label=f"Deducted area (~{deduction.constrained_area_ha:.2f} ha)",
                )
            )

        verdict = "Feasible" if not any(c.intersects for c in constraints) else "Constraints found"
        ax.set_title(
            (
                f"Ontario Land Feasibility - {verdict}\n"
                f"Remaining usable area: ~{deduction.remaining_area_ha:.2f} ha"
            ),
            fontsize=13,
            weight="bold",
        )
        if legend_patches:
            ax.legend(handles=legend_patches, loc="upper right", fontsize=7)
        ax.set_axis_off()
        fig.text(
            0.01,
            0.01,
            f"Basemap: OpenStreetMap | Source: Ontario GeoHub/LIO | Zoom {zoom}",
            fontsize=7,
            color="#475569",
        )

        buf = io.BytesIO()
        fig.savefig(buf, format="png", bbox_inches="tight")
        plt.close(fig)
        return base64.b64encode(buf.getvalue()).decode("ascii")
    except Exception as exc:
        _dbg("MAP_RENDER_ERROR", error=str(exc))
        try:
            plt.close("all")  # type: ignore[name-defined]
        except Exception:
            pass
        return ""


# =============================================================================
# ANALYSIS ORCHESTRATION
# =============================================================================


def _query_all_layers(
    parcel: _Parcel,
    status_cb: StatusCb,
) -> tuple[list[ConstraintLayer], list[_FeatureOverlay]]:
    """Query all Ontario GeoHub/LIO layers and return UI constraints + overlays."""

    group_details: dict[str, list[dict[str, str]]] = {
        "Wetlands / Water bodies": [],
        "Wooded / Forest land": [],
        "Protected / Restricted areas": [],
    }
    group_sources: dict[str, list[str]] = {name: [] for name in group_details}
    overlays: list[_FeatureOverlay] = []

    for index, spec in enumerate(_LAYER_SPECS):
        progress = 0.18 + (index / max(len(_LAYER_SPECS), 1)) * 0.55
        _emit(status_cb, progress, f"Checking Ontario GeoHub: {spec.layer_name}...")
        _dbg("LAYER_START", layer=spec.layer_name, group=spec.group_name)

        feature_collection = {"type": "FeatureCollection", "features": []}
        error = ""
        try:
            feature_collection = _query_lio_geojson(spec, parcel)
        except Exception as exc:
            error = str(exc)
            _dbg("LAYER_ERROR", layer=spec.layer_name, error=error)

        features = feature_collection.get("features", [])
        for feature in features:
            group_details[spec.group_name].append(
                _feature_detail(spec.layer_name, feature.get("properties", {}))
            )
        group_sources[spec.group_name].append(spec.layer_url)
        overlays.append(
            _FeatureOverlay(
                group_name=spec.group_name,
                layer_name=spec.layer_name,
                color=spec.color,
                fill_color=spec.fill_color,
                feature_collection=feature_collection,
                error=error,
            )
        )
        _dbg(
            "LAYER_DONE",
            layer=spec.layer_name,
            matched=len(features),
            error=error,
        )

    constraints = [
        ConstraintLayer(
            name=group_name,
            intersects=bool(details),
            feature_count=len(details),
            details=details,
            overpass_tag=";".join(group_sources[group_name]),
        )
        for group_name, details in group_details.items()
    ]
    return constraints, overlays


def _attach_deduction_details(
    constraints: list[ConstraintLayer],
    deduction: _DeductionSummary,
) -> None:
    """Attach estimated deducted area to each UI constraint layer."""

    for layer in constraints:
        deducted_area = deduction.by_group_ha.get(layer.name, 0.0)
        layer.deducted_area_ha = deducted_area
        if deducted_area > 0:
            layer.details.insert(
                0,
                {
                    "name": "Estimated deducted area inside parcel",
                    "type": f"{deducted_area:.2f} ha ({deduction.method})",
                },
            )


# =============================================================================
# PUBLIC ENGINE ENTRY POINT
# =============================================================================


def run_land_feasibility(
    polygon_coords: list[list[float]],
    status_cb: StatusCb = None,
) -> LandFeasibilityResult:
    """Run Ontario GeoHub land feasibility analysis for a user-drawn polygon."""

    t0 = time.monotonic()
    _dbg("RUN_START", coord_count=len(polygon_coords))
    _emit(status_cb, 0.0, "Starting land feasibility analysis...")

    try:
        _emit(status_cb, 0.05, "Building parcel geometry...")
        parcel = _polygon_to_parcel(polygon_coords)
    except Exception as exc:
        return LandFeasibilityResult(
            polygon_coords=polygon_coords,
            centroid_lon=0.0,
            centroid_lat=0.0,
            area_ha=0.0,
            address="",
            constraints=[],
            overall_feasible=False,
            elapsed_seconds=time.monotonic() - t0,
            error=f"Invalid polygon geometry: {exc}",
        )

    clon, clat = parcel.centroid

    try:
        area_ha = _compute_area_ha(parcel)
    except Exception as exc:
        _dbg("AREA_ERROR", error=str(exc))
        area_ha = 0.0

    _dbg("GEOMETRY_READY", centroid_lon=clon, centroid_lat=clat, area_ha=round(area_ha, 4))

    _emit(status_cb, 0.12, "Reverse-geocoding parcel centroid...")
    address = _reverse_geocode(clon, clat)

    _emit(status_cb, 0.18, "Querying Ontario GeoHub/LIO layers...")
    constraints, overlays = _query_all_layers(parcel, status_cb)
    _emit(status_cb, 0.76, "Estimating deducted and remaining parcel area...")
    deduction = _estimate_deductions(parcel, overlays, area_ha)
    _attach_deduction_details(constraints, deduction)
    overall_feasible = not any(layer.intersects for layer in constraints)

    _emit(status_cb, 0.82, "Generating map image...")
    map_image_b64 = _generate_map_image_b64(parcel, overlays, constraints, deduction)

    elapsed = time.monotonic() - t0
    verdict = "Feasible" if overall_feasible else "Constraints found"
    _emit(status_cb, 1.0, f"Done in {elapsed:.1f} s - {verdict}")
    _dbg(
        "RUN_COMPLETE",
        overall_feasible=overall_feasible,
        elapsed_s=round(elapsed, 2),
        map_generated=bool(map_image_b64),
        constrained_area_ha=round(deduction.constrained_area_ha, 4),
        remaining_area_ha=round(deduction.remaining_area_ha, 4),
    )

    return LandFeasibilityResult(
        polygon_coords=polygon_coords,
        centroid_lon=clon,
        centroid_lat=clat,
        area_ha=area_ha,
        address=address,
        constraints=constraints,
        overall_feasible=overall_feasible,
        elapsed_seconds=elapsed,
        map_image_b64=map_image_b64,
        constrained_area_ha=deduction.constrained_area_ha,
        remaining_area_ha=deduction.remaining_area_ha,
        deduction_method=deduction.method,
    )

