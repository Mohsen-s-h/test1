import geopandas as gpd
import matplotlib.pyplot as plt
import contextily as ctx
from shapely.geometry import Point
from shapely.geometry import Polygon

coords = [
    (-79.102699, 43.900722),
    (-79.105777, 43.896995),
    (-79.105544, 43.896007),
    (-79.107148, 43.895485),
    (-79.107588, 43.891646),
    (-79.106553, 43.890994),
    (-79.104898, 43.891348),
    (-79.101018, 43.895970)
]

area = gpd.GeoDataFrame(
    geometry=[Polygon(coords)],
    crs="EPSG:4326"
).to_crs(epsg=3857)

xmin, ymin, xmax, ymax = area.total_bounds


wetland = gpd.read_file("wetland.shp").to_crs(epsg=3857)
print("Wetland area loaded")

wooded = gpd.read_file("woodedland.shp").to_crs(epsg=3857)
print("Wooded area loaded")

restricted = gpd.read_file("Federal_Protected_Area.shp").to_crs(epsg=3857)
print("Restricted area loaded")

# define a bounding box around the point (zoom level)
buffer = 5000  # meters (adjust zoom here)

xmin -= buffer
xmax += buffer
ymin -= buffer
ymax += buffer

restricted_intersects = restricted.intersects(area.geometry.iloc[0])
wetland_intersects = wetland.intersects(area.geometry.iloc[0])
wooded_intersects = wooded.intersects(area.geometry.iloc[0])

print("Checking if the area intersects with:")
if restricted_intersects.any():
    print("⚠️ Area overlaps restricted zone")
else:
    print("✅ Area is safe from restricted zones")
if wetland_intersects.any():
    print("⚠️ Area overlaps wetland area")
else:
    print("✅ Area is safe from wetland areas")
if wooded_intersects.any():
    print("⚠️ Area overlaps wooded area")
else:
    print("✅ Area is safe from wooded areas")


# plot
fig, ax = plt.subplots(figsize=(8, 8))

# plot polygon
area.plot(ax=ax, facecolor='none', edgecolor='blue', linewidth=2)

# set limits based on area
ax.set_xlim(xmin, xmax)
ax.set_ylim(ymin, ymax)

# add basemap
ctx.add_basemap(ax, source=ctx.providers.OpenStreetMap.Mapnik)
restricted.plot(ax=ax, color='black', linewidth=1)
wetland.plot(ax=ax, color='brown', linewidth=1)
wooded.plot(ax=ax, color='green', linewidth=1)


plt.show()