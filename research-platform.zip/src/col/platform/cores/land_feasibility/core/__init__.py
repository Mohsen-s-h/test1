"""
src/col/platform/cores/land_feasibility/core/__init__.py

Land feasibility analysis sub-package.

Contains:
- land_feasibility_engine.py  — pure analysis logic (no UI)
"""
