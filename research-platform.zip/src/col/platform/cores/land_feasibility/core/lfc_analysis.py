"""
src/col/platform/cores/land_feasibility/core/lfc_analysis.py

Land Feasibility Analysis — Shapefile-based Core
-------------------------------------------------

Purpose
-------
This is the structured, production version of lfc copy.py.

It wraps your original analysis logic into clean functions so the engine
(land_feasibility_engine.py) can call it directly and pass the result
to the UI.

What it does
------------
1. load_shapefiles()        — loads wetland, wooded, restricted shapefiles
2. check_intersections()    — checks which layers overlap the parcel polygon
3. generate_map_image()     — produces the matplotlib map (base64 PNG, no plt.show())
4. run_lfc_analysis()       — main entry point: orchestrates all three steps
                              and returns a structured LfcResult dataclass

How it connects to the platform
--------------------------------
land_feasibility_engine.py calls run_lfc_analysis(polygon_coords, status_cb)
and uses the returned LfcResult to:
    - set overall_feasible on LandFeasibilityResult
    - attach map_image_b64 to LandFeasibilityResult for the UI to display

Shapefile location
------------------
Place your .shp files (+ .dbf, .prj, .shx) here:

    src/col/platform/cores/land_feasibility/core/shapefiles/
        wetland.shp
        woodedland.shp
        Federal_Protected_Area.shp

Or change SHAPEFILE_DIR below to any absolute path.
"""

from __future__ import annotations

# =============================================================================
# STANDARD LIBRARY IMPORTS
# =============================================================================

import base64
import io
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

# =============================================================================
# THIRD-PARTY IMPORTS
# =============================================================================


import geopandas as gpd
import matplotlib
matplotlib.use("Agg")           # non-interactive backend — never calls plt.show()
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import contextily as ctx
from shapely.geometry import Polygon


# =============================================================================
# DEBUG
# =============================================================================

DEBUG_PREFIX = "[LFC_ANALYSIS]"


def _dbg(tag: str, **kwargs: Any) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    if kwargs:
        payload = " | ".join(f"{k}={v!r}" for k, v in kwargs.items())
        print(f"{DEBUG_PREFIX} {ts} {tag} | {payload}", flush=True)
    else:
        print(f"{DEBUG_PREFIX} {ts} {tag}", flush=True)


# =============================================================================
# STATUS CALLBACK TYPE
# =============================================================================

StatusCb = Optional[Callable[[float, str], None]]


def _emit(status_cb: StatusCb, progress: float, text: str) -> None:
    """Fire the status callback safely — ignores all exceptions."""
    _dbg("PROGRESS", pct=int(progress * 100), text=text)
    if status_cb is not None:
        try:
            status_cb(progress, text)
        except Exception:
            pass


# =============================================================================
# SHAPEFILE DIRECTORY
# =============================================================================

SHAPEFILE_DIR = Path(__file__).parent / "shapefiles"
"""
Default location for your .shp files.
Change this to an absolute path if your files live elsewhere, e.g.:
    SHAPEFILE_DIR = Path("/data/gis/land_feasibility")
"""


# =============================================================================
# RESULT DATACLASS
# =============================================================================


@dataclass
class IntersectionResult:
    """
    Intersection result for a single shapefile layer.

    Attributes
    ----------
    layer_name:
        Human-readable layer name shown in the UI.
    intersects:
        True if the parcel polygon overlaps at least one feature.
    feature_count:
        Total number of features in the loaded shapefile.
    matched_count:
        Number of features that intersect the parcel.
    """

    layer_name: str
    intersects: bool
    feature_count: int
    matched_count: int


@dataclass
class LfcResult:
    """
    Complete output of run_lfc_analysis().

    Attributes
    ----------
    intersections:
        One IntersectionResult per loaded shapefile layer.
    overall_feasible:
        True only when no layer reports an intersection.
    map_image_b64:
        Base64-encoded PNG of the matplotlib map. Empty string if the
        plot failed or shapefiles were missing.
    error:
        Non-empty if a fatal error occurred (e.g. shapefiles not found).
    """

    intersections: list[IntersectionResult] = field(default_factory=list)
    overall_feasible: bool = True
    map_image_b64: str = ""
    error: str = ""


# =============================================================================
# STEP 1 — LOAD SHAPEFILES
# =============================================================================


def load_shapefiles(
    shapefile_dir: Path = SHAPEFILE_DIR,
) -> dict[str, gpd.GeoDataFrame]:
    """
    Load the three shapefiles into GeoDataFrames re-projected to EPSG:3857.

    Parameters
    ----------
    shapefile_dir:
        Directory containing wetland.shp, woodedland.shp,
        Federal_Protected_Area.shp.

    Returns
    -------
    dict mapping layer name → GeoDataFrame (EPSG:3857).

    Raises
    ------
    FileNotFoundError
        If any shapefile is missing from shapefile_dir.
    """
    files = {
        "Wetlands":          shapefile_dir / "wetland.shp",
        "Wooded / Forest":   shapefile_dir / "woodedland.shp",
        "Protected areas":   shapefile_dir / "Federal_Protected_Area.shp",
    }

    loaded: dict[str, gpd.GeoDataFrame] = {}

    for layer_name, path in files.items():
        if not path.exists():
            raise FileNotFoundError(
                f"Shapefile not found: {path}\n"
                f"Place your .shp files in: {shapefile_dir}"
            )
        gdf = gpd.read_file(path).to_crs(epsg=3857)
        loaded[layer_name] = gdf
        _dbg("SHAPEFILE_LOADED", layer=layer_name, features=len(gdf))

    return loaded


# =============================================================================
# STEP 2 — BUILD PARCEL GEODATAFRAME
# =============================================================================


def build_parcel_gdf(
    polygon_coords: list[list[float]],
) -> gpd.GeoDataFrame:
    """
    Convert a list of [lon, lat] coordinate pairs into a GeoDataFrame
    in EPSG:3857 (Web Mercator, metres) — matching your lfc copy.py.

    Parameters
    ----------
    polygon_coords:
        List of [longitude, latitude] pairs from the Leaflet map,
        e.g. [[-79.102, 43.900], [-79.105, 43.896], ...].
        Minimum 3 pairs required.

    Returns
    -------
    GeoDataFrame with one row (the parcel polygon) in EPSG:3857.
    """
    # Convert [[lon, lat], ...] to (lon, lat) tuples for Shapely
    coords_tuples = [(c[0], c[1]) for c in polygon_coords]

    gdf = gpd.GeoDataFrame(
        geometry=[Polygon(coords_tuples)],
        crs="EPSG:4326",          # input is WGS-84 (lon/lat)
    ).to_crs(epsg=3857)           # reproject to metres for area + intersection

    _dbg("PARCEL_BUILT", vertices=len(coords_tuples), crs="EPSG:3857")
    return gdf


# =============================================================================
# STEP 3 — CHECK INTERSECTIONS
# =============================================================================


def check_intersections(
    parcel_gdf: gpd.GeoDataFrame,
    layers: dict[str, gpd.GeoDataFrame],
) -> list[IntersectionResult]:
    """
    Check whether the parcel polygon intersects each shapefile layer.

    Parameters
    ----------
    parcel_gdf:
        The parcel GeoDataFrame in EPSG:3857 (from build_parcel_gdf).
    layers:
        Dict of layer_name → GeoDataFrame returned by load_shapefiles().

    Returns
    -------
    List of IntersectionResult — one per layer, in the same order as
    the layers dict.
    """
    parcel_geom = parcel_gdf.geometry.iloc[0]
    results: list[IntersectionResult] = []

    for layer_name, gdf in layers.items():
        mask          = gdf.intersects(parcel_geom)
        intersects    = bool(mask.any())
        matched_count = int(mask.sum())

        result = IntersectionResult(
            layer_name    = layer_name,
            intersects    = intersects,
            feature_count = len(gdf),
            matched_count = matched_count,
        )
        results.append(result)

        flag = "⚠️  CONFLICT" if intersects else "✅ clear"
        _dbg(
            "INTERSECTION",
            layer=layer_name,
            result=flag,
            matched=matched_count,
            total=len(gdf),
        )

    return results


# =============================================================================
# STEP 4 — GENERATE MAP IMAGE
# =============================================================================


def generate_map_image(
    parcel_gdf: gpd.GeoDataFrame,
    layers: dict[str, gpd.GeoDataFrame],
    buffer_m: int = 5000,
) -> str:
    """
    Produce the matplotlib + contextily map from lfc copy.py and return
    it as a base64-encoded PNG string.

    The returned string can be embedded directly in HTML:
        <img src="data:image/png;base64,{map_image_b64}">

    This function never calls plt.show() — it uses the Agg (non-interactive)
    backend so it is safe to call from a background thread inside NiceGUI.

    Parameters
    ----------
    parcel_gdf:
        The parcel GeoDataFrame in EPSG:3857.
    layers:
        Dict of layer_name → GeoDataFrame (same dict from load_shapefiles).
    buffer_m:
        Map extent buffer around the parcel bounding box, in metres.
        Default 5000 matches your original lfc copy.py.

    Returns
    -------
    Base64 PNG string, or "" on failure.
    """
    # Layer colours matching lfc copy.py exactly
    layer_colours = {
        "Protected areas": "black",
        "Wetlands":        "brown",
        "Wooded / Forest": "green",
    }

    try:
        xmin, ymin, xmax, ymax = parcel_gdf.total_bounds

        fig, ax = plt.subplots(figsize=(8, 8))

        # ── Parcel polygon (blue outline, no fill) ────────────────────
        parcel_gdf.plot(
            ax=ax,
            facecolor="none",
            edgecolor="blue",
            linewidth=2,
            zorder=5,
        )

        # ── Map extent with buffer ────────────────────────────────────
        ax.set_xlim(xmin - buffer_m, xmax + buffer_m)
        ax.set_ylim(ymin - buffer_m, ymax + buffer_m)

        # ── OpenStreetMap basemap ─────────────────────────────────────
        ctx.add_basemap(ax, source=ctx.providers.OpenStreetMap.Mapnik)

        # ── Constraint layers ─────────────────────────────────────────
        legend_patches = [
            mpatches.Patch(color="blue",  label="Study area")
        ]

        for layer_name, gdf in layers.items():
            colour = layer_colours.get(layer_name, "gray")
            gdf.plot(ax=ax, color=colour, linewidth=1, alpha=0.7)
            legend_patches.append(
                mpatches.Patch(color=colour, label=layer_name)
            )

        # ── Legend and styling ────────────────────────────────────────
        ax.legend(
            handles=legend_patches,
            loc="upper right",
            fontsize=9,
            framealpha=0.9,
        )
        ax.set_title("Land Feasibility — Constraint Layers", fontsize=11, pad=10)
        ax.set_axis_off()

        # ── Encode as base64 PNG ──────────────────────────────────────
        buf = io.BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight", dpi=130)
        plt.close(fig)
        buf.seek(0)
        result = base64.b64encode(buf.read()).decode()
        _dbg("MAP_GENERATED", size_kb=round(len(result) * 0.75 / 1024))
        return result

    except Exception as exc:
        _dbg("MAP_RENDER_ERROR", error=str(exc))
        plt.close("all")
        return ""


# =============================================================================
# MAIN ENTRY POINT — called by land_feasibility_engine.py
# =============================================================================


def run_lfc_analysis(
    polygon_coords: list[list[float]],
    shapefile_dir: Path = SHAPEFILE_DIR,
    status_cb: StatusCb = None,
) -> LfcResult:
    """
    Run the full shapefile-based land feasibility analysis.

    This is the single function called by land_feasibility_engine.py.
    It orchestrates all four steps and returns a structured LfcResult.

    Parameters
    ----------
    polygon_coords:
        List of [longitude, latitude] pairs from the Leaflet map.
        This is the same ``polygon_coords`` the engine receives from the UI.
    shapefile_dir:
        Directory containing the three .shp files.
        Defaults to SHAPEFILE_DIR (next to this file).
    status_cb:
        Optional progress callback(progress: float, text: str).
        Passed in by the engine so the UI log updates during analysis.

    Returns
    -------
    LfcResult
        Always returns a result — on shapefile load failure, error field
        is populated and overall_feasible is False but the rest of the
        engine analysis still completes.

    Example
    -------
    # Standalone test (no UI needed):
    coords = [
        [-79.102699, 43.900722],
        [-79.105777, 43.896995],
        [-79.105544, 43.896007],
        [-79.107148, 43.895485],
        [-79.107588, 43.891646],
        [-79.106553, 43.890994],
        [-79.104898, 43.891348],
        [-79.101018, 43.895970],
    ]
    result = run_lfc_analysis(coords)
    print("Feasible:", result.overall_feasible)
    for r in result.intersections:
        flag = "⚠️" if r.intersects else "✅"
        print(f"  {flag}  {r.layer_name}")
    """
    _dbg("RUN_START", vertices=len(polygon_coords))

    # ------------------------------------------------------------------
    # Step 1 — Build parcel GeoDataFrame from UI coordinates
    # ------------------------------------------------------------------
    _emit(status_cb, 0.00, "Building parcel geometry…")
    try:
        parcel_gdf = build_parcel_gdf(polygon_coords)
    except Exception as exc:
        _dbg("PARCEL_ERROR", error=str(exc))
        return LfcResult(error=f"Parcel geometry error: {exc}")

    # ------------------------------------------------------------------
    # Step 2 — Load shapefiles
    # ------------------------------------------------------------------
    _emit(status_cb, 0.10, "Loading shapefiles…")
    try:
        layers = load_shapefiles(shapefile_dir)
    except FileNotFoundError as exc:
        _dbg("SHAPEFILE_MISSING", error=str(exc))
        # Return gracefully — engine will still show Overpass results
        return LfcResult(error=str(exc))
    except Exception as exc:
        _dbg("SHAPEFILE_ERROR", error=str(exc))
        return LfcResult(error=f"Shapefile load error: {exc}")

    # ------------------------------------------------------------------
    # Step 3 — Intersection checks
    # ------------------------------------------------------------------
    _emit(status_cb, 0.40, "Checking constraint intersections…")
    intersections = check_intersections(parcel_gdf, layers)
    overall_feasible = not any(r.intersects for r in intersections)

    # ------------------------------------------------------------------
    # Step 4 — Generate map image
    # ------------------------------------------------------------------
    _emit(status_cb, 0.75, "Rendering map…")
    map_image_b64 = generate_map_image(parcel_gdf, layers)

    _dbg(
        "RUN_COMPLETE",
        feasible=overall_feasible,
        map_generated=bool(map_image_b64),
    )

    return LfcResult(
        intersections    = intersections,
        overall_feasible = overall_feasible,
        map_image_b64    = map_image_b64,
    )
