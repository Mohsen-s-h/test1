"""
MODULE: PowerShell Execution Utilities
FILE: powershell.py
LOCATION:
src/col/platform/utils/powershell.py

PURPOSE
-------
This module provides a centralized and controlled interface for executing
PowerShell commands within the Energy Systems Research Framework.

It is designed to support external tool integration workflows such as:
- URBANopt CLI execution
- OpenStudio-based simulations
- future external simulation engines

The module ensures consistent handling of:
- process execution
- real-time log streaming
- error propagation
- working directory management

ARCHITECTURAL ROLE
------------------
This module belongs to the utility layer and is used by:

    Orchestration Layer → Utils → External Tools

It decouples:
- execution logic (PowerShell subprocess handling)
from:
- orchestration logic (URBANopt, preprocessing, etc.)

RESPONSIBILITIES
----------------
1. Execute PowerShell commands in a controlled subprocess environment
2. Stream stdout/stderr output in real time
3. Forward logs to UI or logging callbacks
4. Return process exit codes to caller
5. Maintain backward compatibility with legacy interfaces

EXECUTION FLOW
--------------
Typical workflow:

1. Caller constructs a PowerShell command string
2. run_powershell_stream(...) is invoked
3. Subprocess is created with:
   - working directory
   - PowerShell execution flags
4. Output is streamed line-by-line
5. Each line is forwarded to callback (UI log panel / console)
6. Process completes and exit code is returned

TYPICAL CALLER
--------------
- URBANopt runner modules
- Orchestration layer (load forecasting / DER workflows)
- Future external simulation integrations

IMPORTANT NOTES
---------------
- Uses "-ExecutionPolicy Bypass" to avoid script restrictions
- Streams both stdout and stderr via unified output channel
- Callback-based design allows flexible logging (UI / CLI)
- Encoding can be overridden if required
- Designed for real-time feedback during long-running processes
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import subprocess
from pathlib import Path
from typing import Callable, Optional


# ---------------------------------------------------------------------
# Core function: streaming PowerShell execution
# ---------------------------------------------------------------------
# This is the primary execution interface used across the platform.
#
# Features:
# - real-time log streaming
# - unified stdout/stderr handling
# - callback-driven logging
# ---------------------------------------------------------------------


def run_powershell_stream(
    cmd: str,
    cwd: Path,
    on_line: Callable[[str], None],
    *,
    encoding: Optional[str] = None,
) -> int:
    """
    Execute a PowerShell command and stream output line-by-line.

    Parameters
    ----------
    cmd : str
        PowerShell command string to execute.

    cwd : Path
        Working directory in which the command will be executed.

    on_line : Callable[[str], None]
        Callback function invoked for each output line.
        Typically used to update UI logs or console output.

    encoding : Optional[str]
        Optional encoding override for subprocess output.

    Returns
    -------
    int
        Exit code of the PowerShell process.
    """

    # Ensure working directory is a Path object
    cwd = Path(cwd)

    # Launch PowerShell subprocess
    p = subprocess.Popen(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
        cwd=str(cwd),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,  # Merge stderr into stdout stream
        text=True,
        encoding=encoding,
        bufsize=1,  # Line-buffered output
    )

    # Ensure stdout stream is available
    assert p.stdout is not None

    # -----------------------------------------------------------------
    # Stream output in real time
    # -----------------------------------------------------------------
    # Each line is passed to the provided callback function.
    # This enables:
    # - live UI updates
    # - console logging
    # - progress tracking
    # -----------------------------------------------------------------

    for line in p.stdout:
        on_line(line.rstrip())

    # Wait for process completion and return exit code
    return p.wait()


# ---------------------------------------------------------------------
# Compatibility wrapper (legacy interface)
# ---------------------------------------------------------------------
# Maintains backward compatibility with older modules that used
# a simpler logging interface.
#
# This avoids breaking existing code while transitioning to the
# new streaming API.
# ---------------------------------------------------------------------


def run_powershell(cmd: str, cwd: Path, log: Callable[[str], None]) -> int:
    """
    Backward-compatible wrapper for PowerShell execution.

    Parameters
    ----------
    cmd : str
        PowerShell command string.

    cwd : Path
        Working directory.

    log : Callable[[str], None]
        Logging callback (legacy naming).

    Returns
    -------
    int
        Process exit code.
    """

    return run_powershell_stream(cmd=cmd, cwd=cwd, on_line=log)
