"""
src/col/platform/utils/__init__.py

Utility modules for the COL platform.

This package provides shared helper functions and utilities used
across different platform components, including cores, orchestration,
and UI layers. It includes reusable logic for tasks such as file
handling, data processing, environment management, and integrations.

Typical Usage:
- Import utility functions for common operations
- Support cross-module functionality within the platform
"""
