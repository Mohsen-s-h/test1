"""
src/col/platform/__init__.py

Platform modules for the COL system.

This package contains the main platform-level components that organize
and support the system's technical capabilities, including core
functional domains, utilities, weather-related support modules, and
other shared platform services. It serves as the structural layer
between orchestration, technical cores, and higher-level interfaces.

Typical Usage:
- Access platform-level modules and shared services
- Organize and integrate technical core functionalities
"""
