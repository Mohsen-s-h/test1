"""
MODULE: Weather Data Download and Selection Utility
FILE: weather_download.py
LOCATION:
src/col/platform/weather/weather_download.py

PURPOSE
-------
This module provides functionality to:
- identify the closest weather station based on geographic coordinates
- select the most appropriate EPW dataset based on simulation time period
- download and extract weather files (EPW, DDY, STAT)
- post-process EPW files for compatibility with downstream workflows

It is a critical component of the load forecasting pipeline.

RESPONSIBILITIES
----------------
1. Compute distances between project location and candidate weather stations
2. Select nearest station using Haversine distance
3. Choose best EPW dataset based on year range relevance
4. Download weather archive (ZIP file)
5. Extract EPW, DDY, and STAT files
6. Process EPW file for platform compatibility

EXECUTION FLOW
--------------
Typical workflow:

1. Input latitude and longitude are provided
2. Weather station dataset (Excel file) is loaded
3. Distance to all stations is computed
4. Closest station is selected
5. Multiple dataset URLs are evaluated
6. Best dataset is selected based on simulation year proximity
7. ZIP file is downloaded and extracted
8. EPW, DDY, STAT files are located
9. EPW file is processed using process_epw()
10. Paths to extracted files are returned

TYPICAL CALLER
--------------
- Load forecasting orchestrator
- Weather preprocessing modules

IMPORTANT NOTES
---------------
- Uses Haversine distance for geographic proximity
- Supports multiple dataset versions per station
- Dataset selection is based on year midpoint matching
- Output folder is created automatically
- EPW processing step ensures compatibility with URBANopt workflows
"""


# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import os
import re
import zipfile
from pathlib import Path


# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import pandas as pd
import requests


# ---------------------------------------------------------------------
# Internal imports (geospatial + processing utilities)
# ---------------------------------------------------------------------

from col.platform.weather.haversine import haversine
from col.platform.weather.weather_mapping import process_epw


# ---------------------------------------------------------------------
# Select best dataset URL based on year proximity
# ---------------------------------------------------------------------
# Each URL may represent a dataset covering a time range (e.g., 1990–2010).
# This function selects the dataset whose midpoint best matches the
# simulation period midpoint.
# ---------------------------------------------------------------------


def select_best_url(urls, begin_year, end_year):
    sim_mid = (begin_year + end_year) / 2

    best_url = None
    best_diff = float("inf")

    for url in urls:
        # Extract year range from URL (e.g., 1990-2010)
        match = re.search(r"(\d{4})-(\d{4})", url)

        if match:
            start = int(match.group(1))
            end = int(match.group(2))

            dataset_mid = (start + end) / 2

            diff = abs(sim_mid - dataset_mid)

            if diff < best_diff:
                best_diff = diff
                best_url = url

    return best_url


# ---------------------------------------------------------------------
# Main function: download climate files
# ---------------------------------------------------------------------
# Retrieves EPW, DDY, and STAT files for a given location.
# ---------------------------------------------------------------------


def download_climate_file(lat, lon, output_folder):
    """
    Download EPW climate file for given latitude and longitude.

    Parameters
    ----------
    lat : float
        Latitude of project location

    lon : float
        Longitude of project location

    output_folder : str or Path
        Destination folder for downloaded and extracted files

    Returns
    -------
    tuple
        (epw_path, ddy_path, stat_path, zip_path)
    """

    # -----------------------------------------------------------------
    # Locate internal weather data files
    # -----------------------------------------------------------------

    data_folder = Path(__file__).parent / "data"

    excel_path = data_folder / "Region4_Canada_TMYx_EPW_Processing_locations.xlsx"
    climate_csv = data_folder / "zipcode_weather_stations.csv"

    df = pd.read_excel(excel_path)

    # -----------------------------------------------------------------
    # Define simulation time window
    # -----------------------------------------------------------------

    current_year = pd.Timestamp.now().year
    begin_year = current_year - 1
    end_year = current_year

    # -----------------------------------------------------------------
    # Compute distance to all stations
    # -----------------------------------------------------------------

    df["distance"] = df.apply(
        lambda row: haversine(
            lat, lon, row["Latitude (N+/S-)"], row["Longitude (E+/W-)"]
        ),
        axis=1,
    )

    # Select nearest station
    station = df.loc[df["distance"].idxmin()]

    print("Nearest station:", station["City/Station"])

    # -----------------------------------------------------------------
    # Select best dataset URL
    # -----------------------------------------------------------------

    urls = str(station["URL"]).split(";")

    best_url = select_best_url(urls, begin_year, end_year)

    if best_url is None:
        raise ValueError("No suitable climate file found")

    print("Selected file:", best_url)

    # -----------------------------------------------------------------
    # Download ZIP file
    # -----------------------------------------------------------------

    os.makedirs(output_folder, exist_ok=True)

    zip_path = os.path.join(output_folder, best_url.split("/")[-1])

    r = requests.get(best_url)

    with open(zip_path, "wb") as f:
        f.write(r.content)

    print("Downloaded:", zip_path)

    # -----------------------------------------------------------------
    # Extract ZIP contents
    # -----------------------------------------------------------------

    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(output_folder)

    print("Extracted to:", output_folder)

    # -----------------------------------------------------------------
    # Locate extracted files
    # -----------------------------------------------------------------

    epw_path = None
    ddy_path = None
    stat_path = None

    for root, dirs, files in os.walk(output_folder):
        for file in files:
            if file.lower().endswith(".epw"):
                epw_path = os.path.join(root, file)

            elif file.lower().endswith(".ddy"):
                ddy_path = os.path.join(root, file)

            elif file.lower().endswith(".stat"):
                stat_path = os.path.join(root, file)

    # -----------------------------------------------------------------
    # Post-process EPW file
    # ---------------------------------------------------------------------
    # Ensures compatibility with downstream modules (e.g., URBANopt)
    # ---------------------------------------------------------------------

    process_epw(epw_path, climate_csv)

    return epw_path, ddy_path, stat_path, zip_path
