"""
MODULE: Haversine Distance Utility
FILE: haversine.py
LOCATION:
src/col/platform/weather/haversine.py

PURPOSE
-------
This module provides a lightweight implementation of the Haversine formula
to compute the great-circle distance between two geographic coordinates.

The function is typically used in weather and geospatial workflows,
for example:
- selecting nearest weather station
- comparing geographic locations
- distance-based filtering of spatial data

RESPONSIBILITIES
----------------
1. Convert latitude and longitude from degrees to radians
2. Apply the Haversine formula
3. Return distance between two points on Earth

EXECUTION FLOW
--------------
1. Input coordinates (lat/lon in degrees) are provided
2. Values are converted to radians
3. Differences in latitude and longitude are computed
4. Haversine formula is applied
5. Distance is returned in kilometers

TYPICAL CALLER
--------------
- Weather data modules (e.g., station selection)
- Geospatial utilities
- Site selection or proximity analysis

IMPORTANT NOTES
---------------
- Inputs must be in degrees
- Output is in kilometers
- Assumes Earth as a sphere (radius = 6371 km)
- Suitable for most engineering applications (small numerical error acceptable)
"""


# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from math import radians, sin, cos, sqrt, atan2


# ---------------------------------------------------------------------
# Haversine distance function
# ---------------------------------------------------------------------
# Computes great-circle distance between two points on Earth.
# ---------------------------------------------------------------------


def haversine(lat1, lon1, lat2, lon2):
    """
    Compute distance between two latitude/longitude points (in kilometers).

    Parameters
    ----------
    lat1 : float
        Latitude of first point (degrees)

    lon1 : float
        Longitude of first point (degrees)

    lat2 : float
        Latitude of second point (degrees)

    lon2 : float
        Longitude of second point (degrees)

    Returns
    -------
    float
        Distance between the two points in kilometers
    """

    # Earth radius in kilometers
    R = 6371

    # Convert degrees → radians
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])

    # Differences in coordinates
    dlat = lat2 - lat1
    dlon = lon2 - lon1

    # Apply Haversine formula
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    # Distance in kilometers
    return R * c
