"""
MODULE: Weather Mapping and EPW Processing
FILE: weather_mapping.py
LOCATION:
src/col/platform/weather/weather_mapping.py

PURPOSE
-------
This module provides advanced processing and normalization of EPW weather files
to ensure compatibility with downstream simulation tools (e.g., URBANopt/OpenStudio).

It performs:
- Heating Degree Day (HDD) calculation
- Canadian climate zone classification
- Mapping to US IECC climate zones
- Selection of a compatible US weather station
- Modification of EPW header (WMO + country)
- File renaming to reflect updated metadata

This is a critical step for ensuring that simulation engines that rely on
US-based climate standards can correctly interpret Canadian EPW data.

RESPONSIBILITIES
----------------
1. Compute Heating Degree Days (HDD) from EPW data
2. Determine Canadian climate zone based on HDD thresholds
3. Map Canadian zones to US IECC zones
4. Identify nearest US station matching the same IECC zone
5. Replace WMO and country in EPW header
6. Rename EPW file to reflect updated metadata
7. Provide a unified processing pipeline (process_epw)

EXECUTION FLOW
--------------
1. EPW file is provided
2. HDD is calculated from hourly temperature data
3. Canadian climate zone is determined
4. Zone is mapped to US IECC equivalent
5. US station dataset is filtered by IECC zone
6. Nearest US station is selected using Haversine distance
7. EPW header is patched:
   - country → "USA"
   - WMO → new station ID
8. EPW file is renamed accordingly
9. Updated EPW path is returned

TYPICAL CALLER
--------------
- weather_download.py
- Load forecasting orchestrator

IMPORTANT NOTES
---------------
- Assumes EPW temperature column index = 6
- HDD base temperature = 18°C
- Uses approximate distance via Haversine
- Modifies EPW file in-place (header + filename)
- Designed for compatibility with US-based simulation tools
"""


# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

from pathlib import Path


# ---------------------------------------------------------------------
# Third-party imports
# ---------------------------------------------------------------------

import pandas as pd


# ---------------------------------------------------------------------
# Internal imports
# ---------------------------------------------------------------------

from col.platform.weather.haversine import haversine


# ---------------------------------------------------------------------
# Canadian → US IECC climate zone mapping
# ---------------------------------------------------------------------
# Converts Canadian climate zones into US IECC equivalents.
# Required because many simulation tools expect US zoning.
# ---------------------------------------------------------------------

canada_to_us_zone = {4: "4A", 5: "5A", 6: "6A", "7A": "7", "7B": "7", 8: "8"}


# ---------------------------------------------------------------------
# Calculate Heating Degree Days (HDD)
# ---------------------------------------------------------------------
# HDD is computed using:
# HDD = Σ max(0, 18 - daily_avg_temp)
# ---------------------------------------------------------------------


def calculate_hdd_from_epw(epw_path):
    """
    Compute Heating Degree Days from EPW file.

    Parameters
    ----------
    epw_path : str or Path
        Path to EPW file

    Returns
    -------
    float
        Heating Degree Days (HDD)
    """

    # Skip header rows (first 8 lines)
    weather = pd.read_csv(epw_path, skiprows=8, header=None)

    # Column 6 = dry bulb temperature (°C)
    temperature = weather[6]

    # Compute daily average temperature (24-hour grouping)
    daily_temp = temperature.groupby(weather.index // 24).mean()

    # HDD calculation (base temperature = 18°C)
    HDD = sum(max(0, 18 - t) for t in daily_temp)

    return HDD


# ---------------------------------------------------------------------
# Determine Canadian climate zone
# ---------------------------------------------------------------------
# Based on HDD thresholds
# ---------------------------------------------------------------------


def canadian_climate_zone(HDD):
    """
    Classify Canadian climate zone based on HDD.

    Returns
    -------
    int or str
        Canadian climate zone (e.g., 5, 6, "7A")
    """

    if HDD < 3000:
        return 4

    elif HDD < 4000:
        return 5

    elif HDD < 5000:
        return 6

    elif HDD < 6000:
        return "7A"

    elif HDD < 7000:
        return "7B"

    else:
        return 8


# ---------------------------------------------------------------------
# Find nearest US station within same IECC zone
# ---------------------------------------------------------------------
# Filters US dataset by zone, then selects nearest station.
# ---------------------------------------------------------------------


def find_best_us_station(epw_path, zipcode_file, us_zone):
    """
    Find nearest US weather station matching IECC zone.

    Parameters
    ----------
    epw_path : str or Path
        EPW file path (used to extract location)

    zipcode_file : str or Path
        CSV file containing US weather station data

    us_zone : str
        Target IECC zone

    Returns
    -------
    str
        WMO station identifier
    """

    us = pd.read_csv(zipcode_file)

    # Extract lat/lon from EPW header
    header = open(epw_path).readlines()[0]
    parts = header.split(",")

    lat = float(parts[6])
    lon = float(parts[7])

    # Filter by IECC zone
    us_subset = us[us["zipcode_iecc_zone"] == us_zone].copy()

    # Compute distance to all candidate stations
    us_subset["distance"] = us_subset.apply(
        lambda x: haversine(lat, lon, x["station_latitude"], x["station_longitude"]),
        axis=1,
    )

    # Select nearest station
    nearest = us_subset.loc[us_subset["distance"].idxmin()]

    print("[COL WEATHER] Nearest US station:")
    print("Station WMO:", nearest["station_wmo"])
    print("Latitude:", nearest["station_latitude"])
    print("Longitude:", nearest["station_longitude"])
    print("Distance (km):", nearest["distance"])

    return nearest["station_wmo"]


# ---------------------------------------------------------------------
# Replace WMO and country in EPW header + rename file
# ---------------------------------------------------------------------


def replace_wmo_in_epw(epw_path, new_wmo):
    """
    Modify EPW header and rename file.

    Actions:
    - Replace country → USA
    - Replace WMO station ID
    - Rename file to reflect new WMO
    """

    epw_path = Path(epw_path)

    print("\n================ EPW HEADER PATCH =================")

    print("[COL DEBUG] EPW path:", epw_path)

    if not epw_path.exists():
        raise RuntimeError(f"[COL ERROR] EPW file missing: {epw_path}")

    with open(epw_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    header = lines[0].strip().split(",")

    old_wmo = header[5]

    print("[COL DEBUG] Original header:")
    print(",".join(header))

    print("[COL WEATHER] Old WMO:", old_wmo)
    print("[COL WEATHER] New WMO:", new_wmo)

    # Patch header fields
    header[3] = "USA"
    header[5] = str(new_wmo)

    new_header = ",".join(header)

    print("[COL DEBUG] Patched header:")
    print(new_header)

    lines[0] = new_header + "\n"

    with open(epw_path, "w", encoding="utf-8") as f:
        f.writelines(lines)

    print("\n[COL WEATHER] Header successfully patched")

    # Verify header
    with open(epw_path, "r", encoding="utf-8") as f:
        verify_header = f.readline().strip()

    print("[COL DEBUG] HEADER READ BACK FROM FILE:")
    print(verify_header)

    # Rename file to reflect new WMO
    old_name = epw_path.name
    new_name = old_name.replace(str(old_wmo), str(new_wmo))
    new_path = epw_path.parent / new_name

    print("\n[COL WEATHER DEBUG] Renaming EPW file:")
    print("OLD:", old_name)
    print("NEW:", new_name)

    epw_path.rename(new_path)
    epw_path = new_path

    print("\n[COL DEBUG] FILE AFTER RENAME:", epw_path)

    with open(epw_path, "r", encoding="utf-8") as f:
        verify_header = f.readline().strip()

    print("[COL DEBUG] HEADER INSIDE RENAMED FILE:")
    print(verify_header)

    print("====================================================\n")

    return epw_path


# ---------------------------------------------------------------------
# Main EPW processing pipeline
# ---------------------------------------------------------------------


def process_epw(epw_path, zipcode_file):
    """
    Full EPW processing workflow.

    Steps:
    1. Compute HDD
    2. Determine Canadian zone
    3. Map to US IECC zone
    4. Find nearest US station
    5. Patch EPW header + rename file

    Returns
    -------
    Path
        Updated EPW file path
    """

    print("\n================ WEATHER PROCESSING =================")

    print("[COL WEATHER] EPW file:", epw_path)

    HDD = calculate_hdd_from_epw(epw_path)
    print("[COL WEATHER] Calculated HDD:", HDD)

    ca_zone = canadian_climate_zone(HDD)
    print("[COL WEATHER] Canadian climate zone:", ca_zone)

    us_zone = canada_to_us_zone[ca_zone]
    print("[COL WEATHER] Converted US IECC zone:", us_zone)

    print("[COL WEATHER] Searching nearest US station...")

    best_wmo = find_best_us_station(epw_path, zipcode_file, us_zone)

    print("[COL WEATHER] Selected replacement WMO:", best_wmo)

    epw_path = replace_wmo_in_epw(epw_path, best_wmo)

    print("\n[COL WEATHER] EPW patch completed")
    print("====================================================\n")

    return epw_path
