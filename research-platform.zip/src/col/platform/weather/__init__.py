"""
src/col/platform/weather/__init__.py

Weather data utilities for load forecasting workflows.

This package provides weather-related data handling and processing
functionalities used primarily by the load forecasting core, particularly
URBANopt-based simulations. It supports tasks such as weather file
selection, preprocessing, and integration with simulation workflows.

Typical Usage:
- Retrieve and process weather data for URBANopt simulations
- Support load forecasting workflows with climate inputs
"""
