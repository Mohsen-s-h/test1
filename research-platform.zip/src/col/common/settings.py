# src/col/common/settings.py
"""
Application settings and shared configuration defaults.

This module defines common settings utilities used across the platform.
"""
