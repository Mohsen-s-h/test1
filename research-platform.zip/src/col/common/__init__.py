# src/col/common/__init__.py
"""
Common utilities and shared components for the COL platform.

This package contains reusable modules, helpers, and configurations
that are used across different parts of the application, including
UI, platform cores, and orchestration layers.

Typical Usage:
- Import shared utility functions or constants
- Provide centralized access to common functionality
"""
