# common

Shared utilities used across the platform, such as:
- configuration handling
- logging
- file I/O
- unit conversions
