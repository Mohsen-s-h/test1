"""
Energy Systems Research Framework. — UI Configuration
--------------------------------

Purpose
-------
Central configuration module for the UI layer of the Energy Systems Research Framework..

Responsibilities
---------------
• Define persistent storage locations used by the UI
• Provide default paths for external tools (e.g., URBANopt)
• Store application-wide secrets used by NiceGUI session storage

Design Notes
-----------
Keeping configuration values in a dedicated module avoids
hardcoding paths across multiple files and ensures that the
platform remains easier to maintain and deploy.

This module is imported by:
    - app_main.py
    - UI pages
    - platform orchestration components
"""

from __future__ import annotations

from col.config.config_loader import load_app_config


## ------------------------------------------------------------------
## Runs Directory
## ------------------------------------------------------------------
## Root directory where runtime-generated data is stored.
##
## The path is resolved relative to the repository root to keep
## the project portable across machines and environments.
##
## Typical contents:
##     runs/
##         site_design_sessions/
##         other future runtime outputs
## ------------------------------------------------------------------

_cfg = load_app_config()

RUNS_DIR = _cfg.workspace_root


## ------------------------------------------------------------------
## Site Design Sessions Storage
## ------------------------------------------------------------------
## Directory used to persist user-created map design sessions.
##
## Each session corresponds to a timestamped folder that stores:
##     • drawn site geometry
##     • transformer locations
##     • link relationships
## ------------------------------------------------------------------

SITE_SESSIONS_DIR = _cfg.sessions_root

# Ensure directory exists at application startup
SITE_SESSIONS_DIR.mkdir(parents=True, exist_ok=True)


## ------------------------------------------------------------------
## Default External Tool Paths
## ------------------------------------------------------------------
## Optional default paths for URBANopt-related workflows.
##
## These values are used by load forecasting or other cores
## that rely on URBANopt simulations.
##
## Keeping them here avoids hardcoding paths inside UI modules.
## ------------------------------------------------------------------

PROJECTS_ROOT_DEFAULT = str(_cfg.urbanopt_projects_root)

UO_ENV_DEFAULT = str(_cfg.urbanopt_env_script)


## ------------------------------------------------------------------
## NiceGUI Session Storage Secret
## ------------------------------------------------------------------
## Secret used by NiceGUI to secure browser session storage.
##
## In production deployments this value should be replaced
## with a strong random secret stored in environment variables.
## ------------------------------------------------------------------

STORAGE_SECRET = _cfg.storage_secret
