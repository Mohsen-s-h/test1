"""
MODULE: Site Design API (Session & GeoJSON Management)
FILE: site_api.py
LOCATION:
src/col/ui/api/site_api.py

PURPOSE
-------
This module defines REST API endpoints for the Site Design Map UI.

It manages:
- session lifecycle
- GeoJSON feature persistence
- map snapshot storage

This API acts as the backend interface for interactive map editing
in the Energy Systems Research Framework.

ARCHITECTURAL ROLE
------------------
This module belongs to the UI API layer:

    UI (Map) → API → Filesystem (sessions)

It ensures:
- UI does not directly access filesystem
- session data is consistently structured
- GeoJSON is validated before persistence

NOTE
----
Feature linking, semantic relationships, and styling are handled by:
    site_design_links_api (separate module)

RESPONSIBILITIES
----------------
1. Create and manage map editing sessions
2. Persist GeoJSON drawings per session
3. Ensure unique feature IDs in GeoJSON
4. Store session metadata (creation time)
5. Save PNG snapshots of map state
6. Provide endpoints for UI interaction

EXECUTION FLOW
--------------
1. UI creates a new session → POST /sessions
2. Session folder is created
3. UI reads/writes GeoJSON via API
4. Features are validated and stored
5. Snapshot images may be saved
6. Session remains accessible for later editing

TYPICAL CALLER
--------------
- Site Design Map UI (JavaScript frontend)

DATA STORAGE STRUCTURE
----------------------
<workspace>/site_design/sessions/<sid>/
    ├── features.geojson
    ├── session.json
    └── snapshot.png

IMPORTANT NOTES
---------------
- Session IDs follow strict timestamp format
- GeoJSON is validated before saving
- Feature IDs are enforced to be unique
- All paths are scoped to active project workspace
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import base64
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

# ---------------------------------------------------------------------
# UI framework integration (NiceGUI app state)
# ---------------------------------------------------------------------

from nicegui import app

# ---------------------------------------------------------------------
# Third-party API framework
# ---------------------------------------------------------------------

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
# ---------------------------------------------------------------------
# API router configuration
# ---------------------------------------------------------------------

router = APIRouter(prefix="/api/site", tags=["site_design"])


# ---------------------------------------------------------------------
# Session ID validation pattern
# ---------------------------------------------------------------------
# Format: YYYYMMDD_HHMMSS
# ---------------------------------------------------------------------

SESSION_RE = re.compile(r"^\d{8}_\d{6}$")


# ---------------------------------------------------------------------
# Filesystem helpers
# ---------------------------------------------------------------------


def _get_sessions_root() -> Path:
    """
    Resolve the session root directory for the active project.

    Uses NiceGUI app storage to determine current project context.
    """

    active = app.storage.general.get("active_project")
    print("ACTIVE PROJECT:", active)

    if not active:
        raise HTTPException(status_code=400, detail="No active project")

    workspace = Path(active["workspace_path"])

    root = workspace / "site_design" / "sessions"
    root.mkdir(parents=True, exist_ok=True)

    return root


def _ensure_root() -> Path:
    """
    Ensure session root directory exists.
    """
    return _get_sessions_root()


def _sid_path(sid: str) -> Path:
    """
    Validate session ID and return corresponding directory.
    """

    if not SESSION_RE.match(sid):
        raise HTTPException(status_code=400, detail="Invalid session id format")

    return _get_sessions_root() / sid


def _features_path(sid: str) -> Path:
    """
    Path to GeoJSON file for session.
    """
    return _sid_path(sid) / "features.geojson"


def _session_meta_path(sid: str) -> Path:
    """
    Path to session metadata file.
    """
    return _sid_path(sid) / "session.json"


def _snapshot_path(sid: str) -> Path:
    """
    Path to stored PNG snapshot.
    """
    return _sid_path(sid) / "snapshot.png"


def _new_sid() -> str:
    """
    Generate new session ID using timestamp.
    """
    return datetime.now().strftime("%Y%m%d_%H%M%S")


# ---------------------------------------------------------------------
# GeoJSON validation helper
# ---------------------------------------------------------------------


def _fix_duplicate_feature_ids(fc: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ensure all GeoJSON features have unique IDs.

    Some frontend operations (copy/paste/edit) may introduce
    duplicate or missing IDs. This function enforces uniqueness
    to maintain stable downstream processing.
    """

    try:
        features = fc.get("features", [])

        if not isinstance(features, list):
            return fc

        seen: set[str] = set()

        import uuid

        for f in features:
            if not isinstance(f, dict):
                continue

            props = f.get("properties")

            if not isinstance(props, dict):
                props = {}
                f["properties"] = props

            fid = props.get("id")

            if not isinstance(fid, str) or not fid.strip() or fid in seen:
                props["id"] = str(uuid.uuid4())

            seen.add(props["id"])

        return fc

    except Exception:
        return fc


# ---------------------------------------------------------------------
# API: List sessions
# ---------------------------------------------------------------------


@router.get("/sessions")
def list_sessions() -> Dict[str, Any]:
    """
    Return all available session IDs for active project.
    """

    _ensure_root()

    items = []
    root = _get_sessions_root()

    for p in sorted(root.iterdir(), reverse=True):
        if p.is_dir() and SESSION_RE.match(p.name):
            items.append(p.name)

    return {"sessions": items}


# ---------------------------------------------------------------------
# API: Create new session
# ---------------------------------------------------------------------


@router.post("/sessions")
def create_session() -> Dict[str, Any]:
    """
    Create new session and initialize storage files.
    """

    _ensure_root()

    sid = _new_sid()
    sp = _sid_path(sid)

    sp.mkdir(parents=True, exist_ok=False)

    # Initialize empty GeoJSON
    empty = {"type": "FeatureCollection", "features": []}

    _features_path(sid).write_text(json.dumps(empty, indent=2), encoding="utf-8")

    # Initialize session metadata
    _session_meta_path(sid).write_text(
        json.dumps({"created_at": datetime.now().isoformat()}, indent=2),
        encoding="utf-8",
    )

    return {"session_id": sid}


# ---------------------------------------------------------------------
# API: Select session
# ---------------------------------------------------------------------


class SelectSessionReq(BaseModel):
    session_id: str


@router.post("/sessions/select")
def select_session(req: SelectSessionReq) -> Dict[str, Any]:
    """
    Validate existence of session.
    """

    sp = _sid_path(req.session_id)

    if not sp.exists():
        raise HTTPException(status_code=404, detail="Session not found")

    return {"ok": True, "session_id": req.session_id}


# ---------------------------------------------------------------------
# API: Read GeoJSON
# ---------------------------------------------------------------------


@router.get("/sessions/{sid}/geojson")
def read_geojson(sid: str) -> Dict[str, Any]:
    """
    Load GeoJSON features for a session.
    """

    fp = _features_path(sid)

    if not fp.exists():
        sp = _sid_path(sid)

        if not sp.exists():
            raise HTTPException(status_code=404, detail="Session not found")

        # Create empty file if missing
        fp.write_text(
            json.dumps({"type": "FeatureCollection", "features": []}, indent=2),
            encoding="utf-8",
        )

    try:
        return json.loads(fp.read_text(encoding="utf-8"))

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read geojson: {e}")


# ---------------------------------------------------------------------
# API: Write GeoJSON
# ---------------------------------------------------------------------


@router.put("/sessions/{sid}/geojson")
def write_geojson(sid: str, fc: Dict[str, Any]) -> Dict[str, Any]:
    """
    Persist GeoJSON for session after validation.
    """

    sp = _sid_path(sid)

    if not sp.exists():
        raise HTTPException(status_code=404, detail="Session not found")

    if not isinstance(fc, dict) or fc.get("type") != "FeatureCollection":
        raise HTTPException(status_code=400, detail="Invalid GeoJSON FeatureCollection")

    # Ensure feature IDs are unique
    fc = _fix_duplicate_feature_ids(fc)

    fp = _features_path(sid)

    fp.write_text(json.dumps(fc, indent=2), encoding="utf-8")

    return {"ok": True}


# ---------------------------------------------------------------------
# API: Save map snapshot
# ---------------------------------------------------------------------


class SnapshotReq(BaseModel):
    png_data_url: str


@router.post("/sessions/{sid}/snapshot")
def save_snapshot(sid: str, req: SnapshotReq) -> Dict[str, Any]:
    """
    Save PNG snapshot of map canvas for session.
    """

    sp = _sid_path(sid)

    if not sp.exists():
        raise HTTPException(status_code=404, detail="Session not found")

    data_url = req.png_data_url

    if not isinstance(data_url, str) or "base64," not in data_url:
        raise HTTPException(status_code=400, detail="Invalid data url")

    # Decode base64 PNG
    b64 = data_url.split("base64,", 1)[1]
    raw = base64.b64decode(b64)

    _snapshot_path(sid).write_bytes(raw)

    return {"ok": True}
