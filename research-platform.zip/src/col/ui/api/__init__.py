"""
src/col/ui/api/__init__.py

API interface modules for the COL UI layer.

This package contains API-related components that facilitate
communication between the user interface and the underlying
platform services. It handles request routing, data exchange,
and integration with backend functionalities.

Typical Usage:
- Define and manage API endpoints for UI interactions
- Bridge UI components with platform and core modules
"""
