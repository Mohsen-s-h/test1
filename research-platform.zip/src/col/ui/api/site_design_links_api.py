"""
MODULE: Site Design Links API (Transformer ↔ House Linking)
FILE: site_design_links_api.py
LOCATION:
src/col/ui/api/site_design_links_api.py

PURPOSE
-------
This module provides persistence and management of relationships between
transformers and houses within site design sessions.

It maintains a structured linking model stored in links.json, while ensuring
consistency with the authoritative geometry stored in features.geojson.

This module is intentionally isolated from the main map API to allow
independent evolution of the linking subsystem.

ARCHITECTURAL ROLE
------------------
This module belongs to the UI API layer:

    UI (Linking subsystem) → API → Session storage (links.json + features.geojson)

It ensures:
- separation between drawing (geometry) and linking (relationships)
- robust persistence of transformer ↔ house associations
- automatic synchronization with map features

RESPONSIBILITIES
----------------
1. Persist transformer ↔ house relationships
2. Maintain metadata for transformers and houses
3. Ensure schema versioning and backward compatibility
4. Reconcile links.json with features.geojson (source of truth)
5. Preserve user-defined attributes (e.g., transformer colors)
6. Provide safe read/write API endpoints
7. Guarantee atomic file writes to prevent corruption

DATA MODEL (links.json v2)
--------------------------
{
  "version": 2,
  "updated_at": "...",
  "transformers": { "<tx_id>": {...} },
  "houses": { "<house_id>": {...} },
  "links": { "<tx_id>": ["<house_id>", ...] }
}

EXECUTION FLOW
--------------
GET:
1. Load links.json (if exists)
2. Upgrade schema to v2 if needed
3. Read features.geojson (authoritative data)
4. Reconcile metadata and links
5. Persist if changes detected
6. Return normalized v2 document

PUT:
1. Receive incoming link structure from UI
2. Merge with existing data (preserve colors)
3. Reconcile with features.geojson
4. Remove invalid references
5. Persist safely using atomic write
6. Return normalized structure

TYPICAL CALLER
--------------
- Site Design Map UI (linking subsystem)

IMPORTANT NOTES
---------------
- Backward compatible (supports schema upgrade)
- Self-healing (removes deleted features automatically)
- Non-destructive updates (preserves colors and metadata)
- Uses features.geojson as the single source of truth
"""

from __future__ import annotations


# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------
# UI state (NiceGUI)
# ---------------------------------------------------------------------

from nicegui import app as nicegui_app


# ---------------------------------------------------------------------
# FastAPI imports
# ---------------------------------------------------------------------

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse


# ---------------------------------------------------------------------
# Internal config
# ---------------------------------------------------------------------


# ---------------------------------------------------------------------
# Session file path helpers
# ---------------------------------------------------------------------


def _session_dir(site_sessions_dir: Path, session_id: str) -> Path:
    """Return session directory."""
    return site_sessions_dir / session_id


def _features_path(site_sessions_dir: Path, session_id: str) -> Path:
    """Path to features.geojson."""
    return _session_dir(site_sessions_dir, session_id) / "features.geojson"


def _links_path(site_sessions_dir: Path, session_id: str) -> Path:
    """Path to links.json."""
    return _session_dir(site_sessions_dir, session_id) / "links.json"


def _utc_now_iso() -> str:
    """Return UTC timestamp in ISO format."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


# ---------------------------------------------------------------------
# Atomic JSON writer
# ---------------------------------------------------------------------
# Prevents partial writes or file corruption
# ---------------------------------------------------------------------


def _atomic_write_json(path: Path, obj: Any) -> None:
    """
    Safely write JSON file using temporary file replacement.
    """

    path.parent.mkdir(parents=True, exist_ok=True)

    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

    tmp.replace(path)


# ---------------------------------------------------------------------
# Data model (in-memory representation)
# ---------------------------------------------------------------------


@dataclass
class LinksDoc:
    """
    In-memory representation of links.json schema (v2).
    """

    version: int = 2
    updated_at: str = ""
    transformers: Dict[str, Dict[str, Any]] = None
    houses: Dict[str, Dict[str, Any]] = None
    links: Dict[str, List[str]] = None

    def to_dict(self) -> Dict[str, Any]:
        """
        Normalize structure and return JSON-serializable dictionary.
        """

        return {
            "version": 2,
            "updated_at": self.updated_at or _utc_now_iso(),
            "transformers": self.transformers or {},
            "houses": self.houses or {},
            "links": self.links or {},
        }


# ---------------------------------------------------------------------
# Schema initialization / upgrade
# ---------------------------------------------------------------------


def _empty_v2() -> LinksDoc:
    """Create empty v2 schema."""
    return LinksDoc(
        version=2, updated_at=_utc_now_iso(), transformers={}, houses={}, links={}
    )


def _load_json(path: Path) -> Optional[Dict[str, Any]]:
    """Safely load JSON file."""
    if not path.exists():
        return None

    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read {path.name}: {e}")


def _upgrade_to_v2(raw: Dict[str, Any]) -> LinksDoc:
    """
    Upgrade legacy schema to version 2.
    """

    if isinstance(raw, dict) and raw.get("version") == 2:
        doc = _empty_v2()

        doc.updated_at = str(raw.get("updated_at") or _utc_now_iso())
        doc.transformers = dict(raw.get("transformers") or {})
        doc.houses = dict(raw.get("houses") or {})
        doc.links = {str(k): list(v or []) for k, v in (raw.get("links") or {}).items()}

        return doc

    # Fallback: upgrade v1
    doc = _empty_v2()

    links = raw.get("links") if isinstance(raw, dict) else {}

    if isinstance(links, dict):
        doc.links = {str(k): list(v or []) for k, v in links.items()}

    return doc


# ---------------------------------------------------------------------
# Extract feature index (source of truth)
# ---------------------------------------------------------------------


def _read_features_index(
    features_path: Path,
) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, Dict[str, Any]]]:
    """
    Build lookup tables for transformers and houses from features.geojson.
    """

    if not features_path.exists():
        return {}, {}

    raw = _load_json(features_path) or {}

    feats = raw.get("features") or []

    tx: Dict[str, Dict[str, Any]] = {}
    hs: Dict[str, Dict[str, Any]] = {}

    for f in feats:
        if not isinstance(f, dict):
            continue

        props = f.get("properties") or {}

        fid = props.get("id")
        kind = props.get("kind")
        name = props.get("name")

        if not fid or not isinstance(fid, str):
            continue

        if kind == "transformer":
            tx[fid] = {"name": str(name or ""), "kind": "transformer"}

        elif kind == "house":
            hs[fid] = {"name": str(name or ""), "kind": "house"}

    return tx, hs


# ---------------------------------------------------------------------
# Reconciliation logic
# ---------------------------------------------------------------------


def _reconcile_with_features(
    doc: LinksDoc,
    tx_index: Dict[str, Dict[str, Any]],
    hs_index: Dict[str, Dict[str, Any]],
) -> bool:
    """
    Synchronize links.json with features.geojson.
    """

    changed = False

    doc.transformers = doc.transformers or {}
    doc.houses = doc.houses or {}
    doc.links = doc.links or {}

    # Remove deleted transformers
    for tx_id in list(doc.links.keys()):
        if tx_id not in tx_index:
            doc.links.pop(tx_id, None)
            doc.transformers.pop(tx_id, None)
            changed = True

    for tx_id in list(doc.transformers.keys()):
        if tx_id not in tx_index:
            doc.transformers.pop(tx_id, None)
            changed = True

    # Remove deleted houses
    for house_id in list(doc.houses.keys()):
        if house_id not in hs_index:
            doc.houses.pop(house_id, None)
            changed = True

    # Clean invalid house links
    for tx_id, house_ids in list(doc.links.items()):
        new_list = [hid for hid in (house_ids or []) if hid in hs_index]

        if new_list != (house_ids or []):
            doc.links[tx_id] = new_list
            changed = True

    # Sync transformers metadata (preserve color)
    for tx_id, meta in tx_index.items():
        if tx_id not in doc.links:
            doc.links[tx_id] = []
            changed = True

        existing = doc.transformers.get(tx_id, {})
        color = existing.get("color")

        merged = {
            "name": meta.get("name", ""),
            "kind": "transformer",
        }

        if isinstance(color, str) and color.strip():
            merged["color"] = color.strip()

        if doc.transformers.get(tx_id) != merged:
            doc.transformers[tx_id] = merged
            changed = True

    # Sync houses metadata
    for house_id, meta in hs_index.items():
        merged = {"name": meta.get("name", ""), "kind": "house"}

        if doc.houses.get(house_id) != merged:
            doc.houses[house_id] = merged
            changed = True

    if changed:
        doc.updated_at = _utc_now_iso()

    return changed


# ---------------------------------------------------------------------
# API registration
# ---------------------------------------------------------------------


def register_site_design_links_api(
    app, site_sessions_dir: Optional[Path] = None, **_ignored
) -> None:
    """
    Register Site Design Links API endpoints.
    """

    router = APIRouter()

    # Resolve session directory dynamically
    if not site_sessions_dir:
        active = nicegui_app.storage.general.get("active_project")

        if not active:
            raise RuntimeError("No active project selected")

        workspace = Path(active["workspace_path"])
        site_sessions_dir = workspace / "site_design" / "sessions"

    site_sessions_dir = Path(site_sessions_dir)
    site_sessions_dir.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------------
    # GET links
    # --------------------------------------------------------------

    @router.get("/api/site/sessions/{session_id}/links")
    async def get_links(session_id: str):
        links_p = _links_path(site_sessions_dir, session_id)
        features_p = _features_path(site_sessions_dir, session_id)

        raw = _load_json(links_p) or {}
        doc = _upgrade_to_v2(raw)

        tx_index, hs_index = _read_features_index(features_p)

        changed = _reconcile_with_features(doc, tx_index, hs_index)

        if changed:
            _atomic_write_json(links_p, doc.to_dict())

        return JSONResponse(content=doc.to_dict())

    # --------------------------------------------------------------
    # PUT links
    # --------------------------------------------------------------

    @router.put("/api/site/sessions/{session_id}/links")
    async def put_links(session_id: str, request: Request):
        links_p = _links_path(site_sessions_dir, session_id)
        features_p = _features_path(site_sessions_dir, session_id)

        body = await request.json()

        if not isinstance(body, dict):
            raise HTTPException(status_code=400, detail="Expected JSON object")

        existing_raw = _load_json(links_p) or {}
        existing_doc = _upgrade_to_v2(existing_raw)

        incoming_doc = _upgrade_to_v2(body)

        # Preserve existing transformer colors
        existing_doc.transformers = existing_doc.transformers or {}
        incoming_doc.transformers = incoming_doc.transformers or {}

        for tx_id, meta in existing_doc.transformers.items():
            if tx_id not in incoming_doc.transformers:
                incoming_doc.transformers[tx_id] = dict(meta)

        for tx_id, meta in existing_doc.transformers.items():
            if tx_id in incoming_doc.transformers:
                if "color" not in incoming_doc.transformers[tx_id] and "color" in meta:
                    incoming_doc.transformers[tx_id]["color"] = meta["color"]

        # Reconcile with features
        tx_index, hs_index = _read_features_index(features_p)

        _reconcile_with_features(incoming_doc, tx_index, hs_index)

        # Remove invalid references
        incoming_doc.links = {
            tx: houses
            for tx, houses in (incoming_doc.links or {}).items()
            if tx in tx_index
        }

        incoming_doc.transformers = {
            tx: meta
            for tx, meta in (incoming_doc.transformers or {}).items()
            if tx in tx_index
        }

        # Save atomically
        _atomic_write_json(links_p, incoming_doc.to_dict())

        resp = JSONResponse(content=incoming_doc.to_dict())
        resp.headers["X-ENDPOINT"] = "put_links"

        return resp

    app.include_router(router)
