"""
MODULE: Application Header UI Component
FILE: header.py
LOCATION:
src/col/ui/components/header.py

PURPOSE
-------
This module renders the persistent application header for the Energy Systems Research Framework UI.

It provides a reusable top-level interface component that establishes:
- platform branding
- visual consistency
- navigation context
- stable page structure across the application

The header displays:
- left logo
- centered application title
- right logo

ARCHITECTURAL ROLE
------------------
This module belongs to the shared UI component layer.

It is intended to be reused by multiple page layouts so that all
application screens maintain a consistent top banner and identity.

RESPONSIBILITIES
----------------
1. Inject reusable CSS styles for the platform header
2. Render a sticky header container
3. Display left and right logos
4. Keep the application title centered
5. Maintain responsive layout behavior across screen sizes

EXECUTION FLOW
--------------
Typical workflow:

1. A page layout calls `render_app_header(...)`
2. Shared CSS is injected into the document head
3. NiceGUI header container is created
4. Internal grid layout is rendered:
   left logo | centered title | right logo
5. Header remains sticky at the top of the viewport

TYPICAL CALLER
--------------
- Main application page modules
- Shared page layout wrappers
- Top-level UI initialization code

IMPORTANT NOTES
---------------
- Header uses CSS grid for true center alignment
- Header remains sticky during scrolling
- Logos scale proportionally using `object-fit: contain`
- Shared CSS injection avoids duplication across pages
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# NiceGUI import
# ---------------------------------------------------------------------

from nicegui import ui

# ---------------------------------------------------------------------
# Public UI component: application header
# ---------------------------------------------------------------------
# This function renders the consistent top header used across pages.
#
# Parameters:
# - title: application title displayed in center
# - left_logo_src: path/URL of left logo
# - right_logo_src: path/URL of right logo
# - logo_height_px: rendered logo height
# ---------------------------------------------------------------------


def render_app_header(
    *,
    title: str = "Energy Systems Research Framework (v1)",
    left_logo_src: str = "/static/logo_left.png",
    right_logo_src: str = "/static/logo_right.png",
    logo_height_px: int = 44,
) -> None:
    """
    Render the platform header.

    Layout:
        left logo | centered title | right logo

    Design characteristics
    ----------------------
    - Sticky header, always visible at top
    - True center alignment using CSS grid
    - Logos scale proportionally
    - Responsive font/logo sizing for smaller screens
    """

    # -----------------------------------------------------------------
    # Inject shared CSS styles
    # -----------------------------------------------------------------
    # These styles define:
    # - sticky behavior
    # - centered layout width
    # - grid structure
    # - title appearance
    # - logo sizing
    # - responsive adjustments
    # -----------------------------------------------------------------

    ui.add_head_html(
        """
<style>
  .col-sticky-header {
    position: sticky;
    top: 0;
    z-index: 9999;
    background: #ffffff;
    border-bottom: 1px solid rgba(0,0,0,0.08);
  }

  /* Keep header content aligned with main page content width */
  .col-header-wrap {
    width: 100%;
    max-width: 80rem;
    margin: 0 auto;
    padding: 0 16px;
  }

  .col-header-grid {
    display: grid;
    grid-template-columns: 1fr auto 1fr;
    align-items: center;
    gap: 12px;
    padding: 10px 0;
  }

  .col-header-logo {
    height: var(--col-logo-h);
    width: auto;
    max-width: 240px;
    object-fit: contain;
    display: block;
  }

  .col-header-title {
    font-weight: 800;
    font-size: 22px;
    line-height: 1.1;
    text-align: center;
    white-space: nowrap;
    color: #111827;
  }

  /* Responsive adjustment for smaller screens */
  @media (max-width: 640px) {
    .col-header-title { font-size: 18px; }
    .col-header-logo { max-width: 160px; }
  }
</style>
""",
        shared=True,
    )

    # -----------------------------------------------------------------
    # Render sticky header container
    # -----------------------------------------------------------------

    with ui.header().classes("col-sticky-header"):
        # Width wrapper keeps header aligned with overall page layout
        with ui.element("div").classes("col-header-wrap"):
            # Grid ensures title remains truly centered even if logos differ in size
            with (
                ui.element("div")
                .classes("col-header-grid")
                .style(f"--col-logo-h: {logo_height_px}px;")
            ):
                # ------------------------------------------------------
                # Left logo
                # ------------------------------------------------------
                with ui.element("div").style(
                    "display:flex; justify-content:flex-start;"
                ):
                    ui.html(
                        f'<img class="col-header-logo" src="{left_logo_src}" alt="left logo">',
                        sanitize=False,
                    )

                # ------------------------------------------------------
                # Center title
                # ------------------------------------------------------
                ui.label(title).classes("col-header-title")

                # ------------------------------------------------------
                # Right logo
                # ------------------------------------------------------
                with ui.element("div").style("display:flex; justify-content:flex-end;"):
                    ui.html(
                        f'<img class="col-header-logo" src="{right_logo_src}" alt="right logo">',
                        sanitize=False,
                    )
