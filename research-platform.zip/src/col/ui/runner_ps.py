"""
PowerShell Runner Compatibility Shim
------------------------------------

Purpose
-------
Provides backward compatibility for legacy UI modules that previously
imported the PowerShell execution utility from the UI layer.

Historical Context
------------------
Earlier versions of the platform exposed the PowerShell runner through:

    col.ui.runner_ps

During platform refactoring, the canonical implementation was moved to
the platform utilities layer:

    col.platform.utils.powershell

This file remains as a thin compatibility wrapper so existing imports
continue to function without modification.

Design
------
Instead of re-implementing any logic, this module simply re-exports
the current implementation from the platform utilities package.

Benefits
--------
• Prevents breaking older UI code
• Maintains a stable import path for legacy modules
• Centralizes the real implementation in the platform utilities layer
"""

from __future__ import annotations

## ------------------------------------------------------------------
## Canonical PowerShell Execution Utility
## ------------------------------------------------------------------
## The actual implementation of run_powershell now lives inside the
## platform utilities module. This import exposes it to legacy code
## that still imports from the UI package.
## ------------------------------------------------------------------

from col.platform.utils.powershell import run_powershell

## ------------------------------------------------------------------
## Public API
## ------------------------------------------------------------------
## Explicitly declare the symbol exported by this module. This keeps
## the module interface clean and avoids exposing unintended imports.
## ------------------------------------------------------------------

__all__ = ["run_powershell"]
