"""
DER Dispatch Plot Utilities
---------------------------

Purpose
-------
Provides helper utilities to load DER optimization export files and
generate Plotly visualizations used in the UI.

Responsibilities
---------------
• Resolve exported result file paths
• Load time-series CSV outputs produced by DER optimization
• Extract available date ranges for plotting
• Slice time windows for visualization
• Build Plotly figures for:

      - DER dispatch (load, generators, battery)
      - Battery power and state-of-charge

Design
------
These utilities are used by the DER optimization UI tab to visualize
simulation results produced by the optimization core.

All plotting functions operate on exported CSV files rather than
direct PyPSA objects to keep the UI layer decoupled from the solver.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd


## ------------------------------------------------------------------
## Export Paths Container
## ------------------------------------------------------------------
## Represents the set of CSV files produced by the DER optimization
## export process. Each field corresponds to a specific output file.
## ------------------------------------------------------------------


@dataclass
class DerExportPaths:
    out_dir: Path
    load_csv: Path | None
    gen_csv: Path | None
    storage_csv: Path | None
    soc_csv: Path | None


## ------------------------------------------------------------------
## CSV Time-Series Loader
## ------------------------------------------------------------------
## Reads a pandas-exported CSV file and reconstructs the time index.
##
## Assumption:
## The first column contains the datetime index written by
## pandas DataFrame.to_csv().
## ------------------------------------------------------------------


def _read_timeseries_csv(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)

    # Assume first column represents datetime index
    idx_col = df.columns[0]

    df[idx_col] = pd.to_datetime(df[idx_col])
    df = df.set_index(idx_col)

    df.index = pd.DatetimeIndex(df.index)

    return df


## ------------------------------------------------------------------
## Resolve Export File Paths
## ------------------------------------------------------------------
## Converts a raw export_info dictionary returned by the DER
## optimization core into a structured DerExportPaths object.
##
## This keeps downstream plotting code clean and typed.
## ------------------------------------------------------------------


def get_export_paths(export_info: dict[str, Any]) -> DerExportPaths:
    out_dir = Path(export_info["out_dir"])

    load_csv = Path(export_info["load_csv"]) if export_info.get("load_csv") else None

    gen_csv = (
        Path(export_info["dispatch_generators_csv"])
        if export_info.get("dispatch_generators_csv")
        else None
    )

    storage_csv = (
        Path(export_info["dispatch_storage_csv"])
        if export_info.get("dispatch_storage_csv")
        else None
    )

    soc_csv = Path(export_info["soc_csv"]) if export_info.get("soc_csv") else None

    return DerExportPaths(
        out_dir=out_dir,
        load_csv=load_csv,
        gen_csv=gen_csv,
        storage_csv=storage_csv,
        soc_csv=soc_csv,
    )


## ------------------------------------------------------------------
## Determine Available Date Range
## ------------------------------------------------------------------
## Inspects available CSV files and returns the earliest and latest
## timestamps available in the exported data.
##
## Load data is treated as the preferred reference series.
## ------------------------------------------------------------------


def available_date_range(
    paths: DerExportPaths,
) -> tuple[pd.Timestamp, pd.Timestamp] | None:
    # Prefer load as authoritative index
    for p in [paths.load_csv, paths.gen_csv, paths.soc_csv, paths.storage_csv]:
        if p and p.exists():
            df = _read_timeseries_csv(p)

            if len(df.index) > 0:
                return pd.Timestamp(df.index.min()), pd.Timestamp(df.index.max())

    return None


## ------------------------------------------------------------------
## Slice Time Window
## ------------------------------------------------------------------
## Extracts a time window from a time-series DataFrame.
##
## Parameters
## ----------
## start : starting timestamp
## days  : number of days to include
## ------------------------------------------------------------------


def slice_window(df: pd.DataFrame, start: pd.Timestamp, days: int) -> pd.DataFrame:
    days = int(max(1, days))

    end = start + pd.Timedelta(days=days)

    return df.loc[(df.index >= start) & (df.index < end)]


## ------------------------------------------------------------------
## Plotly Figure: DER Dispatch
## ------------------------------------------------------------------
## Creates a multi-series dispatch plot showing:
##
##   • Load demand
##   • Grid import
##   • PV generation
##   • Diesel generation
##   • Load shedding
##   • Battery charge/discharge
##   • Battery state-of-charge
##
## The battery SoC is plotted on a secondary axis.
## ------------------------------------------------------------------


def build_plotly_dispatch(paths: DerExportPaths, *, start: pd.Timestamp, days: int):
    import plotly.graph_objects as go

    # --------------------------------------------------------------
    # Load series
    # --------------------------------------------------------------

    load = None

    if paths.load_csv and paths.load_csv.exists():
        load_df = _read_timeseries_csv(paths.load_csv)

        load_df = slice_window(load_df, start, days)

        if "load" in load_df.columns:
            load = load_df["load"]

    # --------------------------------------------------------------
    # Generator dispatch
    # --------------------------------------------------------------

    gen_df = (
        _read_timeseries_csv(paths.gen_csv)
        if paths.gen_csv and paths.gen_csv.exists()
        else pd.DataFrame()
    )

    gen_df = slice_window(gen_df, start, days) if len(gen_df) else gen_df

    # --------------------------------------------------------------
    # Battery power dispatch
    # --------------------------------------------------------------

    storage_df = (
        _read_timeseries_csv(paths.storage_csv)
        if paths.storage_csv and paths.storage_csv.exists()
        else pd.DataFrame()
    )

    storage_df = (
        slice_window(storage_df, start, days) if len(storage_df) else storage_df
    )

    # --------------------------------------------------------------
    # Battery state-of-charge
    # --------------------------------------------------------------

    soc_df = (
        _read_timeseries_csv(paths.soc_csv)
        if paths.soc_csv and paths.soc_csv.exists()
        else pd.DataFrame()
    )

    soc_df = slice_window(soc_df, start, days) if len(soc_df) else soc_df

    fig = go.Figure()

    # --------------------------------------------------------------
    # Plot Load
    # --------------------------------------------------------------

    if load is not None and len(load):
        fig.add_trace(
            go.Scatter(
                x=load.index,
                y=load.values,
                name="load (MW)",
                mode="lines",
            )
        )

    # --------------------------------------------------------------
    # Plot Generators
    # --------------------------------------------------------------

    for name in ["grid_import", "pv", "diesel", "load_shed"]:
        if name in gen_df.columns:
            fig.add_trace(
                go.Scatter(
                    x=gen_df.index,
                    y=gen_df[name].values,
                    name=f"{name} (MW)",
                    mode="lines",
                )
            )

    # --------------------------------------------------------------
    # Battery charge/discharge
    # --------------------------------------------------------------

    if "battery" in storage_df.columns:
        p = storage_df["battery"]

        batt_dis = p.clip(lower=0.0)

        batt_ch = (-p).clip(lower=0.0)

        fig.add_trace(
            go.Scatter(
                x=storage_df.index,
                y=batt_dis.values,
                name="battery_discharge (MW)",
                mode="lines",
            )
        )

        fig.add_trace(
            go.Scatter(
                x=storage_df.index,
                y=batt_ch.values,
                name="battery_charge (MW)",
                mode="lines",
            )
        )

    # --------------------------------------------------------------
    # Battery State-of-Charge (secondary axis)
    # --------------------------------------------------------------

    if "battery" in soc_df.columns:
        fig.add_trace(
            go.Scatter(
                x=soc_df.index,
                y=soc_df["battery"].values,
                name="battery SoC (MWh)",
                mode="lines",
                yaxis="y2",
                line=dict(dash="dash"),
            )
        )

    fig.update_layout(
        title=f"DER dispatch (start={start.date()}, days={days})",
        xaxis_title="Time",
        yaxis=dict(
            title="Power (MW)",
            autorange=True,
        ),
        yaxis2=dict(
            title="Energy (MWh)",
            overlaying="y",
            side="right",
            autorange=True,
        ),
        margin=dict(l=60, r=60, t=80, b=60),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0.0,
            bgcolor="rgba(255,255,255,0.6)",
        ),
        hovermode="x unified",
    )

    return fig


## ------------------------------------------------------------------
## Plotly Figure: Battery Operation
## ------------------------------------------------------------------
## Generates a dedicated battery plot showing:
##
##   • Battery power (charge/discharge)
##   • Battery state-of-charge
## ------------------------------------------------------------------


def build_plotly_battery(paths: DerExportPaths, *, start: pd.Timestamp, days: int):
    import plotly.graph_objects as go

    storage_df = (
        _read_timeseries_csv(paths.storage_csv)
        if paths.storage_csv and paths.storage_csv.exists()
        else pd.DataFrame()
    )

    storage_df = (
        slice_window(storage_df, start, days) if len(storage_df) else storage_df
    )

    soc_df = (
        _read_timeseries_csv(paths.soc_csv)
        if paths.soc_csv and paths.soc_csv.exists()
        else pd.DataFrame()
    )

    soc_df = slice_window(soc_df, start, days) if len(soc_df) else soc_df

    fig = go.Figure()

    if "battery" in storage_df.columns:
        p = storage_df["battery"]

        fig.add_trace(
            go.Scatter(
                x=storage_df.index,
                y=p.values,
                name="battery p (MW) (+discharge / -charge)",
                mode="lines",
            )
        )

    if "battery" in soc_df.columns:
        fig.add_trace(
            go.Scatter(
                x=soc_df.index,
                y=soc_df["battery"].values,
                name="battery SoC (MWh)",
                mode="lines",
            )
        )

    fig.update_layout(
        title=f"Battery (start={start.date()}, days={days})",
        xaxis_title="Time",
        yaxis=dict(autorange=True),
        margin=dict(l=60, r=60, t=80, b=60),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="left",
            x=0.0,
        ),
        hovermode="x unified",
    )

    return fig
