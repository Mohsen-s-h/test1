# src/col/ui/pages/tabs/site_design.py

"""
Site Design Panel Module
------------------------

Purpose
-------
This module renders the Site Design panel within the Energy Systems Research Framework UI.

Responsibilities
----------------
- Provide session management controls for the site design workflow
- Allow users to load previous design sessions
- Allow users to start a new site design session
- Render the interactive map UI (delegated to site_design_tab)

Important Notes
---------------
The map interface and drawing logic are implemented separately in:

    col.ui.pages.site_design_tab.site_design_tab

This module focuses only on session selection and panel layout.
"""

from nicegui import ui
from nicegui import app
from pathlib import Path
import shutil


def render_site_design_panel(list_site_sessions, sanitize_session_id) -> None:
    active = app.storage.tab.get("active_project")
    workspace = None
    if isinstance(active, dict):
        workspace = active.get("workspace_path")
    print("SITE DESIGN WORKSPACE:", workspace)
    # ensure site_design folder exists
    if workspace:
        Path(workspace, "site_design").mkdir(exist_ok=True)
    if not workspace:
        ui.label(
            "Please create or load a project in the Project Setup tab first."
        ).classes("text-red-500 text-sm")

    if isinstance(active, dict) and active.get("workspace_path"):
        ui.label(f"Workspace: {active.get('workspace_path')}").classes(
            "text-xs text-slate-600 break-all mb-1"
        )
    else:
        ui.label("Workspace: (none — create/load a project in Project setup)").classes(
            "text-xs text-slate-500 break-all mb-1"
        )

    # ------------------------------------------------------------------
    # Session Controls
    # ------------------------------------------------------------------

    with ui.row().classes("items-center gap-3 w-full"):
        ui.label("Session:").classes("text-sm text-gray-700")
        print("BEFORE list_site_sessions")

        sessions = {}
        if workspace:
            try:
                sessions = list_site_sessions()
                print("SITE DESIGN SESSIONS:", sessions)
            except Exception as e:
                print("SESSION LIST ERROR:", e)

        print("AFTER list_site_sessions")
        session_select = (
            ui.select(
                options=sessions,
                label="Load saved session",
                value=None,
            )
            .props("outlined dense")
            .classes("w-96")
        )

        # if sessions:
        #     session_select.value = list(sessions)[0]

        ui.button(
            "Refresh list",
            color="secondary",
            on_click=lambda: session_select.set_options(list_site_sessions()),
        )

        ui.button(
            "New Session",
            color="primary",
            on_click=lambda: ui.run_javascript(
                """

        async function createNewSession(){

            if(!window.COL_create_session){
                console.error("COL_create_session not available")
                return
            }

            const sid = await window.COL_create_session()

            if(!sid){
                alert("Failed to create session")
                return
            }

            window.COL_ACTIVE_SESSION = sid

            if(window.COL_DRAWN) window.COL_DRAWN.clearLayers()
            if(window.COL_SEARCH_LAYER) window.COL_SEARCH_LAYER.clearLayers()

            if(window.COL_load_session){
                window.COL_load_session(sid)
            }

        }

        createNewSession()

        """
            ),
        )

        # --------------------------------------------------------------
        # Delete Session Button
        # --------------------------------------------------------------

        def delete_selected_session():
            sid = sanitize_session_id(str(session_select.value or ""))

            if not sid:
                ui.notify("No session selected", color="red")
                return

            session_path = Path(workspace) / "site_design" / "sessions" / sid

            if not session_path.exists():
                ui.notify("Session folder not found", color="red")
                return

            # Confirmation dialog
            with ui.dialog() as dialog, ui.card():
                ui.label(f"Delete session: {sid}?").classes("text-lg")
                ui.label("This action cannot be undone.").classes("text-red-600")

                with ui.row():
                    ui.button("Cancel", on_click=dialog.close)

                    def confirm_delete():
                        try:
                            shutil.rmtree(session_path)

                            ui.notify(f"Session deleted: {sid}", color="orange")

                            # refresh dropdown
                            session_select.set_options(list_site_sessions())

                            session_select.value = None

                        except Exception as e:
                            ui.notify(f"Delete failed: {e}", color="red")

                        dialog.close()

                    ui.button("Delete", color="red", on_click=confirm_delete)

            dialog.open()

        ui.button(
            "Delete Session",
            color="red",
            on_click=delete_selected_session,
        )

    # if (window.COL_load_session) window.COL_load_session(''); this commented from above before '''''
    # localStorage.removeItem('col_site_design_session_id'); temporry remove from up before if(window.xxx)
    # ------------------------------------------------------------------
    # Load Session
    # ------------------------------------------------------------------

    def _load_selected_session():
        sid = sanitize_session_id(str(session_select.value or ""))
        if not sid:
            return

        ui.run_javascript(
            f"if (window.COL_load_session) window.COL_load_session('{sid}')"
        )

    session_select.on("update:model-value", lambda _: _load_selected_session())

    # ------------------------------------------------------------------
    # Map UI
    # ------------------------------------------------------------------

    with ui.column().classes("w-full gap-2  items-stretch"):
        with ui.row().classes("w-full items-end gap-2  items-stretch"):
            search_input = ui.input(
                placeholder="Search address / place",
            ).classes("w-full")

            ui.button(
                "SEARCH",
                color="primary",
                on_click=lambda: ui.run_javascript(
                    f"COL_search('{search_input.value}')"
                ),
            )

        # ------------------------------------------------------------------
        # Map Container
        # ------------------------------------------------------------------

        ui.html(
            """
        <div id="col_map"
            style="
                height:650px;
                width:100%;
                min-width:100%;
                display:block;
                border:1px solid #e5e7eb;
                border-radius:12px;
            ">
        </div>
        """,
            sanitize=False,
        )
        ui.label().props("id=col_map_status").classes("text-caption text-grey")

        # ------------------------------------------------------------------
        # Map Initializer
        # ------------------------------------------------------------------

        ui.run_javascript(
            """
        window.COL_SITE_DESIGN_ENABLED = true;

        (function loadSiteDesignLinkingScript() {
            const old = document.getElementById('col_site_linking_script');
            if (old) {
                old.remove();
            }

            const s = document.createElement('script');
            s.id = 'col_site_linking_script';
            s.src = '/static/site_map_linking.js?v=' + Date.now();
            s.onload = () => console.log('[COL] site_map_linking.js loaded');
            s.onerror = (e) => console.error('[COL] site_map_linking.js failed to load', e);
            document.head.appendChild(s);
        })();
        """
        )

        ui.run_javascript(
            """

function initCOLSiteMap(){

    const el = document.getElementById("col_map")

    if(!el) return

    if(el.__MAP_INIT__) return

    if(window.COL_init_map){

        console.log("Initializing Leaflet map")

        window.COL_init_map("col_map",{
            statusId:"col_map_status",
            enableDraw: true
        })

        el.__MAP_INIT__ = true

        setTimeout(()=>{
            if(window.COL_MAP){
                window.COL_MAP.invalidateSize()
            }
        },300)
    }
}

setTimeout(initCOLSiteMap,500)

document.addEventListener("click",()=>{
    setTimeout(initCOLSiteMap,200)
})

"""
        )
