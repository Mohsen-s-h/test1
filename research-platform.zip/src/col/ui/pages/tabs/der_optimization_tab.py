"""
DER Optimization Tab
--------------------

Purpose
-------
This module renders the outer DER Optimization tab and delegates the PyPSA
panel implementation to the DER optimization PyPSA UI module.

Responsibilities
----------------
1. Show the active project workspace at the tab level
2. Render the high-level DER optimization tab set
3. Delegate PyPSA-specific UI logic to the PyPSA panel module
4. Keep the top-level tab file thin, readable, and easy to maintain

Execution Flow
--------------
home_page.py
    -> der_optimization_tab()
        -> render_der_optimization_pypsa_panel()

Design Note
-----------
The detailed PyPSA UI implementation lives in the DER optimization PyPSA
module so that this tab file remains focused on top-level layout only.
"""

from __future__ import annotations

from nicegui import app, ui

from col.platform.cores.der_optimization.pypsa.pypsa_ui_panel import (
    render_der_optimization_pypsa_panel,
)


def der_optimization_tab() -> None:
    """
    Public tab entry point.

    This function renders the outer DER Optimization tab and its sub-tabs.
    """
    active = app.storage.tab.get("active_project")

    if isinstance(active, dict) and active.get("workspace_path"):
        ui.label(f"Workspace: {active.get('workspace_path')}").classes(
            "text-xs text-slate-600 break-all mb-1"
        )
    else:
        ui.label("Workspace: (none - create/load a project in Project setup)").classes(
            "text-xs text-slate-500 mb-1"
        )

    ui.markdown("## DER Optimization")

    with ui.tabs().classes("w-full") as tabs:
        t_pypsa = ui.tab("PyPSA")
        t_sama = ui.tab("SAMA")
        t_pp = ui.tab("pandapower")
        t_dss = ui.tab("OpenDSS")

    with ui.tab_panels(tabs, value=t_pypsa).classes("w-full max-w-full"):
        with ui.tab_panel(t_pypsa).classes("max-w-full"):
            render_der_optimization_pypsa_panel()

        with ui.tab_panel(t_sama):
            ui.label("SAMA solver integration - coming soon.")

        with ui.tab_panel(t_pp):
            ui.label("pandapower solver integration - coming soon.")

        with ui.tab_panel(t_dss):
            ui.label("OpenDSS solver integration - coming soon.")
