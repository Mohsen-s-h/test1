"""
src/col/ui/pages/tabs/load_forecasting_tab.py

Load forecasting tab for the COL platform.

Purpose
-------
This module renders the top-level Load Forecasting tab and delegates the
residential URBANopt-specific UI implementation to the URBANopt UI panel
module so that the tab layer remains thin, clear, and easier to maintain.

Responsibilities
----------------
1. Show the active project workspace at the tab level
2. Render the high-level load forecasting tab set
3. Delegate residential URBANopt UI rendering to the dedicated panel module
4. Keep the top-level tab file focused on layout only

Execution Flow
--------------
home_page.py
    -> load_forecasting_tab()
        -> render_load_forecasting_urbanopt_panel()
"""

from __future__ import annotations

from nicegui import app, ui

from col.platform.cores.load_forecasting.urbanopt.urbanopt_ui_pannel import (
    render_load_forecasting_urbanopt_panel,
)


def load_forecasting_tab() -> None:
    """
    Render the top-level Load Forecasting tab and its sub-tabs.
    """
    active = app.storage.tab.get("active_project")

    if isinstance(active, dict) and active.get("workspace_path"):
        ui.label(f"Workspace: {active.get('workspace_path')}").classes(
            "text-xs text-slate-600 break-all mb-1"
        )
    else:
        ui.label("Workspace: (none — create/load a project in Project setup)").classes(
            "text-xs text-slate-500 mb-1"
        )

    ui.markdown("## Load Forecasting")

    with ui.tabs().classes("w-full") as tabs:
        t_res = ui.tab("Residential")
        t_ev = ui.tab("EV Charging")
        t_dc = ui.tab("Data Center")
        t_gh = ui.tab("Greenhouse")

    with ui.tab_panels(tabs, value=t_res).classes("w-full"):
        with ui.tab_panel(t_res):
            render_load_forecasting_urbanopt_panel()

        with ui.tab_panel(t_ev):
            ui.label("EV Charging load forecasting — coming soon.")

        with ui.tab_panel(t_dc):
            ui.label("Data Center load forecasting — coming soon.")

        with ui.tab_panel(t_gh):
            ui.label("Greenhouse load forecasting — coming soon.")
