"""
src/col/ui/pages/tabs/land_feasibility_tab.py

Land Feasibility Tab
--------------------

Purpose
-------
This module renders the top-level Land Feasibility tab and delegates the
detailed UI implementation to the land feasibility panel module so that the
tab layer remains thin, clear, and easy to maintain.

Responsibilities
----------------
1. Show the active project workspace path at the tab level.
2. Render the high-level Land Feasibility tab heading.
3. Delegate all panel rendering to ``render_land_feasibility_panel()``.
4. Keep this file focused on layout only — no analysis logic lives here.

Execution Flow
--------------
home_page.py
    -> build_land()
        -> land_feasibility_tab()
            -> render_land_feasibility_panel()
"""

from __future__ import annotations

from nicegui import app, ui

from col.platform.cores.land_feasibility.land_feasibility_ui_panel import (
    render_land_feasibility_panel,
)


def land_feasibility_tab() -> None:
    """
    Public tab entry point.

    This function renders the outer Land Feasibility tab.
    """
    active = app.storage.tab.get("active_project")

    if isinstance(active, dict) and active.get("workspace_path"):
        ui.label(f"Workspace: {active.get('workspace_path')}").classes(
            "text-xs text-slate-600 break-all mb-1"
        )
    else:
        ui.label(
            "Workspace: (none — create/load a project in Project setup)"
        ).classes("text-xs text-slate-500 mb-1")

    ui.markdown("## Land Feasibility Core")

    render_land_feasibility_panel()
