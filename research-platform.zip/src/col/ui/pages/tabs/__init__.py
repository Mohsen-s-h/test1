"""
src/col/ui/pages/tabs/__init__.py

Tab-based UI components for the COL platform.

This package contains modules that define and manage tab-based
layouts within the user interface. Each tab represents a specific
functional view, such as load forecasting or DER optimization,
and organizes UI elements for user interaction.

Typical Usage:
- Define UI tabs and associated layouts
- Structure user interface views for different functionalities
"""
