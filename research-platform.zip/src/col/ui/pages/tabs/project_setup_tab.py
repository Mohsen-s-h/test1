# src/col/ui/pages/tabs/project_setup_tab.py

"""
Energy Systems Research Framework
Project Setup Tab
-----------------

Purpose
-------
This module collects the initial project information and prepares the
workspace used by downstream modules (Site Design, DER sizing, etc.).

Key Responsibilities
--------------------
1. Collect project metadata
2. Provide location search + map visualization
3. Capture high-level engineering context
4. Create / load project workspaces

Important Notes
---------------
• This tab uses the shared map engine implemented in site_map.js
• We DO NOT modify site_map.js
• A guard prevents the map from initializing twice when NiceGUI refreshes
"""

from __future__ import annotations

import json
import re

from datetime import datetime
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

from nicegui import ui, app
from col.config.config_loader import load_app_config


# =============================================================================
# Geocoding utility
# =============================================================================


def _geocode_address(addr: str):
    q = (addr or "").strip()

    if not q:
        return None

    url = f"https://nominatim.openstreetmap.org/search?q={quote(q)}&format=json&limit=1"

    req = Request(url, headers={"User-Agent": "COL-Platform/1.0"})

    try:
        with urlopen(req, timeout=10) as res:
            raw = json.loads(res.read().decode("utf-8"))

        if not raw:
            return None

        hit = raw[0]

        lat = float(hit["lat"])
        lon = float(hit["lon"])
        label = str(hit.get("display_name") or q)

        return lat, lon, label

    except Exception:
        return None


# =============================================================================
# Filesystem safe naming
# =============================================================================


def _safe_name(name: str):
    name = re.sub(r"[^A-Za-z0-9_\- ]+", "", name)
    name = name.strip().replace(" ", "_")

    return name[:60] if name else "project"


# =============================================================================
# Create project workspace
# =============================================================================


def _create_project_workspace(
    client_name,
    project_name,
    project_type,
    address,
    lat,
    lon,
):
    cfg = load_app_config()

    root = Path(cfg.workspace_root) / "projects"
    root.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    project_id = f"{_safe_name(client_name)}_{_safe_name(project_type)}_{timestamp}"

    workspace = root / project_id
    workspace.mkdir(parents=True, exist_ok=True)

    (workspace / "site_design").mkdir(exist_ok=True)
    (workspace / "results").mkdir(exist_ok=True)
    (workspace / "exports").mkdir(exist_ok=True)

    meta = {
        "project_id": project_id,
        "client_name": client_name,
        "project_name": project_name,
        "project_type": project_type,
        "address": address,
        "latitude": lat,
        "longitude": lon,
        "created_at": datetime.now().isoformat(timespec="seconds"),
    }

    with open(workspace / "project.json", "w") as f:
        json.dump(meta, f, indent=2)

    return {**meta, "workspace_path": str(workspace)}


# =============================================================================
# List existing projects
# =============================================================================


def _list_projects():
    cfg = load_app_config()
    root = Path(cfg.workspace_root) / "projects"

    if not root.exists():
        return {}

    opts = {}

    for p in sorted(root.iterdir()):
        pj = p / "project.json"

        if pj.exists():
            meta = json.loads(pj.read_text())

            label = f"{meta['client_name']} / {meta['project_id']}"

            # IMPORTANT:
            # label = what user sees
            # value = actual folder path
            opts[str(p)] = label

    return opts


# =============================================================================
# Load project metadata
# =============================================================================


def _load_project(path: str):
    # Ensure we use the exact path selected from the dropdown
    project_dir = Path(path)

    if not project_dir.exists():
        raise FileNotFoundError(f"Project folder not found: {project_dir}")

    pj = project_dir / "project.json"

    if not pj.exists():
        raise FileNotFoundError(f"project.json missing in {project_dir}")

    meta = json.loads(pj.read_text())

    return {**meta, "workspace_path": str(project_dir)}


# =============================================================================
# Main UI
# =============================================================================


def project_setup_tab():
    _ = load_app_config()

    data = app.storage.tab.get("project_setup", {}) or {}

    def get(k, d=None):
        return data.get(k, d)

    def setv(k, v):
        data[k] = v
        app.storage.tab["project_setup"] = data

    # =============================================================================
    # Engineering context definitions
    # =============================================================================

    PCC_CONNECTION = [
        "≤ 50 kV (Distribution-connected)",
        "> 50 kV (Transmission-connected – IESO)",
        "No connection / off-grid",
    ]

    VOLTAGE_CLASSES = [
        "600 V",
        "4.16 kV",
        "13.8 kV",
        "27.6 kV",
        "44 kV",
        "69 kV",
        "115 kV",
        "Other / Unknown",
    ]

    DER_TECH = [
        "Solar PV",
        "BESS",
        "Diesel Generator",
        "Wind",
        "Fuel Cell",
        "Thermal Storage",
        "Heat Pumps",
        "EV Chargers (as Load)",
    ]

    EXPORT_BEHAVIOR = [
        "Non-exporting",
        "Export-limited",
        "Exporting",
    ]

    LOAD_TYPES = [
        "Residential",
        "EV charging",
        "DATA CENTER",
        "GREEN HOUSE",
        "CONSTRUCTION SITE",
        "Mixed-use",
    ]

    HEATING_TYPE = [
        "Fully electric",
        "Natural gas",
        "Hybrid (gas + electric)",
        "District heating",
        "Unknown",
    ]

    COOLING_TYPE = [
        "Electric AC / Chiller",
        "No cooling",
        "Unknown",
    ]

    CRITICAL_LOAD = [
        "0%",
        "20%",
        "50%",
        "80%",
        "100%",
    ]

    # =============================================================================
    # UI Helpers
    # =============================================================================

    def card():
        return ui.card().classes("w-full border shadow-sm").style("overflow:visible;")

    def title(text):
        ui.label(text).classes("text-base font-semibold")

    with ui.column().classes("w-full"):
        # =========================================================================
        # Location
        # =========================================================================

        with card():
            title("Project Location")

            with ui.row():
                address = ui.input(
                    "Project address", placeholder="Search address"
                ).classes("flex-1")

                def do_search():
                    hit = _geocode_address(address.value)

                    if not hit:
                        ui.notify("Address not found")
                        return

                    lat, lon, label = hit

                    setv("address", label)
                    setv("lat", lat)
                    setv("lon", lon)

                    ui.run_javascript(
                        f"""
if(window.COL_set_project_location){{
COL_set_project_location({lat},{lon},{json.dumps(label)});
}}
"""
                    )

                ui.button("Search", on_click=do_search)

            ui.html(
                """
            <div id="col_project_map"
            style="
            height:420px;
            width:100%;
            border:1px solid #ddd;
            border-radius:10px;
            position:relative;
            ">
            </div>
            """,
                sanitize=False,
            ).classes("w-full")

            ui.label().props("id=col_project_map_status")
            # Disable Site Design UI for this tab

            ui.run_javascript("""
            window.COL_SITE_DESIGN_ENABLED = false;
            window.COL_PROJECT_SETUP_ENABLED = true;
            """)

            # ---------------------------------------------------------------------
            # Safe map initialization (guard prevents double init)
            # ---------------------------------------------------------------------

            ui.run_javascript(
                """

            function initProjectSetupMap(){

                const el = document.getElementById("col_project_map")

                if(!el) return

                if(el.__MAP_INIT__) return

                if(window.COL_init_map){

                    console.log("Initializing Project Setup Map")

                    window.COL_init_map("col_project_map",{
                        statusId:"col_project_map_status",
                        enableDraw:false
                    })

                    el.__MAP_INIT__ = true

                    setTimeout(()=>{
                        if(window.COL_MAP){
                            window.COL_MAP.invalidateSize()
                        }
                    },300)
                }
            }

            setTimeout(initProjectSetupMap,500)

            document.addEventListener("click",()=>{
                setTimeout(initProjectSetupMap,200)
            })

            """
            )

        # =========================================================================
        # Interconnection
        # =========================================================================

        with card():
            title("Interconnection")

            with ui.grid(columns=2).classes("w-full gap-4"):
                ui.select(PCC_CONNECTION, label="Connection type")

                ui.select(VOLTAGE_CLASSES, label="Voltage class")

        # =========================================================================
        # DER
        # =========================================================================

        with card():
            title("DER technologies")

            with ui.grid(columns=2).classes("w-full gap-4"):
                ui.select(DER_TECH, label="Technologies", multiple=True)

                ui.select(EXPORT_BEHAVIOR, label="Export behaviour")

        # =========================================================================
        # Load Context
        # =========================================================================

        with card():
            title("Load context")

            with ui.grid(columns=2).classes("w-full gap-4"):
                ui.select(LOAD_TYPES, label="Load type")

                ui.select(HEATING_TYPE, label="Heating type")

                ui.select(COOLING_TYPE, label="Cooling type")

                ui.select(CRITICAL_LOAD, label="Critical load share")

        # =========================================================================
        # Workspace
        # =========================================================================

        with card():
            title("Workspace")

            with ui.row():
                ui.input("Client name").classes("w-1/3").on_value_change(
                    lambda e: setv("client", e.value)
                )

                ui.input("Project name").classes("w-1/3").on_value_change(
                    lambda e: setv("project", e.value)
                )

                ui.input("Project type").classes("w-1/3").on_value_change(
                    lambda e: setv("type", e.value)
                )

            with ui.row():

                def create_project():
                    meta = _create_project_workspace(
                        get("client", ""),
                        get("project", ""),
                        get("type", ""),
                        get("address", ""),
                        get("lat"),
                        get("lon"),
                    )

                    app.storage.tab["active_project"] = meta
                    app.storage.general["active_project"] = meta

                    ui.notify(f"Project created: {meta['project_id']}")

                ui.button("Create Project", color="primary", on_click=create_project)

                project_select = ui.select(
                    options=_list_projects(), label="Load project"
                ).classes("w-96")
                loaded_project_label = ui.label("Loaded project: None").classes(
                    "text-sm text-gray-600"
                )

                def load_project():
                    if not project_select.value:
                        ui.notify("Please select a project")
                        return

                    project_path = project_select.value
                    print("SELECTED PROJECT PATH:", project_path)

                    # LOAD META
                    meta = _load_project(project_path)
                    app.storage.tab["active_project"] = meta
                    app.storage.general["active_project"] = meta
                    loaded_project_label.set_text(
                        f"Loaded project: {meta.get('project_id')}"
                    )

                    print("PROJECT META:", meta)

                    lat = meta.get("latitude")
                    lon = meta.get("longitude")
                    addr = meta.get("address", "")

                    print("SENDING LOCATION:", lat, lon)

                    if lat and lon:
                        ui.timer(
                            0.5,
                            lambda: ui.run_javascript(
                                f'''
                                COL_set_project_location({lat}, {lon}, "{addr}");

                                if(window.COL_MAP){{
                                    window.COL_MAP.invalidateSize();
                                }}

                                if(window.COL_reload_project){{
                                    window.COL_reload_project();
                                }}
                                '''
                            ),
                            once=True,
                        )

                    ui.notify(f"Loaded {meta.get('project_id')}")

                ui.button("Load", on_click=load_project)

                def clear_project():
                    app.storage.tab["active_project"] = None
                    app.storage.general["active_project"] = None

                    loaded_project_label.set_text("Loaded project: None")

                    ui.run_javascript("""
                    if(window.COL_MAP){
                        window.COL_MAP.eachLayer(function(layer){
                            if(layer instanceof L.Marker){
                                window.COL_MAP.removeLayer(layer)
                            }
                        })
                    }
                    """)

                    ui.notify("Project cleared")

                ui.button("Clear Loaded Project", color="red", on_click=clear_project)
