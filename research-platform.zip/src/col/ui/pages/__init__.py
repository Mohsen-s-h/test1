"""
src/col/ui/pages/__init__.py

User interface page modules for the COL platform.

This package organizes the different pages and views of the user
interface, including tab-based layouts and other UI structures.
It provides the structural foundation for presenting platform
functionalities to the user.

Typical Usage:
- Define and organize UI pages and views
- Structure user-facing components within the application
"""
