"""
Energy Systems Research Framework Main UI Page.
---------------------------

Purpose
-------
Defines the main entry point of the Energy Systems Research Framework. web interface.

Responsibilities
---------------
• Register the root application page ("/")
• Render the platform header
• Create the main project workflow tabs
• Route each tab to its corresponding module

UI Structure
-----------
The interface contains the following workflow tabs:

  - Project setup
  - Site design
  - Land feasibility core
  - Load forecasting core
  - DER optimization core
  - Operational evaluation core
  - Network & feeder design core
  - Financial assessment core

Each tab loads its corresponding UI module when selected.
"""

from __future__ import annotations

from nicegui import ui, app


def register_home_page(list_site_sessions, sanitize_session_id) -> None:
    @ui.page("/")
    async def main() -> None:
        await ui.context.client.connected()
        app.storage.tab

        from col.ui.components.header import render_app_header

        render_app_header(
            title="Energy Systems Research Framework (v1)",
            left_logo_src="/static/logo_left.png",
            right_logo_src="/static/logo_right.png",
            logo_height_px=76,
        )

        with ui.card().classes("w-full max-w-5xl mx-auto"):
            ui.markdown("## Inputs")

            with ui.tabs().classes("w-full") as tabs:
                t_setup = ui.tab("Project setup")
                t_land = ui.tab("Land feasibility core")
                t_site = ui.tab("Site design")
                t_load = ui.tab("Load forecasting core")
                t_der = ui.tab("DER optimization core")
                t_oper = ui.tab("Operational evaluation core")
                t_net = ui.tab("Network & feeder design core")
                t_fin = ui.tab("Financial assessment core")

            built = {
                "setup": False,
                "land": False,
                "site": False,
                "load": False,
                "der": False,
                "oper": False,
                "net": False,
                "fin": False,
            }

            with ui.tab_panels(tabs, value=t_setup).classes("w-full"):
                with ui.tab_panel(t_setup):
                    c_setup = ui.column().classes("w-full")

                with ui.tab_panel(t_land):
                    c_land = ui.column().classes("w-full")

                with ui.tab_panel(t_site):
                    c_site = ui.column().classes("w-full")

                with ui.tab_panel(t_load):
                    c_load = ui.column().classes("w-full")

                with ui.tab_panel(t_der):
                    c_der = ui.column().classes("w-full")

                with ui.tab_panel(t_oper):
                    c_oper = ui.column().classes("w-full")

                with ui.tab_panel(t_net):
                    c_net = ui.column().classes("w-full")

                with ui.tab_panel(t_fin):
                    c_fin = ui.column().classes("w-full")

            def build_setup() -> None:
                if built["setup"]:
                    return
                built["setup"] = True
                with c_setup:
                    from col.ui.pages.tabs.project_setup_tab import project_setup_tab

                    project_setup_tab()

            def build_land() -> None:
                if built["land"]:
                    return
                built["land"] = True
                with c_land:
                    from col.ui.pages.tabs.land_feasibility_tab import land_feasibility_tab
                    land_feasibility_tab()
            def build_site() -> None:
                if built["site"]:
                    return
                built["site"] = True
                with c_site:
                    from col.ui.pages.tabs.site_design import render_site_design_panel

                    render_site_design_panel(list_site_sessions, sanitize_session_id)

            def build_load() -> None:
                if built["load"]:
                    return
                built["load"] = True
                with c_load:
                    from col.ui.pages.tabs.load_forecasting_tab import (
                        load_forecasting_tab,
                    )

                    load_forecasting_tab()

            def build_der() -> None:
                if built["der"]:
                    return
                built["der"] = True
                with c_der:
                    from col.ui.pages.tabs.der_optimization_tab import (
                        der_optimization_tab,
                    )

                    der_optimization_tab()

            def build_oper() -> None:
                if built["oper"]:
                    return
                built["oper"] = True
                with c_oper:
                    ui.label("TODO oper")

            def build_net() -> None:
                if built["net"]:
                    return
                built["net"] = True
                with c_net:
                    ui.label("TODO net")

            def build_fin() -> None:
                if built["fin"]:
                    return
                built["fin"] = True
                with c_fin:
                    ui.label("TODO fin")

            t_setup.on("click", lambda e: build_setup())
            t_land.on("click", lambda e: build_land())
            t_site.on("click", lambda e: build_site())
            t_load.on("click", lambda e: build_load())
            t_der.on("click", lambda e: build_der())
            t_oper.on("click", lambda e: build_oper())
            t_net.on("click", lambda e: build_net())
            t_fin.on("click", lambda e: build_fin())

            build_setup()
