"""
Energy Systems Research Framework Desktop Launcher
--------------------------------------------------

Purpose
-------
Launch the Energy Systems Research Framework web application in a native desktop window.

This module wraps the NiceGUI web application and exposes it as a
desktop application using pywebview.

Responsibilities
----------------
• Start the NiceGUI backend server (app_main.py) as a subprocess
• Wait until the local HTTP server becomes reachable
• Open the UI inside a native desktop window using pywebview
• Ensure the backend process terminates cleanly when the window closes

Architecture
------------
Desktop Launcher
        │
        ▼
NiceGUI backend (col.ui.app_main)
        │
        ▼
Local HTTP server (127.0.0.1:8080)
        │
        ▼
pywebview native window

Important
---------
This file does NOT implement any UI logic.
It only manages application startup and shutdown.
"""

from __future__ import annotations

## ------------------------------------------------------------------
## Imports
## ------------------------------------------------------------------

import subprocess
import sys
import time
import urllib.request

import webview


## ------------------------------------------------------------------
## Application URL
## ------------------------------------------------------------------
## NiceGUI serves the application locally. The desktop window loads
## this URL once the server becomes available.
## ------------------------------------------------------------------

URL = "http://127.0.0.1:8080/"


## ------------------------------------------------------------------
## Server Availability Check
## ------------------------------------------------------------------
## Poll the backend URL until the NiceGUI server becomes reachable.
##
## Why this is required:
## • NiceGUI startup takes a few seconds
## • pywebview must NOT open before the HTTP server exists
## • Prevents blank window or connection errors
## ------------------------------------------------------------------


def wait_until_up(url: str, timeout_s: float = 60.0) -> None:
    """
    Poll the given URL until it responds or timeout expires.

    Parameters
    ----------
    url : str
        URL of the backend server.

    timeout_s : float
        Maximum time to wait before raising an error.

    Raises
    ------
    RuntimeError
        If the server does not become reachable within the timeout.
    """

    start = time.time()
    last_err: Exception | None = None

    while time.time() - start < timeout_s:
        try:
            with urllib.request.urlopen(url, timeout=1) as r:
                # Accept any HTTP response that proves server is alive
                if 200 <= r.status < 500:
                    return

        except Exception as e:
            last_err = e
            time.sleep(0.2)

    raise RuntimeError(
        f"Server not reachable at {url} within {timeout_s}s. Last error: {last_err!r}"
    )


## ------------------------------------------------------------------
## Desktop Launcher Main Entry
## ------------------------------------------------------------------
## Responsible for starting the backend process and opening the
## desktop application window.
##
## Execution Flow
## --------------
## 1. Start NiceGUI backend as subprocess
## 2. Wait until HTTP server becomes reachable
## 3. Launch pywebview window
## 4. When window closes, terminate backend process
## ------------------------------------------------------------------


def main() -> None:
    """
    Launch backend + desktop window.

    Flow:
    -----
    1. Start NiceGUI backend as a subprocess
    2. Wait until HTTP server is reachable
    3. Open pywebview window (Edge/Chromium)
    4. On exit, terminate backend process
    """

    ## --------------------------------------------------------------
    ## Start NiceGUI backend
    ## --------------------------------------------------------------
    ## The backend is launched using Python module execution so the
    ## app_main.py entrypoint runs exactly as in normal web mode.
    ## --------------------------------------------------------------

    proc = subprocess.Popen(
        [sys.executable, "-m", "col.ui.app_main"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        # Windows-specific: enables clean process termination
        creationflags=(
            subprocess.CREATE_NEW_PROCESS_GROUP if sys.platform.startswith("win") else 0
        ),
    )

    try:
        ## ----------------------------------------------------------
        ## Wait for backend server
        ## ----------------------------------------------------------
        ## Ensures that the NiceGUI server is fully initialized
        ## before opening the desktop window.
        ## ----------------------------------------------------------

        wait_until_up(URL, timeout_s=60.0)

        ## ----------------------------------------------------------
        ## Create native desktop window
        ## ----------------------------------------------------------
        ## The window simply loads the locally served web UI.
        ## ----------------------------------------------------------

        webview.create_window(
            title="Energy Systems Research Framework",
            url=URL,
            width=1200,
            height=800,
        )

        ## ----------------------------------------------------------
        ## Start pywebview GUI engine
        ## ----------------------------------------------------------
        ## Edge/Chromium engine provides best compatibility for:
        ## • Leaflet maps
        ## • JavaScript-heavy UI
        ## • Canvas rendering
        ## ----------------------------------------------------------

        webview.start(gui="edgechromium")

    finally:
        ## ----------------------------------------------------------
        ## Backend shutdown
        ## ----------------------------------------------------------
        ## Ensures the NiceGUI process is terminated when the
        ## desktop window closes.
        ## ----------------------------------------------------------

        if proc.poll() is None:
            proc.terminate()

            try:
                proc.wait(timeout=5)

            except Exception:
                proc.kill()


## ------------------------------------------------------------------
## Script Entrypoint
## ------------------------------------------------------------------
## Allows the launcher to be executed directly using:
##
##     python desktop.py
##
## or packaged into a standalone desktop application.
## ------------------------------------------------------------------

if __name__ == "__main__":
    main()
