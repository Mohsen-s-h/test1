"""
MODULE: Energy Systems Research Framework Main Application Entry Point
FILE: app_main.py
LOCATION:
src/col/ui/app_main.py

PURPOSE
-------
This module initializes and launches the Energy Systems Research Framework web application
using NiceGUI (frontend) and FastAPI (backend).

It acts as the central bootstrap layer responsible for:
- registering backend APIs
- configuring static assets
- wiring UI pages
- initializing application-level helpers
- starting the web server

ARCHITECTURAL ROLE
------------------
This file is the top-level integration point of the UI system.

It connects:

    1) Backend APIs
       - Site design geometry persistence
       - Transformer ↔ house linking

    2) UI Layer
       - Home page
       - Tab-based workflows

    3) Static Frontend Assets
       - Leaflet map libraries
       - Drawing tools
       - Custom JavaScript modules

RESPONSIBILITIES
----------------
1. Register FastAPI routers used by the UI
2. Configure static file serving (JS, CSS, images)
3. Inject required frontend libraries (Leaflet, html2canvas)
4. Provide helper utilities for session management
5. Register UI pages
6. Launch NiceGUI application server

EXECUTION FLOW
--------------
1. Import configuration and modules
2. Register API routers
3. Configure static file directory
4. Inject frontend JS/CSS dependencies
5. Register UI pages
6. Start NiceGUI server (if executed as main module)

TYPICAL CALLER
--------------
- Python runtime (entry point)
- Development execution (python app_main.py)

IMPORTANT NOTES
---------------
- Uses NiceGUI's FastAPI wrapper (`app`)
- Static assets are served under `/static`
- Leaflet is used for map visualization
- Session handling is tied to active project context
"""

from __future__ import annotations

# ---------------------------------------------------------------------
# Standard library imports
# ---------------------------------------------------------------------

import re
from datetime import datetime
from pathlib import Path

# ---------------------------------------------------------------------
# Framework imports (FastAPI + NiceGUI)
# ---------------------------------------------------------------------

from nicegui import app, ui  # app = NiceGUI FastAPI wrapper

# ---------------------------------------------------------------------
# Internal API modules
# ---------------------------------------------------------------------

from col.config.config_loader import ensure_demo_project_available, load_app_config
from col.platform.orchestration.project_orchestrator import load_project_by_workspace
from col.ui.api.site_api import router as site_router
from col.ui.api.site_design_links_api import register_site_design_links_api

# ---------------------------------------------------------------------
# UI page registration
# ---------------------------------------------------------------------

from col.ui.pages.home_page import register_home_page

# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

from col.ui.config import SITE_SESSIONS_DIR, STORAGE_SECRET

# ---------------------------------------------------------------------
# Debug output for configuration verification
# ---------------------------------------------------------------------

print("SITE_SESSIONS_DIR =", SITE_SESSIONS_DIR)


# ---------------------------------------------------------------------
# Helper: list available site design sessions
# ---------------------------------------------------------------------
# Retrieves session directories for the currently active project.
# ---------------------------------------------------------------------


def list_site_sessions() -> list[str]:
    try:
        active = app.storage.tab.get("active_project")

        if not active:
            return []

        workspace = Path(active["workspace_path"])

        sessions_dir = workspace / "site_design" / "sessions"

        if not sessions_dir.exists():
            return []

        return sorted(
            [p.name for p in sessions_dir.iterdir() if p.is_dir()],
            reverse=True,
        )

    except Exception as e:
        print("SESSION LIST ERROR:", e)
        return []


# ---------------------------------------------------------------------
# Helper: validate session ID
# ---------------------------------------------------------------------
# Ensures safe and predictable filesystem usage.
# ---------------------------------------------------------------------


def sanitize_session_id(s: str) -> str:
    """
    Validate a session identifier.

    Allowed format:
        YYYYMMDD_HHMMSS

    Prevents invalid paths or malicious input.
    """

    s = (s or "").strip()
    return s if re.fullmatch(r"\d{8}_\d{6}", s) else ""


# ---------------------------------------------------------------------
# Helper: generate new session ID
# ---------------------------------------------------------------------


def _new_session_id() -> str:
    """
    Create a new session identifier.

    Format:
        YYYYMMDD_HHMMSS
    """

    return datetime.now().strftime("%Y%m%d_%H%M%S")


# ---------------------------------------------------------------------
# Helper: resolve session directory path
# ---------------------------------------------------------------------


def _session_dir(session_id: str) -> Path:
    """
    Resolve filesystem path for a given session ID.

    Strategy:
    1. Prefer strictly validated session IDs
    2. Allow limited fallback for legacy IDs
    """

    safe = sanitize_session_id(session_id) or "".join(
        ch for ch in session_id if (ch.isdigit() or ch in "_-")
    )

    return SITE_SESSIONS_DIR / safe


# =============================================================================
# FASTAPI ROUTER REGISTRATION
# =============================================================================
# ---------------------------------------------------------------------
# Bootstrap default active project
# ---------------------------------------------------------------------


def _bootstrap_default_active_project() -> None:
    """
    Ensure a default active project exists for first-run scenarios.

    Strategy:
    1. Load application config
    2. Ensure bundled demo project is copied into workspace
    3. If no active project is selected, load demo project metadata
    4. Populate both NiceGUI storage scopes used by the app
    """
    cfg = load_app_config()
    demo_workspace = ensure_demo_project_available(cfg)

    if demo_workspace is None:
        return

    active_general = app.storage.general.get("active_project")

    if active_general:
        return

    try:
        meta = load_project_by_workspace(str(demo_workspace))
        payload = meta.to_dict()
    except Exception:
        payload = {
            "project_id": demo_workspace.name,
            "workspace_path": str(demo_workspace),
        }

    app.storage.general["active_project"] = payload


# ---------------------------------------------------------------------
# Register site design geometry API
# ---------------------------------------------------------------------
_bootstrap_default_active_project()

app.include_router(site_router)


# ---------------------------------------------------------------------
# Register transformer ↔ house linking API
# ---------------------------------------------------------------------


register_site_design_links_api(app)


# ---------------------------------------------------------------------
# Debug: verify API routes are correctly registered
# ---------------------------------------------------------------------

for r in app.routes:
    p = getattr(r, "path", None)
    m = getattr(r, "methods", None)

    if p and "api/site/sessions" in p and "links" in p:
        print("ROUTE:", m, p, "->", getattr(r, "name", None))


# =============================================================================
# STATIC FILE CONFIGURATION
# =============================================================================
# Serve frontend assets such as:
# - JavaScript files
# - CSS files
# - logos
# - map utilities
# =============================================================================

STATIC_DIR = Path(__file__).resolve().parent / "static"

app.add_static_files("/static", str(STATIC_DIR))

print("STATIC_DIR =", STATIC_DIR)

print(
    "STATIC_DIR files =",
    [p.name for p in STATIC_DIR.glob("*") if p.is_file()],
)


# ---------------------------------------------------------------------
# Inject external JS/CSS libraries (Leaflet ecosystem)
# ---------------------------------------------------------------------
# Required for map rendering, drawing, geometry utilities, and snapshotting
# ---------------------------------------------------------------------

ui.add_head_html(
    """
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<link rel="stylesheet" href="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.css">

<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script src="https://unpkg.com/leaflet-draw@1.0.4/dist/leaflet.draw.js"></script>
<script src="https://unpkg.com/leaflet-geometryutil@0.10.1/src/leaflet.geometryutil.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>

<script src="/static/site_map.js"></script>
""",
    shared=True,
)


# =============================================================================
# UI PAGE REGISTRATION
# =============================================================================

register_home_page(
    list_site_sessions,
    sanitize_session_id,
)


# =============================================================================
# APPLICATION ENTRYPOINT
# =============================================================================
# Launch NiceGUI server when executed directly
# =============================================================================

if __name__ in {"__main__", "__mp_main__"}:
    ui.run(
        title="Energy Systems Research Framework",
        reload=False,
        storage_secret=STORAGE_SECRET,
        reconnect_timeout=5,
    )
