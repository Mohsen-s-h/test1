
// src/col/ui/static/site_map_linking.js
// COL Site Design - Transformer ↔ House linking 
// Does NOT modify site_map.js. It only hooks into existing globals:
//   window.COL_MAP, window.COL_DRAWN, localStorage.col_site_design_session_id
// Requires backend endpoints (see site_design_links_api.py):
//   GET/PUT /api/site/sessions/<sid>/links
// ============================================================================
// FILE MAP (quick navigation)
//  1) Constants & storage keys (LS / API)
//  2) Color strategy (distinct per transformer + persisted in links.json)
//  3) Layer meta helpers (read __COL_META__, index by id)
//  4) Styling/highlight helpers (save orig style, apply highlight, restore)
//  5) Global state object + persistence to localStorage
//  6) Backend I/O (loadLinks/saveLinks)
//  7) Panel UI injection + wiring (buttons + color controls)
//  8) Panel rendering (updatePanel, chips)
//  9) Repaint engine (repaintHighlights)
// 10) Click routing (transformer click vs house click)
// 11) Bootstrap + waitForMap loop
// ============================================================================

// ============================================================================
// SECTION 1: Constants (LocalStorage keys + Backend endpoints)
// ============================================================================

// (function () {
//   // disable linking if map is not the Site Design map

//   function isSiteDesignTab(){
//       return document.getElementById("col_map") !== null
//   }

//   if(!isSiteDesignTab()){
//       console.log("Site Design map not ready yet → waiting...")
//   }

//   'use strict';




  (function () {
    'use strict';

    if (window.__COL_LINKING_SCRIPT_LOADED__) {
      console.log('[COL linking] script already loaded -> skipping duplicate boot');
      return;
    }
    window.__COL_LINKING_SCRIPT_LOADED__ = true;

    function isSiteDesignTab() {
      return document.getElementById('col_map') !== null;
    }

    window.COL_SITE_DESIGN_ENABLED = !!window.COL_SITE_DESIGN_ENABLED;




  const LS = {
    sid: 'col_site_design_session_id',
    link_on: 'col_linking_on',
    unlink_on: 'col_unlink_on',
    multi_on: 'col_link_multi_on',
    show_all: 'col_link_show_all',
    active_txs: 'col_link_active_transformers',
    primary_tx: 'col_link_primary_transformer',
  };

  const API = {
    links: (sid) => `/api/site/sessions/${encodeURIComponent(sid)}/links`,
  };

  const $ = (id) => document.getElementById(id);

// ============================================================================
// SECTION 2: Tiny utility helpers (time, parsing, session id)
// ============================================================================


  function nowIso() { return new Date().toISOString(); }

  function safeJsonParse(s, fallback) {
    try {
      const v = JSON.parse(s);
      return v == null ? fallback : v;
    } catch { return fallback; }
  }

  function getSid() { return localStorage.getItem(LS.sid) || ''; }

  // --------------------------
  // Stable color per transformer 
  // --------------------------
  function fnv1a32(str) {
    let h = 0x811c9dc5;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 0x01000193) >>> 0;
    }
    return h >>> 0;
  }

// ---------------------------------------------------------------------------
// Color strategy 
//
// Problem: hashing transformer_id -> hue can produce visually "near" colors.
// Fix:
//   1) Each transformer gets a persisted color stored in links.json:
//        doc.transformers[tx_id].color = "#rrggbb"
//   2) If a transformer has no color yet, we assign a *new distinct* color using
//      a golden-angle hue walk with a minimum hue separation from existing colors.
//   3) Because the color is persisted, it is stable across refresh and sessions.
// ---------------------------------------------------------------------------

function hslToHex(h, s, l) {
  const to01 = (x) => Math.max(0, Math.min(1, x));
  h = ((h % 360) + 360) % 360;
  s = to01(s); l = to01(l);

  const c = (1 - Math.abs(2 * l - 1)) * s;
  const hp = h / 60;
  const x = c * (1 - Math.abs((hp % 2) - 1));
  let r1 = 0, g1 = 0, b1 = 0;
  if (0 <= hp && hp < 1) [r1, g1, b1] = [c, x, 0];
  else if (1 <= hp && hp < 2) [r1, g1, b1] = [x, c, 0];
  else if (2 <= hp && hp < 3) [r1, g1, b1] = [0, c, x];
  else if (3 <= hp && hp < 4) [r1, g1, b1] = [0, x, c];
  else if (4 <= hp && hp < 5) [r1, g1, b1] = [x, 0, c];
  else if (5 <= hp && hp < 6) [r1, g1, b1] = [c, 0, x];

  const m = l - c / 2;
  const r = Math.round((r1 + m) * 255);
  const g = Math.round((g1 + m) * 255);
  const b = Math.round((b1 + m) * 255);
  return "#" + [r, g, b].map(v => v.toString(16).padStart(2, "0")).join("");
}

function hexToRgb(hex) {
  if (typeof hex !== "string") return null;
  const m = hex.trim().match(/^#([0-9a-f]{6})$/i);
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0;
  const l = (max + min) / 2;
  const d = max - min;
  if (d !== 0) {
    s = d / (1 - Math.abs(2 * l - 1));
    switch (max) {
      case r: h = ((g - b) / d) % 6; break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, s, l };
}

// ============================================================================
// SECTION 3: Transformer color strategy (stable + distinct + persisted)
// ----------------------------------------------------------------------------
// Goal: each transformer gets a consistent, visually distinct color.
// Source of truth: links.json -> doc.transformers[txId].color
// ============================================================================


function hash32(str) {
  // FNV-1a 32-bit
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h >>> 0;
}

function minHueDistance(h, hues) {
  if (!hues || hues.length === 0) return 999;
  let best = 999;
  for (const x of hues) {
    const d = Math.abs(h - x);
    const dd = Math.min(d, 360 - d);
    if (dd < best) best = dd;
  }
  return best;
}

function pickDistinctColor(seedStr, existingHexColors) {
  const GOLDEN = 137.50776405003785; // degrees
  const existingHues = [];
  for (const hex of (existingHexColors || [])) {
    const rgb = hexToRgb(hex);
    if (!rgb) continue;
    existingHues.push(rgbToHsl(rgb.r, rgb.g, rgb.b).h);
  }

  // Start hue based on hash (stable), then walk by golden angle until far enough.
  let hue = (hash32(seedStr) % 360);
  const MIN_SEP = 28; // minimum hue separation in degrees

  // Avoid house base hues (blue-ish) so mapping colors stand out vs default "house" styling
  const forbiddenBands = [
    [200, 260], // blues
    [120, 160], // greens (pv areas)
    [270, 310], // purples (bess)
  ];
  const inForbidden = (h) => forbiddenBands.some(([a, b]) => {
    const hh = ((h % 360) + 360) % 360;
    return a <= hh && hh <= b;
  });

  for (let k = 0; k < 2000; k++) {
    const okSep = minHueDistance(hue, existingHues) >= MIN_SEP;
    if (okSep && !inForbidden(hue)) {
      // vivid, readable outline + light fill
      return {
        stroke: hslToHex(hue, 0.85, 0.45),
        fill: hslToHex(hue, 0.85, 0.70),
        hue,
      };
    }
    hue = (hue + GOLDEN) % 360;
  }

  // fallback (should never happen)
  return { stroke: "#ff006e", fill: "#ffd6e9", hue: 0 };
}

function transformerColor(id) {
  // Returns an object: {stroke, fill}
  const state = window.__COL_LINKS_STATE__;
  const doc = state && state.linksDoc;
  const meta = doc && doc.transformers && doc.transformers[id];

  // If already stored in links.json, use it (stable across refresh).
  if (meta && typeof meta.color === "string") {
    const rgb = hexToRgb(meta.color.trim());
    if (rgb) {
      const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
      return {
        stroke: meta.color.trim(),
        fill: hslToHex(hsl.h, 0.85, 0.72),
      };
    }
  }

  // Otherwise assign a new distinct color and persist it (doc.transformers[id].color).
  const existing = [];
  if (doc && doc.transformers) {
    for (const k of Object.keys(doc.transformers)) {
      const c = doc.transformers[k] && doc.transformers[k].color;
      if (typeof c === "string" && /^#[0-9a-f]{6}$/i.test(c.trim())) existing.push(c.trim());
    }
  }

  const picked = pickDistinctColor(String(id), existing);
  if (doc) {
    if (!doc.transformers) doc.transformers = {};
    doc.transformers[id] = Object.assign({ name: id.slice(0, 8), kind: "transformer" }, meta || {});
    doc.transformers[id].color = picked.stroke;


    saveLinks(doc).catch(err => console.warn('color save failed', err));

  }

  return { stroke: picked.stroke, fill: picked.fill };
}

// ============================================================================
// SECTION 4: Links document schema (versioning + upgrade)
// ----------------------------------------------------------------------------
// We store linking relationships in a JSON doc .
// ============================================================================

function emptyLinksV2() {
    return { version: 2, updated_at: nowIso(), transformers: {}, houses: {}, links: {} };
  }

  function upgradeToV2(doc) {
    if (!doc || typeof doc !== 'object') return emptyLinksV2();
    if (doc.version === 2) {
      doc.transformers = doc.transformers && typeof doc.transformers === 'object' ? doc.transformers : {};
      doc.houses = doc.houses && typeof doc.houses === 'object' ? doc.houses : {};
      doc.links = doc.links && typeof doc.links === 'object' ? doc.links : {};
      doc.updated_at = doc.updated_at || nowIso();
      return doc;
    }
    const v2 = emptyLinksV2();
    const links = (doc.links && typeof doc.links === 'object') ? doc.links : {};
    v2.links = links;
    return v2;
  }

// ============================================================================
// SECTION 5: Access to map layers + metadata helpers
// ----------------------------------------------------------------------------
// Reads from window.COL_DRAWN and layer.__COL_META__ created by site_map.js
// ============================================================================


  // --------------------------
  // Layer indexing helpers
  // --------------------------
  function getDrawn() { return window.COL_DRAWN; }

  function layerMeta(layer) { return (layer && layer.__COL_META__) ? layer.__COL_META__ : null; }

  function metaId(layer) {
    const m = layerMeta(layer);
    return m && m.id ? String(m.id) : null;
  }

  function metaName(layer) {
    const m = layerMeta(layer);
    return m && m.name ? String(m.name) : '';
  }

  function metaKind(layer) {
    const m = layerMeta(layer);
    return m && m.kind ? String(m.kind) : '';
  }

  function indexLayersById() {
    const idx = new Map();
    const drawn = getDrawn();
    if (!drawn) return idx;
    drawn.eachLayer((layer) => {
      const id = metaId(layer);
      if (id) idx.set(id, layer);
    });
    return idx;
  }

  function ensureOrigStyle(layer) {
    if (!layer || !layer.setStyle) return;
    if (!layer.__COL_ORIG_STYLE__) {
      // Best-effort snapshot
      layer.__COL_ORIG_STYLE__ = Object.assign({}, layer.options || {});
    }
  }

// ============================================================================
// SECTION 6: Highlight styling (restore original style, apply colored outline)
// ----------------------------------------------------------------------------
// We never permanently modify layer base style; we snapshot original style and
// repaint highlights safely on every refresh/event.
// ============================================================================

  function restoreOrigStyle(layer) {
    if (!layer || !layer.setStyle) return;
    const st = layer.__COL_ORIG_STYLE__;
    if (st && typeof st === 'object') {
      // Only apply the style-related keys Leaflet cares about
      const keys = ['color', 'weight', 'opacity', 'fillColor', 'fillOpacity', 'dashArray'];
      const apply = {};
      for (const k of keys) if (k in st) apply[k] = st[k];
      layer.setStyle(apply);
    }
  }

  function applyHouseHighlight(layer, colorHex) {
    if (!layer || !layer.setStyle) return;
    ensureOrigStyle(layer);
    layer.setStyle({
      color: colorHex,           // border
      weight: 5,
      opacity: 0.95,
      fillColor: colorHex,
      fillOpacity: 0.28,
      dashArray: null,
    });
  }

  function applyTransformerHighlight(layer, colorHex, active) {
    if (!layer || !layer.setStyle) return;
    ensureOrigStyle(layer);
    layer.setStyle({
      color: colorHex,
      weight: active ? 7 : 5,
      opacity: 0.98,
      fillColor: colorHex,
      fillOpacity: 0.10, // keep transformer visible but not too strong
      dashArray: active ? null : '6,6',
    });
  }

// ============================================================================
// SECTION 7: Runtime state + persistence flags (localStorage-backed)
// ----------------------------------------------------------------------------
// state.linksDoc: in-memory links.json doc
// state.primaryTxId: active transformer for linking
// state.activeTxIds: highlighted transformer set
// ============================================================================

  const state = {
    linksDoc: emptyLinksV2(),
    linkingOn: localStorage.getItem(LS.link_on) === '1',
    unlinkOn: localStorage.getItem(LS.unlink_on) === '1',
    multiOn: localStorage.getItem(LS.multi_on) === '1',
    showAll: localStorage.getItem(LS.show_all) === '1',
    primaryTxId: localStorage.getItem(LS.primary_tx) || '',
    activeTxIds: new Set(safeJsonParse(localStorage.getItem(LS.active_txs), [])),
  };
  window.COL_DEBUG = { state };
// Expose state for other helpers (e.g., color assignment + persisted palette)
window.__COL_LINKS_STATE__ = state;

// Debounced "dirty" saver used by color assignment and other metadata updates.
state._dirtyTimer = null;
state.markDirty = function () {
  if (state._dirtyTimer) clearTimeout(state._dirtyTimer);
  state._dirtyTimer = setTimeout(() => {
    // Best-effort save; failures are logged but do not break UI.
    saveLinks(state.linksDoc).catch(err => console.warn('[COL linking] autosave failed', err));
  }, 600);
};


  function persistStateFlags() {
    localStorage.setItem(LS.link_on, state.linkingOn ? '1' : '0');
    localStorage.setItem(LS.unlink_on, state.unlinkOn ? '1' : '0');
    localStorage.setItem(LS.multi_on, state.multiOn ? '1' : '0');
    localStorage.setItem(LS.show_all, state.showAll ? '1' : '0');
    localStorage.setItem(LS.primary_tx, state.primaryTxId || '');
    localStorage.setItem(LS.active_txs, JSON.stringify(Array.from(state.activeTxIds)));
  }

// ============================================================================
// SECTION 8: Backend persistence (links.json per session)
// ----------------------------------------------------------------------------
// GET/PUT /api/site/sessions/<sid>/links
// ============================================================================

  async function loadLinks() {
    const sid = getSid();
    if (!sid) return emptyLinksV2();

    const res = await fetch(API.links(sid), { headers: { Accept: 'application/json' } });
    if (!res.ok) return emptyLinksV2();
    const doc = await res.json();
    return upgradeToV2(doc);
  }
  // NOTE: saveLinks is the ONLY place that writes to backend.
  // UI changes should update state.linksDoc first, then call saveLinks / markDirty.

  async function saveLinks(doc) {
    const sid = getSid();
    if (!sid) throw new Error('No session id in localStorage');
    doc.updated_at = nowIso();
    const res = await fetch(API.links(sid), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(doc),
    });
    if (!res.ok) throw new Error(`Failed saving links (${res.status})`);
  }

// ============================================================================
// SECTION 9: UI panel injection (buttons, toggles, color picker)
// ----------------------------------------------------------------------------
// Injects a control panel below the main toolbar created in site_map.js
// ============================================================================

  // function injectPanel() {
  //   if (!window.COL_SITE_DESIGN_ENABLED) return;
  //   if ($('col_linking_panel')) return;

  //   // Insert after the existing toolbar if present; else place at top of body

  //   const anchor = $('col_toolbar');
  //   if(!anchor){
  //       console.log("Toolbar not ready → retry injectPanel")
  //       setTimeout(injectPanel, 300);
  //       return
  //   }



  function injectPanel() {
    if (!isSiteDesignTab()) return;
    if (!window.COL_SITE_DESIGN_ENABLED) return;
    if ($('col_linking_panel')) return;

    const anchor = $('col_toolbar');
    if (!anchor) {
      console.log('[COL linking] Toolbar not ready -> retry injectPanel');
      setTimeout(injectPanel, 300);
      return;
    }





    const panel = document.createElement('div');
    panel.id = 'col_linking_panel';
    panel.className = 'col-linking-panel';

    panel.innerHTML = `
      <div class="col-linking-row">
        <button id="col_linking_toggle" class="col-btn">${state.linkingOn ? 'Linking: ON' : 'Linking: OFF'}</button>
        <button id="col_unlink_toggle" class="col-btn">${state.unlinkOn ? 'Unlink: ON' : 'Unlink: OFF'}</button>
        <button id="col_clear_tx" class="col-btn">Clear transformer</button>
        <span class="col-linking-spacer"></span>
        <button id="col_multi_toggle" class="col-btn">${state.multiOn ? 'Multi: ON' : 'Multi: OFF'}</button>
        <button id="col_show_all" class="col-btn">${state.showAll ? 'Show: ALL' : 'Show: ACTIVE'}</button>
      </div>

      <div class="col-linking-grid">
        <div class="col-linking-left">
          <div><b>Session</b> <span id="col_link_session">(none)</span></div>
          <div><b>Primary transformer</b> <span id="col_link_primary">(none)</span></div>
      <div class="col-linking-subrow">
        <span class="k">Color:</span>
        <input id="col_tx_color" type="color" title="Transformer color"/>
        <input id="col_tx_hex" class="col-hex" type="text" placeholder="#RRGGBB" spellcheck="false"/>
        <button id="col_tx_rand" class="col-btn">Randomize</button>
      </div>

          <div><b>Highlighted transformers</b> <span id="col_link_active">(none)</span></div>
          <div><b>Linked houses</b> <span id="col_link_count">0</span></div>
        </div>
        <div class="col-linking-right">
          <div class="col-linking-hint" id="col_link_hint"></div>
          <div class="col-linking-chips" id="col_link_chips"></div>
        </div>
      </div>
    `;

    // place right after toolbar
    anchor.parentElement?.insertBefore(panel, anchor.nextSibling);

    // CSS (scoped)
    if (!$('col_linking_css')) {
      const style = document.createElement('style');
      style.id = 'col_linking_css';
      style.textContent = `
        .col-linking-panel { margin:8px 0 10px 0; padding:10px; border:1px solid #e5e7eb; border-radius:10px; background:#fff; }
        .col-linking-row { display:flex; flex-wrap:wrap; align-items:center; gap:8px; }
        .col-linking-spacer { flex:1; }
        .col-linking-grid { display:grid; grid-template-columns: 240px 1fr; gap:10px; margin-top:8px; }
        .col-linking-left { font-size:13px; color:#111827; display:flex; flex-direction:column; gap:6px; }
        .col-linking-right { display:flex; flex-direction:column; gap:6px; }
        .col-linking-hint { font-size:12px; color:#6b7280; }
        .col-linking-chips { display:flex; flex-wrap:wrap; gap:6px; }
        .col-chip { font-size:12px; border:1px solid #e5e7eb; border-radius:999px; padding:2px 8px; background:#f9fafb; color:#111827; }
        .col-chip.dot::before { content:''; display:inline-block; width:10px; height:10px; border-radius:999px; margin-right:6px; vertical-align:-1px; background: var(--dot,#111); }
      `;
      document.head.appendChild(style);
    }

// ----------------------------------------------------------------------------
// SUBSECTION: Color controls for the PRIMARY transformer
// - writes doc.transformers[txId].color
// - triggers repaintHighlights() + debounced save
// ----------------------------------------------------------------------------

function wireColorControls() {
  const colorInput = $('col_tx_color');
  const hexInput = $('col_tx_hex');
  const randBtn = $('col_tx_rand');

  function normalizeHex(x) {
    if (typeof x !== 'string') return null;
    const v = x.trim();
    if (/^#[0-9a-f]{6}$/i.test(v)) return v.toLowerCase();
    return null;
  }

  function applyColor(hex) {
    if (!state.primaryTxId) return;
    const doc = state.linksDoc;
    if (!doc) return;
    if (!doc.transformers) doc.transformers = {};
    if (!doc.transformers[state.primaryTxId]) {
      doc.transformers[state.primaryTxId] = { name: state.primaryTxName || state.primaryTxId.slice(0, 8), kind: 'transformer' };
    }
    doc.transformers[state.primaryTxId].color = hex;

    // Repaint + persist
    repaintHighlights();
    updatePanel();
    state.markDirty && state.markDirty();
  }

  if (colorInput) {
    colorInput.addEventListener('input', () => {
      const hex = normalizeHex(colorInput.value);
      if (!hex) return;
      if (hexInput) hexInput.value = hex;
      applyColor(hex);
    });
  }

  if (hexInput) {
    hexInput.addEventListener('change', () => {
      const hex = normalizeHex(hexInput.value);
      if (!hex) {
        // revert to current transformer color
        if (state.primaryTxId) {
          const c = transformerColor(state.primaryTxId).stroke;
          hexInput.value = c;
          if (colorInput) colorInput.value = c;
        } else {
          hexInput.value = '';
        }
        return;
      }
      if (colorInput) colorInput.value = hex;
      applyColor(hex);
    });
  }

  if (randBtn) {
    randBtn.addEventListener('click', () => {
      if (!state.primaryTxId) return;
      const doc = state.linksDoc;
      const existing = [];
      if (doc && doc.transformers) {
        for (const k of Object.keys(doc.transformers)) {
          const c = doc.transformers[k] && doc.transformers[k].color;
          if (typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c.trim())) existing.push(c.trim());
        }
      }
      const picked = pickDistinctColor(String(state.primaryTxId) + ':' + Date.now(), existing).stroke;
      if (colorInput) colorInput.value = picked;
      if (hexInput) hexInput.value = picked;
      applyColor(picked);
    });
  }
}


    // Wire buttons
    $('col_linking_toggle').onclick = () => {
      state.linkingOn = !state.linkingOn;
      if (state.linkingOn) state.unlinkOn = false; // mutually exclusive
      persistStateFlags();
      updatePanel();
    };

    $('col_unlink_toggle').onclick = () => {
      state.unlinkOn = !state.unlinkOn;
      if (state.unlinkOn) state.linkingOn = false; // mutually exclusive
      persistStateFlags();
      updatePanel();
    };

    $('col_clear_tx').onclick = () => {
      state.primaryTxId = '';
      if (!state.multiOn) state.activeTxIds.clear();
      persistStateFlags();
      repaintHighlights();
      updatePanel();
    };

    $('col_multi_toggle').onclick = () => {
      state.multiOn = !state.multiOn;
      if (!state.multiOn) {
        // Single mode: keep only primary highlighted
        const keep = state.primaryTxId ? new Set([state.primaryTxId]) : new Set();
        state.activeTxIds = keep;
      }
      persistStateFlags();
      repaintHighlights();
      updatePanel();
    };

    $('col_show_all').onclick = () => {
      state.showAll = !state.showAll;
      persistStateFlags();
      repaintHighlights();
      updatePanel();
    };

    // Wire color controls AFTER panel DOM is created.
    wireColorControls();

  }

// ============================================================================
// SECTION 10: Panel renderer (refresh UI text + chips + counts)
// ----------------------------------------------------------------------------
// Reads current state + drawn layers, renders "active transformer/houses" summary.
// ============================================================================

// Color controls (per-transformer) ------------------------------------------------
// - Stored in links.json: doc.transformers[txId].color = "#RRGGBB"
// - Changing color immediately updates transformer + its linked houses.
function updatePanel() {
    if (!$('col_linking_panel')) return;

    $('col_linking_toggle').textContent = state.linkingOn ? 'Linking: ON' : 'Linking: OFF';
    $('col_unlink_toggle').textContent = state.unlinkOn ? 'Unlink: ON' : 'Unlink: OFF';
    $('col_multi_toggle').textContent = state.multiOn ? 'Multi: ON' : 'Multi: OFF';
    $('col_show_all').textContent = state.showAll ? 'Show: ALL' : 'Show: ACTIVE';

    const sid = getSid();
    $('col_link_session').textContent = sid || '(none)';

    const idx = indexLayersById();
    const primaryLayer = state.primaryTxId ? idx.get(state.primaryTxId) : null;
    const primaryName = primaryLayer ? metaName(primaryLayer) : '';
    const primaryShort = state.primaryTxId ? `${primaryName || '(unnamed)'} (${String(state.primaryTxId).slice(0, 8)}…)` : '(none)';
    $('col_link_primary').textContent = primaryShort;


// Sync color controls (persisted in links.json)
const colorInput = $('col_tx_color');
const hexInput = $('col_tx_hex');
const randBtn = $('col_tx_rand');
if (!state.primaryTxId) {
  if (colorInput) { colorInput.disabled = true; colorInput.value = '#000000'; }
  if (hexInput) { hexInput.disabled = true; hexInput.value = ''; }
  if (randBtn) randBtn.disabled = true;
} else {
  const col = transformerColor(state.primaryTxId);
  if (colorInput) { colorInput.disabled = false; colorInput.value = col.stroke; }
  if (hexInput) { hexInput.disabled = false; hexInput.value = col.stroke; }
  if (randBtn) randBtn.disabled = false;
}

    const active = Array.from(getEffectiveActiveTxIds());
    if (active.length === 0) {
      $('col_link_active').textContent = '(none)';
    } else {
      const names = active.map((id) => {
        const lay = idx.get(id);
        const nm = lay ? metaName(lay) : (state.linksDoc.transformers[id]?.name || '');
        return nm ? nm : String(id).slice(0, 8);
      });
      $('col_link_active').textContent = names.join(', ');
    }

    const { chips, count } = buildHouseChipsForPanel(idx);
    $('col_link_count').textContent = String(count);
    const chipsEl = $('col_link_chips');
    chipsEl.innerHTML = chips;

    $('col_link_hint').textContent =
      'Tip: click a transformer (kind=transformer) to activate it. ' +
      (state.linkingOn ? 'Then click houses to LINK. ' : '') +
      (state.unlinkOn ? 'Then click linked houses to UNLINK. ' : '') +
      (state.multiOn ? 'Multi: click transformers to add/remove highlights. ' : 'Single: transformer click replaces highlight. ') +
      (state.showAll ? 'Show ALL highlights.' : 'Show ACTIVE highlights only.');
  }

  function getEffectiveActiveTxIds() {
    if (state.showAll) {
      const all = Object.keys(state.linksDoc.links || {});
      return new Set(all);
    }
    return state.activeTxIds;
  }

  function buildHouseChipsForPanel(idx) {
    // Group by transformer (for readability at scale)
    const active = Array.from(getEffectiveActiveTxIds());
    let total = 0;
    const parts = [];

    for (const txId of active) {
      const tx = idx.get(txId);
      const txName = tx ? metaName(tx) : (state.linksDoc.transformers[txId]?.name || String(txId).slice(0, 8));
      const color = transformerColor(txId).stroke;

      const houseIds = (state.linksDoc.links && state.linksDoc.links[txId]) ? state.linksDoc.links[txId] : [];
      if (!Array.isArray(houseIds) || houseIds.length === 0) {
        if (state.showAll) {
          parts.push(`<span class="col-chip dot" style="--dot:${color}"><b>${escapeHtml(txName)}</b> <span style="opacity:.7">(0)</span></span>`);
        }
        continue;
      }

      total += houseIds.length;

      parts.push(`<span class="col-chip dot" style="--dot:${color}"><b>${escapeHtml(txName)}</b> <span style="opacity:.7">(${houseIds.length})</span></span>`);
      for (const hid of houseIds) {
        const hl = idx.get(hid);
        const hn = hl ? metaName(hl) : (state.linksDoc.houses[hid]?.name || String(hid).slice(0, 8));
        parts.push(`<span class="col-chip">${escapeHtml(hn)}</span>`);
      }
    }

    return { chips: parts.join(''), count: total };
  }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

// ============================================================================
// SECTION 11: Repaint engine (single source of truth for highlighting)
// ----------------------------------------------------------------------------
// Rule: always restore all original styles first, then apply highlights based on
// state.linksDoc + activeTxIds (or showAll).
// ============================================================================
// NOTE: repaintHighlights is idempotent and safe to call often.
// It always restores original styles first.


  function repaintHighlights() {
    const drawn = getDrawn();
    if (!drawn) return;
  
    // Restore everything first
    drawn.eachLayer((layer) => {
      if (!layer || !layer.setStyle) return;
      restoreOrigStyle(layer);
    });
  
    const idx = indexLayersById();
  
    let active;
    if (state.showAll) {
      active = Object.keys(state.linksDoc?.links || {});
    } else {
      active = Array.from(getEffectiveActiveTxIds());
    }
  
    // Highlight transformers + their houses
    for (const txId of active) {
      const color = transformerColor(txId).stroke;
  
      const txLayer = idx.get(txId);
      if (txLayer) applyTransformerHighlight(txLayer, color, txId === state.primaryTxId);
  
      const houseIds = (state.linksDoc.links && state.linksDoc.links[txId]) ? state.linksDoc.links[txId] : [];
      if (!Array.isArray(houseIds)) continue;
  
      for (const hid of houseIds) {
        const hLayer = idx.get(hid);
        if (hLayer) applyHouseHighlight(hLayer, color);
      }
    }
  }
// ============================================================================
// SECTION 12: Click routing (transformer vs house)
// ----------------------------------------------------------------------------
// transformer click:
//   - sets primaryTxId, manages activeTxIds, updates transformer meta
// house click:
//   - links/unlinks house id under linksDoc.links[primaryTxId]
// ============================================================================

  function wireLayerClicksOnce() {
    const drawn = getDrawn();
    if (!drawn) return;

    drawn.eachLayer((layer) => {
      if (layer.__COL_LINK_WIRED__) return;
      layer.__COL_LINK_WIRED__ = true;

      layer.on('click', async () => {
        try {
          const kind = metaKind(layer);
          const id = metaId(layer);
          if (!id) return;

          // Transformer click: set primary and highlight
          if (kind === 'transformer') {
            state.primaryTxId = id;

            if (!state.multiOn) state.activeTxIds.clear();

            // Toggle highlight in multi mode; else always activate
            if (state.multiOn) {
              if (state.activeTxIds.has(id)) state.activeTxIds.delete(id);
              else state.activeTxIds.add(id);
            } else {
              state.activeTxIds.add(id);
            }

            // Keep metadata for readability
            const txName = metaName(layer) || state.linksDoc.transformers[id]?.name || String(id).slice(0, 8);
            // Preserve existing transformer metadata (especially persisted color) instead of overwriting.
            const prevTxMeta = (state.linksDoc.transformers && state.linksDoc.transformers[id]) ? state.linksDoc.transformers[id] : {};
            state.linksDoc.transformers[id] = Object.assign({}, prevTxMeta, { name: txName, kind: 'transformer' });

            persistStateFlags();
            repaintHighlights();
            updatePanel();
            return;
          }

          // House click: link/unlink based on mode
          if (kind === 'house') {
            if (!state.primaryTxId) {
              // If no transformer selected, ignore
              updatePanel();
              return;
            }

            // Ensure house metadata stored
            const houseName = metaName(layer) || state.linksDoc.houses[id]?.name || String(id).slice(0, 8);
            state.linksDoc.houses[id] = { name: houseName, kind: 'house' };

            // Ensure transformer metadata exists too
            const idx = indexLayersById();
            const txLayer = idx.get(state.primaryTxId);
            const txName = txLayer ? metaName(txLayer) : (state.linksDoc.transformers[state.primaryTxId]?.name || String(state.primaryTxId).slice(0, 8));
            // Preserve existing transformer metadata (especially persisted color) instead of overwriting.
            const prevMeta = (state.linksDoc.transformers && state.linksDoc.transformers[state.primaryTxId]) ? state.linksDoc.transformers[state.primaryTxId] : {};
            state.linksDoc.transformers[state.primaryTxId] = Object.assign({}, prevMeta, { name: txName, kind: 'transformer' });

            // Ensure link array
            if (!state.linksDoc.links[state.primaryTxId]) state.linksDoc.links[state.primaryTxId] = [];
            const arr = state.linksDoc.links[state.primaryTxId];

            const already = arr.includes(id);

            if (state.linkingOn && !already) {
              arr.push(id);
              await saveLinks(state.linksDoc);
              // Always highlight primary even if multi off
              if (!state.multiOn) state.activeTxIds = new Set([state.primaryTxId]);
              else state.activeTxIds.add(state.primaryTxId);
            } else if (state.unlinkOn && already) {
              state.linksDoc.links[state.primaryTxId] = arr.filter((x) => x !== id);
              await saveLinks(state.linksDoc);
            } else {
              // No-op if mode off
            }

            persistStateFlags();
            repaintHighlights();
            updatePanel();
          }
        } catch (e) {
          console.warn('[COL linking] click handler failed', e);
        }
      });
    });
  }

// ============================================================================
// SECTION 13: Bootstrap (load doc, repaint, wire clicks, refresh loop)
// ----------------------------------------------------------------------------
// Runs only after map globals exist. Re-wires periodically to catch new drawings.
// ============================================================================

  async function bootstrap() {

    console.log("COL_MAP:", !!window.COL_MAP)
    console.log("COL_DRAWN:", !!window.COL_DRAWN)
    console.log("COL_SITE_DESIGN_ENABLED:", window.COL_SITE_DESIGN_ENABLED)
    console.log("Toolbar exists:", !!document.getElementById("col_toolbar"))
    injectPanel();

    // load links, repaint, and keep wiring clicks (new layers can be added anytime)
    try {
      state.linksDoc = await loadLinks();
      console.log("[COL linking] links loaded:", state.linksDoc);
    } catch (e) {
      console.warn('[COL linking] loadLinks failed', e);
      state.linksDoc = emptyLinksV2();
    }

    // If primary was stored, ensure it is active at least in single mode
    if (!state.multiOn && state.primaryTxId) {
      state.activeTxIds = new Set([state.primaryTxId]);
    }
  // --------------------------------------------------------------------------
  // Initial repaint
  // --------------------------------------------------------------------------
    repaintHighlights();
    updatePanel();
    // ------------------------------------------------------------
    // Session watcher — reload links if session appears later
    // ------------------------------------------------------------

    const sessionWatcher = setInterval(async () => {

      const sid = getSid();
      if (!sid) return;

      try {

        const doc = await loadLinks();

        if (doc && doc.links && Object.keys(doc.links).length > 0) {

          console.log("[COL linking] Links detected after session load → repainting");

          state.linksDoc = doc;

          repaintHighlights();
          updatePanel();

          clearInterval(sessionWatcher);

        }

      } catch (e) {
        console.warn("[COL linking] session watcher failed", e);
      }

    }, 800);

    // ------------------------------------------------------------
    // Layer click wiring
    // ------------------------------------------------------------

    wireLayerClicksOnce();
    setInterval(wireLayerClicksOnce, 800);
  }


  // Wait until map exists before bootstrapping

  // (function waitForMap() {
  //   const sid = localStorage.getItem('col_site_design_session_id');

  //   if (window.COL_MAP && window.COL_DRAWN) {
  //     bootstrap();
  //     return;
  //   }

  //   console.log("Site Design map not ready yet → waiting...");
  //   setTimeout(waitForMap, 250);

  // })();


  (function waitForMap() {
    if (!isSiteDesignTab()) {
      console.log('[COL linking] waiting for Site Design DOM...');
      setTimeout(waitForMap, 250);
      return;
    }

    if (!window.COL_SITE_DESIGN_ENABLED) {
      console.log('[COL linking] waiting for Site Design enable flag...');
      setTimeout(waitForMap, 250);
      return;
    }

    if (!document.getElementById('col_toolbar')) {
      console.log('[COL linking] waiting for toolbar...');
      setTimeout(waitForMap, 250);
      return;
    }

    if (window.COL_MAP && window.COL_DRAWN) {
      if (!window.__COL_LINKING_BOOTSTRAPPED__) {
        window.__COL_LINKING_BOOTSTRAPPED__ = true;
        bootstrap();
      } else {
        console.log('[COL linking] bootstrap already completed');
      }
      return;
    }

    console.log('[COL linking] Site Design map not ready yet -> waiting...');
    setTimeout(waitForMap, 250);
  })();


})();


