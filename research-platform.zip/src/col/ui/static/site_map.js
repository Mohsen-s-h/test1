
// src/col/ui/static/site_map.js
// Exposes:
//   window.COL_init_map(mapDivId, opts)
//   window.COL_search(query, opts)
// ============================================================================
// FILE MAP / TABLE OF CONTENTS
// ----------------------------------------------------------------------------
// 1) Small helpers + constants (API, LocalStorage keys, time utils)
// 2) Counters system (auto names like house-001, transformer-003)
// 3) Styling + geometry utilities (centroid, length, area)
// 4) GeoJSON serialization (layer -> feature, applyStyle)
// 5) Labels system (ensureLabel + selected layer)
// 6) Move mode (drag polygon by mouse when Move: ON)
// 7) Duplicate feature (copy geojson, offset, new id/name)
// 8) Toolbar UI injection (HTML + CSS, buttons)
// 9) Session I/O (ensureSession, loadGeoJSONIntoMap, saveGeoJSON, snapshot)
// 10) Autosave scheduler
// 11) COL_init_map() main initializer (Leaflet map, draw tools, event wiring)
// 12) Search (COL_search via Nominatim)
// ============================================================================
// NOTE: This file intentionally keeps all map logic in one closure (IIFE) and
// exposes only 2 globals: COL_init_map and COL_search.
// ============================================================================


  // ==========================================================================
  // SECTION A — Constants + basic helpers
  // - $(): tiny DOM helper
  // - API endpoints for session/geojson/snapshot/meta
  // - LocalStorage keys
  // ==========================================================================


(function () {
  'use strict';
  // ======================================================
  // GLOBAL MAP STATE (shared between tabs/windows)
  // ======================================================
  window.COL_STATE = {
    center: null,
    zoom: null
  };
  window.COL_ACTIVE_SESSION = null; //this added

  const $ = (id) => document.getElementById(id);

  const API = {
    newSession: '/api/site/sessions',
    geojson: (sid) => `/api/site/sessions/${encodeURIComponent(sid)}/geojson`,
    snapshot: (sid) => `/api/site/sessions/${encodeURIComponent(sid)}/snapshot`,
    sessionMeta: (sid) => `/api/site/sessions/${encodeURIComponent(sid)}/session`,
  };

  const LS = {
    // sessionId: 'col_site_design_session_id',
    counters: 'col_site_design_counters',
    autosave: 'col_site_design_autosave',
  };

  function nowIso() { return new Date().toISOString(); }
    function safeJsonParse(s, fallback) {
    try {
      const v = JSON.parse(s);
      // IMPORTANT: JSON.parse("null") returns null -> treat as invalid
      if (v === null || typeof v !== 'object' || Array.isArray(v)) return fallback;
      return v;
    } catch {
      return fallback;
    }
  }

// ==========================================================================
// SECTION B — Counters + auto naming
// Purpose:
// - Keep running counters per feature kind (house, transformer, etc.)
// - Generate stable names like: transformer-003
// - Stored in LocalStorage so refresh keeps numbering consistent
// ==========================================================================


  const LS_COUNTERS = 'col_site_design_counters';

  function defaultCounters() {
    return { house: 0, pv_area: 0, bess_area: 0, cable_route: 0, transformer: 0 };
  }

  function getCounters() {
    const raw = localStorage.getItem(LS_COUNTERS);

    // raw can be null; JSON.parse("null") becomes null -> handle BOTH
    let c = null;
    try { c = raw ? JSON.parse(raw) : null; } catch { c = null; }

    if (c === null || typeof c !== 'object' || Array.isArray(c)) c = defaultCounters();

    // ensure keys exist
    const base = defaultCounters();
    for (const k of Object.keys(base)) {
      if (typeof c[k] !== 'number') c[k] = 0;
    }

    // heal storage
    localStorage.setItem(LS_COUNTERS, JSON.stringify(c));
    return c;
  }
  function setCounters(c) {
    if (c === null || typeof c !== 'object' || Array.isArray(c)) c = defaultCounters();
    localStorage.setItem(LS_COUNTERS, JSON.stringify(c));
  }

  function nextName(kind) {
    const c = getCounters();                // NEVER null now
    c[kind] = (typeof c[kind] === 'number' ? c[kind] : 0) + 1;
    setCounters(c);
    return `${kind}-${String(c[kind]).padStart(3, '0')}`;
  }


// ==========================================================================
// SECTION C — Feature styling (by kind)
// Central place that defines the default Leaflet style for each feature type.
// NOTE: meta.style can override these defaults (see applyStyle).
// ==========================================================================


  function kindStyle(kind) {
    const styles = {
      house:        { color: '#2563eb', fillColor: '#93c5fd', fillOpacity: 0.35, weight: 3 },
      pv_area:      { color: '#16a34a', fillColor: '#86efac', fillOpacity: 0.30, weight: 3 },
      bess_area:    { color: '#7c3aed', fillColor: '#c4b5fd', fillOpacity: 0.30, weight: 3 },
      cable_route:  { color: '#ef4444', weight: 5, opacity: 0.9 },
      transformer:  { color: '#f59e0b', fillColor: '#fde68a', fillOpacity: 0.35, weight: 3 },
      road:         { color: '#374151', weight: 4, opacity: 0.8 },
      no_build:     { color: '#111827', fillColor: '#e5e7eb', fillOpacity: 0.25, weight: 2, dashArray: '6,6' },
      default:      { color: '#0ea5e9', fillColor: '#bae6fd', fillOpacity: 0.25, weight: 3 },
    };
    return styles[kind] || styles.default;
  }

  function ensureLeaflet() {
    if (!window.L) throw new Error('Leaflet "L" is not loaded');
  }

  function setStatus(statusId, msg) {
    if (!statusId) return;
    const el = $(statusId);
    if (el) el.textContent = msg;
  }
// ==========================================================================
// SECTION D — Geometry utilities
// - centroidOfLayer(): label anchor point
// - lengthMeters(): for polylines (cable route)
// - areaMeters2(): for polygons (house areas etc.)
// ==========================================================================

  function centroidOfLayer(layer) {
    try {
      if (layer.getLatLngs) {
        const latlngs = layer.getLatLngs();
        const pts = Array.isArray(latlngs[0]) ? latlngs[0] : latlngs;
        let sLat = 0, sLng = 0;
        const n = pts.length || 1;
        pts.forEach(p => { sLat += p.lat; sLng += p.lng; });
        return L.latLng(sLat / n, sLng / n);
      }
      if (layer.getLatLng) return layer.getLatLng();
    } catch {}
    return null;
  }

  function lengthMeters(layer) {
    if (!layer.getLatLngs) return null;
    const latlngs = layer.getLatLngs();
    const pts = Array.isArray(latlngs[0]) ? latlngs[0] : latlngs;
    let d = 0;
    for (let i = 1; i < pts.length; i++) d += pts[i - 1].distanceTo(pts[i]);
    return d;
  }

  function areaMeters2(layer) {
    if (!window.L || !L.GeometryUtil || !L.GeometryUtil.geodesicArea) return null;
    if (!layer.getLatLngs) return null;
    const latlngs = layer.getLatLngs();
    const ring = Array.isArray(latlngs[0]) ? latlngs[0] : latlngs;
    return L.GeometryUtil.geodesicArea(ring);
  }

// ==========================================================================
// SECTION E — GeoJSON serialization + meta
// layerToFeature():
// - Converts Leaflet drawn layer into GeoJSON Feature
// - Ensures properties: id, name, kind, style, created_at, updated_at
// - Adds computed metrics: area_m2, length_m, centroid
// applyStyle():
// - Applies kindStyle + meta.style overrides to Leaflet layer
// ==========================================================================



  function layerToFeature(layer) {
    const gj = layer.toGeoJSON();
    gj.properties = gj.properties || {};
    const p = gj.properties;

    const meta = layer.__COL_META__ || {};
    p.id = meta.id || p.id || crypto.randomUUID?.() || `${Date.now()}_${Math.random()}`;
    p.name = meta.name || p.name || 'Unnamed';
    p.kind = meta.kind || p.kind || 'default';
    p.style = meta.style || p.style || {};
    p.created_at = meta.created_at || p.created_at || nowIso();
    p.updated_at = nowIso();

    const a = areaMeters2(layer);
    const len = lengthMeters(layer);
    if (a != null) p.area_m2 = a;
    if (len != null) p.length_m = len;

    const c = centroidOfLayer(layer);
    if (c) p.centroid = { lat: c.lat, lon: c.lng };

    return gj;
  }

  function applyStyle(layer, meta) {
    const st = Object.assign({}, kindStyle(meta.kind), meta.style || {});
    if (layer.setStyle) layer.setStyle(st);
  }

// ==========================================================================
// SECTION F — Labels
// ensureLabel():
// - Removes existing label marker for a layer (if any)
// - If labelsOn=true, creates a divIcon marker at centroid with meta.name
// Controlled by global: window.COL_LABELS_ON
// ==========================================================================

  function ensureLabel(map, layer, meta, labelsOn) {
    if (layer.__COL_LABEL__) {
      map.removeLayer(layer.__COL_LABEL__);
      layer.__COL_LABEL__ = null;
    }
    if (!labelsOn) return;

    const c = centroidOfLayer(layer);
    if (!c) return;

    const label = L.marker(c, {
      interactive: false,
      icon: L.divIcon({
        className: 'col-label',
        html: `<div class="col-label-pill">${meta.name}</div>`,
      }),
    });

    label.addTo(map);
    layer.__COL_LABEL__ = label;
  }

  function setSelected(layer) { window.COL_SELECTED_LAYER = layer || null; }
  function getSelected() { return window.COL_SELECTED_LAYER || null; }

// ==========================================================================
// SECTION G — Selection + Move mode + Duplication
// - setSelected/getSelected: track selected layer
// - enableMoveMode: when Move: ON, drag polygons without Leaflet edit handles
// - duplicateLayer: clone geojson, offset slightly, new id + new auto name
// ==========================================================================


  function enableMoveMode(map, layer) {
    if (!layer || !layer.getLatLngs) return;

    let dragging = false;
    let startPt = null;

    function onMouseDown(e) {
      if (!window.COL_MOVE_MODE) return;
      dragging = true;
      startPt = e.latlng;
      map.dragging.disable();
    }

    function onMouseMove(e) {
      if (!window.COL_MOVE_MODE || !dragging || !startPt) return;

      const dx = e.latlng.lng - startPt.lng;
      const dy = e.latlng.lat - startPt.lat;
      startPt = e.latlng;

      const latlngs = layer.getLatLngs();
      const isNested = Array.isArray(latlngs[0]);
      const pts = isNested ? latlngs[0] : latlngs;

      const moved = pts.map(p => L.latLng(p.lat + dy, p.lng + dx));
      if (isNested) layer.setLatLngs([moved]); else layer.setLatLngs(moved);
      layer.redraw?.();

      const meta = layer.__COL_META__ || {};
      if (window.COL_LABELS_ON) ensureLabel(map, layer, meta, true);
    }

    function onMouseUp() {
      if (!window.COL_MOVE_MODE) return;
      dragging = false;
      startPt = null;
      map.dragging.enable();
    }

    layer.on('mousedown', onMouseDown);
    map.on('mousemove', onMouseMove);
    map.on('mouseup', onMouseUp);
  }

  function duplicateLayer(map, drawnItems, layer) {
    if (!layer) return null;

    const gj = layer.toGeoJSON();
    const meta = Object.assign({}, layer.__COL_META__ || {});
    meta.id = crypto.randomUUID?.() || `${Date.now()}_${Math.random()}`;
    meta.name = nextName(meta.kind || 'default');
    meta.created_at = nowIso();
    meta.updated_at = nowIso();

    const offset = { dx: 0.00015, dy: 0.00010 };
    function offsetCoords(coords) {
      if (typeof coords[0] === 'number') return [coords[0] + offset.dx, coords[1] + offset.dy];
      return coords.map(offsetCoords);
    }
    if (gj.geometry && gj.geometry.coordinates) {
      gj.geometry.coordinates = offsetCoords(gj.geometry.coordinates);
    }

    const newLayer = L.geoJSON(gj, { style: () => kindStyle(meta.kind) }).getLayers()[0];
    if (!newLayer) return null;

    newLayer.__COL_META__ = meta;
    applyStyle(newLayer, meta);
    drawnItems.addLayer(newLayer);

    setSelected(newLayer);
    if (window.COL_LABELS_ON) ensureLabel(map, newLayer, meta, true);

    return newLayer;
  }

// ==========================================================================
// SECTION H — Toolbar injection
// injectToolbar():
// - Inserts custom toolbar above the map (kind select + buttons)
// injectToolbarCss():
// - Adds CSS styling for toolbar + label pill
// ==========================================================================


  function injectToolbar(containerId) {
    const host = $(containerId);
    if (!host) return;
    if ($('col_toolbar')) return;

    const toolbar = document.createElement('div');
    toolbar.id = 'col_toolbar';
    toolbar.className = 'col-toolbar';
    toolbar.innerHTML = `
      <div class="col-toolbar-row">
        <label class="col-toolbar-label">Type:</label>
        <select id="col_kind_select" class="col-select">
          <option value="house">house</option>
          <option value="pv_area">pv_area</option>
          <option value="bess_area">bess_area</option>
          <option value="cable_route">cable_route</option>
          <option value="transformer">transformer</option>
          <option value="road">road</option>
          <option value="no_build">no_build</option>
        </select>

        <button id="col_labels_btn" class="col-btn">Labels: OFF</button>
        <button id="col_move_btn" class="col-btn">Move: OFF</button>
        <button id="col_duplicate_btn" class="col-btn">Duplicate</button>
        <button id="col_editmeta_btn" class="col-btn">Edit Meta</button>
        <button id="col_delete_btn" class="col-btn">Delete</button>
        <button id="col_save_btn" class="col-btn primary">Save Session</button>
        <button id="col_new_btn" class="col-btn">New Session</button>
        <button id="col_snapshot_btn" class="col-btn">Snapshot PNG</button>
      </div>
      <div class="col-toolbar-row small">
        Tip: draw shapes, click to select, <b>Duplicate</b> then turn <b>Move: ON</b> and drag the copy to place it.
      </div>
    `;
    host.parentElement?.insertBefore(toolbar, host);
  }

  function injectToolbarCss() {
    if ($('col_toolbar_css')) return;
    const style = document.createElement('style');
    style.id = 'col_toolbar_css';
    style.textContent = `
      .col-toolbar { display:flex; flex-direction:column; gap:6px; padding:10px; border:1px solid #e5e7eb; border-radius:10px; margin:8px 0 10px 0; background:#fff; }
      .col-toolbar-row { display:flex; flex-wrap:wrap; align-items:center; gap:8px; }
      .col-toolbar-row.small { font-size:12px; color:#6b7280; }
      .col-toolbar-label { font-size:13px; color:#374151; margin-right:4px; }
      .col-select { padding:6px 8px; border-radius:8px; border:1px solid #d1d5db; outline:none; font-size:13px; }
      .col-btn { padding:6px 10px; border-radius:10px; border:1px solid #d1d5db; background:#fff; cursor:pointer; font-size:13px; }
      .col-btn:hover { background:#f3f4f6; }
      .col-btn.primary { background:#3b82f6; border-color:#3b82f6; color:#fff; }
      .col-btn.primary:hover { background:#2563eb; }
      .col-label .col-label-pill{ background:rgba(255,255,255,0.95); border:1px solid #e5e7eb; border-radius:999px; padding:2px 8px; font-size:12px; font-weight:600; color:#111827; box-shadow:0 2px 6px rgba(0,0,0,0.08); white-space:nowrap; }
    `;
    document.head.appendChild(style);
  }

// ==========================================================================
// SECTION I — Session management + persistence (backend API)
// ensureSession():
// - Creates session on backend if missing; stores session id in LocalStorage
// loadGeoJSONIntoMap():
// - Loads saved FeatureCollection into map (but does NOT wipe if user drew)
// saveGeoJSON():
// - PUTs FeatureCollection to backend
// saveSnapshot():
// - Captures map div -> PNG -> POST to backend
// ==========================================================================


  async function ensureSession(statusId) {
    // let sid = localStorage.getItem(LS.sessionId);
    let sid = window.COL_ACTIVE_SESSION; //this added
    if (sid) return sid;

    setStatus(statusId, 'Creating session...');
    const res = await fetch(API.newSession, { method: 'POST' });
    if (!res.ok) throw new Error(`Failed to create session: ${res.status}`);
    const js = await res.json();
    sid = js.session_id;
    // localStorage.setItem(LS.sessionId, sid);
    window.COL_ACTIVE_SESSION = sid; //this added
    setStatus(statusId, `Session: ${sid}`);
    return sid;
  }

  async function loadGeoJSONIntoMap(map, drawnItems, statusId) {
    // const sid = localStorage.getItem(LS.sesionId);
    const sid = window.COL_ACTIVE_SESSION; //this added
    if (!sid) return;

    // CRITICAL FIX:
    // if already drew something, DO NOT clear/overwrite it
    let hasAnything = false;
    drawnItems.eachLayer(() => { hasAnything = true; });
    if (hasAnything) return;

    try {
      const res = await fetch(API.geojson(sid));
      if (!res.ok) return;
      const fc = await res.json();
      if (!fc || !fc.features) return;

      drawnItems.clearLayers();

      const layers = L.geoJSON(fc, {
        style: (feature) => {
          const kind = feature?.properties?.kind || 'default';
          const style = feature?.properties?.style || {};
          return Object.assign({}, kindStyle(kind), style);
        },
        onEachFeature: (feature, layer) => {
          const p = feature.properties || {};
          layer.__COL_META__ = {
            id: p.id, name: p.name, kind: p.kind, style: p.style || {},
            created_at: p.created_at, updated_at: p.updated_at,
          };
          applyStyle(layer, layer.__COL_META__);

          layer.on('click', () => setSelected(layer));
          layer.on('dblclick', () => {
            const meta = layer.__COL_META__ || {};
            const nn = prompt('Rename feature:', meta.name || '');
            if (nn && nn.trim()) {
              meta.name = nn.trim();
              layer.__COL_META__ = meta;
              if (window.COL_LABELS_ON) ensureLabel(map, layer, meta, true);
            }
          });

          enableMoveMode(map, layer);
          if (window.COL_LABELS_ON) ensureLabel(map, layer, layer.__COL_META__, true);
        },
      });

      layers.getLayers().forEach(l => drawnItems.addLayer(l));
      setStatus(statusId, 'Loaded saved features');
    } catch (e) {
      console.warn('[COL] loadGeoJSON failed', e);
    }
  }

  function serializeDrawn(drawnItems) {
    const features = [];
    drawnItems.eachLayer((layer) => features.push(layerToFeature(layer)));
    return { type: 'FeatureCollection', features };
  }

  async function saveGeoJSON(drawnItems, statusId) {
    // const sid = localStorage.getItem(LS.sessionId);
    const sid = window.COL_ACTIVE_SESSION; //this added
    if (!sid) throw new Error('No session_id. Create session first.');

    const fc = serializeDrawn(drawnItems);

    const res = await fetch(API.geojson(sid), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fc),
    });
    if (!res.ok) throw new Error(`Save failed: ${res.status}`);
    setStatus(statusId, 'Saved');
  }

  async function saveSnapshot(mapDivId, statusId) {
    // const sid = localStorage.getItem(LS.sessionId);
    const sid = window.COL_ACTIVE_SESSION; //this added

    if (!sid) throw new Error('No session_id.');

    if (typeof window.html2canvas !== 'function') {
      setStatus(statusId, 'Snapshot needs html2canvas');
      alert('Snapshot requires html2canvas. Add it in app_tabs.py head HTML.');
      return;
    }

    const el = $(mapDivId);
    if (!el) throw new Error('Map div not found');

    setStatus(statusId, 'Rendering snapshot...');
    const canvas = await window.html2canvas(el, { useCORS: true, backgroundColor: null });
    const dataUrl = canvas.toDataURL('image/png');

    const res = await fetch(API.snapshot(sid), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ png_data_url: dataUrl }),
    });
    if (!res.ok) throw new Error(`Snapshot failed: ${res.status}`);

    setStatus(statusId, 'Snapshot saved');
  }


// ==========================================================================
// SECTION J — Autosave
// scheduleAutosave():
// - If LS.autosave == '1', schedules a delayed save to avoid spam
// ==========================================================================



  let _autosaveTimer = null;
  function scheduleAutosave(drawnItems, statusId) {
    const enabled = localStorage.getItem(LS.autosave) === '1';
    if (!enabled) return;

    clearTimeout(_autosaveTimer);
    _autosaveTimer = setTimeout(() => {
      saveGeoJSON(drawnItems, statusId).catch(err => console.warn(err));
    }, 900);
  }

// ==========================================================================
// SECTION K — Main entry: COL_init_map()
// Responsibilities:
// 1) Create Leaflet map + base tile layer
// 2) Create feature groups: drawnItems + searchLayer
// 3) Initialize global UI states (labels/move)
// 4) Ensure session + restore saved GeoJSON
// 5) Configure Leaflet.Draw + event handlers (created/edited/deleted)
// 6) Wire toolbar buttons (labels/move/duplicate/edit/delete/save/new/snap)
// 7) Wire optional search UI (Enter key / button)
// ==========================================================================


  function COL_init_map(mapDivId = 'col_map', opts = {}) {
    ensureLeaflet();

    const {
      statusId = 'col_map_status',
      center = [43.8966433, -79.1056840],
      zoom = 17,
      enableDraw = false,
      autoWireSearchUI = true,
    } = opts;

    const mapEl = $(mapDivId);
    if (!mapEl) throw new Error(`Map div #${mapDivId} not found`);

    injectToolbarCss();

    if (enableDraw) {
      injectToolbar(mapDivId);
    }



    if (mapEl.__COL_MAP__) {

      window.COL_MAP = mapEl.__COL_MAP__;
  
      setTimeout(()=>{
          mapEl.__COL_MAP__.invalidateSize();
      },200);
  
      return mapEl.__COL_MAP__;
  }



    setStatus(statusId, 'Initializing map...');

    const map = L.map(mapDivId).setView(center, zoom);
    window.COL_MAP = map;
    mapEl.__COL_ENABLE_DRAW__ = enableDraw


    // Restore previous map state if it exists
    if (window.COL_STATE.center) {

      map.setView(
        window.COL_STATE.center,
        window.COL_STATE.zoom
      );

    }    

    // Save map state whenever map moves
    map.on("moveend", function () {

      const c = map.getCenter();

      window.COL_STATE.center = [c.lat, c.lng];
      window.COL_STATE.zoom = map.getZoom();

    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    const drawnItems = new L.FeatureGroup();
    map.addLayer(drawnItems);

    const searchLayer = new L.FeatureGroup();
    map.addLayer(searchLayer);




    window.COL_DRAWN = drawnItems;
    window.COL_SEARCH_LAYER = searchLayer;

    window.COL_LABELS_ON = false;
    window.COL_MOVE_MODE = false;

    // CRITICAL FIX: create session + restore immediately (no delayed clear wipe)
    // (async () => {
    //   try {
    //     await ensureSession(statusId);
    //     await loadGeoJSONIntoMap(map, drawnItems, statusId);
    //     setTimeout(() => map.invalidateSize(), 250);
    //   } catch (e) {
    //     console.warn('[COL] session/restore failed', e);
    //   }
    // })();

    // (async () => {
    //   try {
    
    //     await ensureSession(statusId);
    
    //     // Only load drawings when drawing mode is enabled
    //     if (enableDraw) {
    //       await loadGeoJSONIntoMap(map, drawnItems, statusId);
    //     }
    
    //     setTimeout(() => map.invalidateSize(), 250);
    
    //   } catch (e) {
    //     console.warn('[COL] session/restore failed', e);
    //   }
    // })();    
    // new below added replace above because session was getting created on the page reload
    (async () => {
      try {
    
        const sid = window.COL_ACTIVE_SESSION;
    
        if (!sid) {
          console.log("[COL] No active session — waiting for user to create one");
          return;
        }
    
        if (enableDraw) {
          await loadGeoJSONIntoMap(map, drawnItems, statusId);
        }
    
        setTimeout(() => map.invalidateSize(), 250);
    
      } catch (e) {
        console.warn('[COL] session/restore failed', e);
      }
    })();

    if (enableDraw && L.Control && L.Control.Draw) {
      const drawControl = new L.Control.Draw({
        position: 'topleft',
        draw: {
          polyline: { shapeOptions: { color: kindStyle('cable_route').color, weight: kindStyle('cable_route').weight } },
          rectangle: true,
          polygon: { allowIntersection: false, showArea: true },
          circle: false,
          circlemarker: false,
          marker: false,
        },
        edit: { featureGroup: drawnItems, edit: true, remove: true },
      });
      map.addControl(drawControl);

      // IMPORTANT FIX: DO NOT "await" before adding the layer
      map.on(L.Draw.Event.CREATED, (e) => {
        const layer = e.layer;

        try {
          // Assign type & auto name (NO backend needed to keep the drawing)
          const kindSel = $('col_kind_select');
          const kind = kindSel ? kindSel.value : 'house';

          const meta = {
            id: crypto.randomUUID?.() || `${Date.now()}_${Math.random()}`,
            kind,
            name: nextName(kind),
            style: {},
            created_at: nowIso(),
            updated_at: nowIso(),
          };
          layer.__COL_META__ = meta;

          applyStyle(layer, meta);

          // IMPORTANT: add to drawnItems immediately so it never disappears
          drawnItems.addLayer(layer);

          // selection + interactions
          layer.on('click', () => setSelected(layer));
          layer.on('dblclick', () => {
            const m = layer.__COL_META__ || {};
            const nn = prompt('Rename feature:', m.name || '');
            if (nn && nn.trim()) {
              m.name = nn.trim();
              layer.__COL_META__ = m;
              if (window.COL_LABELS_ON) ensureLabel(map, layer, m, true);
            }
          });

          enableMoveMode(map, layer);
          ensureLabel(map, layer, meta, window.COL_LABELS_ON);

          // Popup info
          const a = areaMeters2(layer);
          const len = lengthMeters(layer);
          let html = `<b>${meta.name}</b><br>${meta.kind}`;
          if (a != null) html += `<br>Area: ${(a).toFixed(1)} m²`;
          if (len != null) html += `<br>Length: ${(len).toFixed(1)} m`;
          layer.bindPopup(html).openPopup();

          // Create session in background (never blocks drawing)
          ensureSession(statusId).catch(err => {
            console.warn('[COL] ensureSession failed:', err);
            setStatus(statusId, 'Warning: session not created yet (drawings still kept)');
          });

          // Optional autosave
          scheduleAutosave(drawnItems, statusId);

        } catch (err) {
          console.error('[COL] draw:created failed', err);
          setStatus(statusId, `Draw error: ${err?.message || err}`);
          // still keep the layer if it was added
        }
      });


      map.on('draw:edited', () => {
        drawnItems.eachLayer((layer) => {
          const meta = layer.__COL_META__ || {};
          ensureLabel(map, layer, meta, window.COL_LABELS_ON);
        });
        scheduleAutosave(drawnItems, statusId);
      });

      map.on('draw:deleted', () => scheduleAutosave(drawnItems, statusId));
    }

    const labelsBtn = $('col_labels_btn');
    const moveBtn = $('col_move_btn');
    const dupBtn = $('col_duplicate_btn');
    const editMetaBtn = $('col_editmeta_btn');
    const delBtn = $('col_delete_btn');
    const saveBtn = $('col_save_btn');
    const newBtn = $('col_new_btn');
    const snapBtn = $('col_snapshot_btn');

    if (labelsBtn) {
      labelsBtn.onclick = () => {
        window.COL_LABELS_ON = !window.COL_LABELS_ON;
        labelsBtn.textContent = `Labels: ${window.COL_LABELS_ON ? 'ON' : 'OFF'}`;
        drawnItems.eachLayer((layer) => {
          const meta = layer.__COL_META__ || {};
          ensureLabel(map, layer, meta, window.COL_LABELS_ON);
        });
      };
    }

    if (moveBtn) {
      moveBtn.onclick = () => {
        window.COL_MOVE_MODE = !window.COL_MOVE_MODE;
        moveBtn.textContent = `Move: ${window.COL_MOVE_MODE ? 'ON' : 'OFF'}`;
      };
    }

    if (dupBtn) {
      dupBtn.onclick = async () => {
        await ensureSession(statusId);
        const sel = getSelected();
        if (!sel) return alert('Select a shape first (click it).');
        const cp = duplicateLayer(map, drawnItems, sel);
        if (!cp) return alert('Duplicate failed for this shape.');
        scheduleAutosave(drawnItems, statusId);
      };
    }

    if (editMetaBtn) {
      editMetaBtn.onclick = async () => {
        await ensureSession(statusId);
        const sel = getSelected();
        if (!sel) return alert('Select a shape first (click it).');
        const meta = sel.__COL_META__ || {};
        const nn = prompt('Name:', meta.name || '');
        if (nn && nn.trim()) meta.name = nn.trim();

        const kk = prompt('Kind (house, pv_area, bess_area, cable_route, transformer, road, no_build):', meta.kind || 'house');
        if (kk && kk.trim()) meta.kind = kk.trim();

        const cc = prompt('Color (hex like #ff0000) OR empty to keep default:', '');
        if (cc && cc.trim()) meta.style = Object.assign({}, meta.style || {}, { color: cc.trim(), fillColor: cc.trim() });

        sel.__COL_META__ = meta;
        applyStyle(sel, meta);
        ensureLabel(map, sel, meta, window.COL_LABELS_ON);
        scheduleAutosave(drawnItems, statusId);
      };
    }

    if (delBtn) {
      delBtn.onclick = async () => {
        await ensureSession(statusId);
        const sel = getSelected();
        if (!sel) return alert('Select a shape first (click it).');
        drawnItems.removeLayer(sel);
        if (sel.__COL_LABEL__) map.removeLayer(sel.__COL_LABEL__);
        setSelected(null);
        scheduleAutosave(drawnItems, statusId);
      };
    }

    if (saveBtn) {
      saveBtn.onclick = async () => {
        await ensureSession(statusId);
        await saveGeoJSON(drawnItems, statusId);
      };
    }

    if (newBtn) {
      newBtn.onclick = async () => {
        // localStorage.removeItem(LS.sessionId);
        window.COL_ACTIVE_SESSION = null; //this added

        await ensureSession(statusId);
        drawnItems.clearLayers();
        if (window.COL_SEARCH_LAYER) window.COL_SEARCH_LAYER.clearLayers();
        setStatus(statusId, 'New session created (empty)');
      };
    }

    if (snapBtn) {
      snapBtn.onclick = async () => {
        await ensureSession(statusId);
        await saveSnapshot(mapDivId, statusId);
      };
    }



    // --------------------------------------------------
    // Wire search UI AFTER DOM exists
    // --------------------------------------------------
    // if (autoWireSearchUI) {

    //   setTimeout(() => {

    //     const input = document.querySelector('input[placeholder="Search address / place"]');
    //     const btn = document.querySelector('button');

    //     if (btn && input) {

    //       btn.addEventListener('click', async () => {
    //         const q = input.value || '';
    //         await COL_search(q, { statusId });
    //       });

    //       input.addEventListener('keydown', async (ev) => {
    //         if (ev.key === 'Enter') {
    //           await COL_search(input.value || '', { statusId });
    //         }
    //       });

    //       console.log('[COL] Search UI connected');

    //     } else {
    //       console.warn('[COL] Search UI elements not found');
    //     }

    //   }, 300);

    // }
    if (autoWireSearchUI) {
      const input = $('col_search_input');
      const btn = $('col_search_btn');

      if (btn && !btn.__COL_BOUND__) {
        btn.__COL_BOUND__ = true;
        btn.addEventListener('click', async () => {
          const q = input ? input.value : '';
          await COL_search(q, { statusId });
        });
      }
      if (input && !input.__COL_BOUND__) {
        input.__COL_BOUND__ = true;
        input.addEventListener('keydown', async (ev) => {
          if (ev.key === 'Enter') {
            await COL_search(input.value, { statusId });
          }
        });
      }
    }

    const defaultMarker = L.marker(center).addTo(searchLayer);
    defaultMarker.bindPopup('Default location');

    mapEl.__COL_MAP__ = map;
    setStatus(statusId, 'Map ready');
    return map;
  }

// ==========================================================================
// SECTION L — Search: COL_search()
// Uses Nominatim (OpenStreetMap) to geocode a text query and place a marker.
// Writes result marker into window.COL_SEARCH_LAYER and centers map.
// ==========================================================================
// ==========================================================================
// SECTION L — Search: COL_search()
// Uses Nominatim (OpenStreetMap) to geocode a text query and place a marker.
// If no query argument is provided it reads the search input automatically.
// ==========================================================================

async function COL_search(query, opts = {}) {

  ensureLeaflet();

  const { statusId = 'col_map_status', zoom = 17, limit = 1, countrycodes = 'ca' } = opts;

  const map = window.COL_MAP;
  if (!map) throw new Error('Map not initialized. Call COL_init_map first.');

  const q = (query || '').trim();
  if (!q) {
    setStatus(statusId, 'Enter a search query');
    return null;
  }

  setStatus(statusId, 'Searching...');

  // -------------------------------
  // NEW: coordinate detection
  // -------------------------------

  const coordMatch = q.match(/^(-?\d+\.?\d*)[, ]+(-?\d+\.?\d*)$/);

  if (coordMatch) {

    const lat = parseFloat(coordMatch[1]);
    const lon = parseFloat(coordMatch[2]);

    if (window.COL_SEARCH_LAYER) window.COL_SEARCH_LAYER.clearLayers();

    const marker = L.marker([lat, lon]).addTo(window.COL_SEARCH_LAYER);
    marker.bindPopup(`${lat}, ${lon}`).openPopup();

    map.setView([lat, lon], zoom);

    setStatus(statusId, 'Coordinates located');

    return { lat, lon };
  }

  // -------------------------------
  // ORIGINAL Nominatim search
  // -------------------------------

  const params = new URLSearchParams({
    format: 'json',
    q,
    limit: String(limit),
    addressdetails: '1'
  });

  if (countrycodes) params.set('countrycodes', countrycodes);

  const url = `https://nominatim.openstreetmap.org/search?${params.toString()}`;

  const res = await fetch(url, { headers: { Accept: 'application/json' } });

  if (!res.ok) {
    setStatus(statusId, `Search failed: ${res.status}`);
    throw new Error(`Nominatim error: ${res.status}`);
  }

  const data = await res.json();

  if (!Array.isArray(data) || data.length === 0) {
    setStatus(statusId, 'No result');
    return null;
  }

  const hit = data[0];
  const lat = parseFloat(hit.lat);
  const lon = parseFloat(hit.lon);

  if (window.COL_SEARCH_LAYER) window.COL_SEARCH_LAYER.clearLayers();

  const marker = L.marker([lat, lon]).addTo(window.COL_SEARCH_LAYER);
  marker.bindPopup(hit.display_name || q).openPopup();

  map.setView([lat, lon], zoom);

  setStatus(statusId, 'Found');

  return { lat, lon, display_name: hit.display_name, raw: hit };
}


// --------------------------------------------------
// External session loader (called from NiceGUI)
// --------------------------------------------------

window.COL_load_session = async function(sessionId){

  console.log("[COL] Loading session:", sessionId)
  localStorage.setItem("col_site_design_session_id", sessionId);

  if(!sessionId){
    return
  }

  // change active session
  // localStorage.setItem("col_site_design_session_id", sessionId)
  window.COL_ACTIVE_SESSION = sessionId; //this added

  const map = window.COL_MAP
  const drawn = window.COL_DRAWN

  if(!map || !drawn){
    console.warn("Map not ready yet")
    return
  }

  // clear current layers
  drawn.clearLayers()

  // reload saved geojson
  try{

    const res = await fetch(`/api/site/sessions/${encodeURIComponent(sessionId)}/geojson`)

    if(!res.ok){
      console.warn("No saved geometry for session")
      return
    }

    const fc = await res.json()

    if(!fc || !fc.features) return

    const layers = L.geoJSON(fc,{
      style:(feature)=>{
        const kind = feature?.properties?.kind || "default"
        const style = feature?.properties?.style || {}
        return Object.assign({}, kindStyle(kind), style)
      },
      onEachFeature:(feature,layer)=>{

        const p = feature.properties || {}

        layer.__COL_META__={
          id:p.id,
          name:p.name,
          kind:p.kind,
          style:p.style || {},
          created_at:p.created_at,
          updated_at:p.updated_at
        }

        applyStyle(layer,layer.__COL_META__)

        layer.on("click",()=>setSelected(layer))

        enableMoveMode(map,layer)

        if(window.COL_LABELS_ON){
          ensureLabel(map,layer,layer.__COL_META__,true)
        }
      }
    })

    layers.getLayers().forEach(l=>drawn.addLayer(l))

    if(drawn.getLayers().length){
      map.fitBounds(drawn.getBounds())
    }

  }catch(e){
    console.error("Session load failed",e)
  }
}



window.COL_init_map = COL_init_map;
window.COL_search = COL_search;
})();


// ============================================================
// Move map to project location (used by Project Setup search)
// ============================================================

function COL_set_project_location(lat, lon, label) {

  if (!window.COL_MAP) {
      console.warn("COL_MAP not available")
      return
  }

  const coords = [lat, lon]

  window.COL_MAP.setView(coords, 17)

  if (window.COL_PROJECT_MARKER) {
      window.COL_MAP.removeLayer(window.COL_PROJECT_MARKER)
  }

  window.COL_PROJECT_MARKER = L.marker(coords).addTo(window.COL_MAP)

  if (label) {
      window.COL_PROJECT_MARKER.bindPopup(label).openPopup()
  }
}


// ==========================================================================
// END — Export public API and close module
// ==========================================================================
