"""
src/col/ui/__init__.py

User interface layer for the COL platform.

This package contains all components related to the user interface,
including page structures, tab-based layouts, and API interaction
modules. It is responsible for presenting platform functionalities
to the user and enabling interaction with underlying platform services.

Typical Usage:
- Access UI components and layouts
- Integrate user interface with platform and core modules
"""
