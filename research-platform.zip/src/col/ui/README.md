# ui

User interface layer.
Initial version will use NiceGUI.
