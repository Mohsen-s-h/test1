"""
Tests for project setup tab helper functions.
"""

from col.ui.pages.tabs.project_setup_tab import _safe_name


def test_safe_name_replaces_spaces_with_underscores() -> None:
    assert _safe_name("My Project") == "My_Project"


def test_safe_name_removes_special_characters() -> None:
    assert _safe_name("Proj@#1") == "Proj1"


def test_safe_name_trims_whitespace() -> None:
    assert _safe_name("  Test Project  ") == "Test_Project"


def test_safe_name_returns_project_for_empty_string() -> None:
    assert _safe_name("") == "project"
