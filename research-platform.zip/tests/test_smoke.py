"""
tests/test_smoke.py

Basic smoke test to verify that the test suite is configured
and running correctly.
"""


def test_smoke():
    """Ensure the test framework executes successfully."""
    assert True
