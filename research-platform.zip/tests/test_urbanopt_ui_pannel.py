"""
tests/test_urbanopt_ui_pannel.py

Tests for deterministic helper behavior in the URBANopt load forecasting UI panel.

Purpose
-------
Validate that the extracted URBANopt panel keeps its plotting behavior intact
after refactoring out of the top-level tab module.
"""

from __future__ import annotations

import pandas as pd

from col.platform.cores.load_forecasting.urbanopt import (
    urbanopt_ui_pannel as module_under_test,
)


def test_build_plotly_figure_adds_feature_traces_and_total_trace() -> None:
    """The Plotly builder should create one trace per feature plus a TOTAL trace."""
    df_a = pd.DataFrame(
        {
            "Datetime": pd.date_range("2026-01-01", periods=3, freq="h"),
            "Electricity (kW)": [1.0, 2.0, 3.0],
        }
    )
    df_b = pd.DataFrame(
        {
            "Datetime": pd.date_range("2026-01-01", periods=3, freq="h"),
            "Electricity (kW)": [4.0, 5.0, 6.0],
        }
    )

    feature_data = [
        {"name": "Feature A", "df": df_a, "columns": ["Electricity (kW)"]},
        {"name": "Feature B", "df": df_b, "columns": ["Electricity (kW)"]},
    ]

    fig = module_under_test._build_plotly_figure(
        feature_data,
        "Electricity (kW)",
    )

    assert len(fig.data) == 3
    assert [trace.name for trace in fig.data] == ["Feature A", "Feature B", "TOTAL"]
    assert list(fig.data[-1].y) == [5.0, 7.0, 9.0]
    assert fig.layout.title.text == "Electricity (kW)"
    assert fig.layout.xaxis.title.text == "Time"
    assert fig.layout.yaxis.title.text == "kW"
