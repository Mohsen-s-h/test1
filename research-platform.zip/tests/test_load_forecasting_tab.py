"""
tests/test_load_forecasting_tab.py

Tests for the thin top-level load forecasting tab wrapper.

Purpose
-------
Validate that the refactored tab module:
1. displays the active workspace label
2. renders the expected top-level tab labels
3. delegates residential UI rendering to the URBANopt panel module
"""

from __future__ import annotations

from types import SimpleNamespace

import col.ui.pages.tabs.load_forecasting_tab as module_under_test


class _DummyElement:
    """Minimal NiceGUI-like element used for unit testing."""

    def __init__(self, text: str | None = None) -> None:
        self.text = text
        self.class_history: list[str] = []

    def classes(self, value: str):
        self.class_history.append(value)
        return self


class _DummyContext(_DummyElement):
    """Minimal context-manager element used for `with ui....` blocks."""

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        return False


class _DummyUI:
    """Very small UI stub for testing tab-level orchestration."""

    def __init__(self) -> None:
        self.labels: list[str] = []
        self.markdowns: list[str] = []
        self.tabs_created: list[str] = []

    def label(self, text: str):
        self.labels.append(text)
        return _DummyElement(text)

    def markdown(self, text: str):
        self.markdowns.append(text)
        return _DummyElement(text)

    def tabs(self):
        return _DummyContext()

    def tab(self, text: str):
        self.tabs_created.append(text)
        return text

    def tab_panels(self, *args, **kwargs):
        return _DummyContext()

    def tab_panel(self, *args, **kwargs):
        return _DummyContext()


def test_load_forecasting_tab_renders_workspace_and_delegates_residential_panel(
    monkeypatch,
) -> None:
    """The top-level tab should stay thin and delegate residential UI rendering."""
    fake_ui = _DummyUI()
    delegated_calls: list[str] = []

    fake_app = SimpleNamespace(
        storage=SimpleNamespace(
            tab=SimpleNamespace(
                get=lambda key: {"workspace_path": r"C:\demo\workspace"}
                if key == "active_project"
                else None
            )
        )
    )

    monkeypatch.setattr(module_under_test, "ui", fake_ui)
    monkeypatch.setattr(module_under_test, "app", fake_app)
    monkeypatch.setattr(
        module_under_test,
        "render_load_forecasting_urbanopt_panel",
        lambda: delegated_calls.append("called"),
    )

    module_under_test.load_forecasting_tab()

    assert any("Workspace: C:\\demo\\workspace" in label for label in fake_ui.labels)
    assert "## Load Forecasting" in fake_ui.markdowns
    assert fake_ui.tabs_created == [
        "Residential",
        "EV Charging",
        "Data Center",
        "Greenhouse",
    ]
    assert delegated_calls == ["called"]
