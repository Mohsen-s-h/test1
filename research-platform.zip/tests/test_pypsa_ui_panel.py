"""
Tests for the PyPSA DER optimization UI panel module.
"""

from __future__ import annotations

import sys
from pathlib import Path
from types import ModuleType

from col.platform.cores.der_optimization.pypsa import pypsa_ui_panel


def test_run_der_core_returns_result_from_orchestrator(monkeypatch) -> None:
    """The thin worker wrapper should return the orchestrator result unchanged."""
    fake_module = ModuleType("col.platform.orchestration.der_optimization_orchestrator")

    expected = {
        "der_case": "pv+battery",
        "objective": 123.4,
        "pv_kw": 10.0,
        "battery_kw": 5.0,
        "diesel_kw": 0.0,
    }

    def _fake_run_der_optimization(**kwargs):
        return expected

    fake_module.run_der_optimization = _fake_run_der_optimization
    monkeypatch.setitem(
        sys.modules,
        "col.platform.orchestration.der_optimization_orchestrator",
        fake_module,
    )

    result = pypsa_ui_panel._run_der_core(
        project_path=Path("C:/COL/demo"),
        scenario_stem="scenario_a",
        der_case_name="pv+battery",
        battery_hours=4.0,
        grid_import_limit_kw=1000.0,
        costs=object(),
        cb_status=lambda *_args, **_kwargs: None,
        cb_detail=lambda *_args, **_kwargs: None,
        export_dir=Path("C:/COL/demo/export"),
        outage_start_hour=0,
        outage_hours_per_day=0,
        outage_start_date=None,
        return_timeseries=False,
    )

    assert result == expected


def test_run_der_core_returns_error_payload_on_failure(monkeypatch) -> None:
    """The thin worker wrapper should convert worker-side failures into an error payload."""
    fake_module = ModuleType("col.platform.orchestration.der_optimization_orchestrator")

    def _fake_run_der_optimization(**kwargs):
        raise RuntimeError("boom")

    fake_module.run_der_optimization = _fake_run_der_optimization
    monkeypatch.setitem(
        sys.modules,
        "col.platform.orchestration.der_optimization_orchestrator",
        fake_module,
    )

    result = pypsa_ui_panel._run_der_core(
        project_path=Path("C:/COL/demo"),
        scenario_stem="scenario_a",
        der_case_name="pv+battery",
        battery_hours=4.0,
        grid_import_limit_kw=1000.0,
        costs=object(),
        cb_status=lambda *_args, **_kwargs: None,
        cb_detail=lambda *_args, **_kwargs: None,
        export_dir=Path("C:/COL/demo/export"),
        outage_start_hour=0,
        outage_hours_per_day=0,
        outage_start_date=None,
        return_timeseries=False,
    )

    assert "__error__" in result
    assert "RuntimeError" in result["__error__"]
    assert "boom" in result["__error__"]


def test_list_der_result_runs_returns_sorted_directory_names(tmp_path: Path) -> None:
    """DER result run discovery should return sorted folder names only."""
    (tmp_path / "20260404_101500").mkdir()
    (tmp_path / "20260403_090000").mkdir()
    (tmp_path / "notes.txt").write_text("ignore me", encoding="utf-8")

    runs = pypsa_ui_panel.list_der_result_runs(tmp_path)

    assert runs == ["20260403_090000", "20260404_101500"]
