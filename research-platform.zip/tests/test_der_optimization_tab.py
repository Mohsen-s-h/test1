"""
Tests for the thin DER optimization tab wrapper.
"""

from __future__ import annotations

from types import SimpleNamespace

from col.ui.pages.tabs import der_optimization_tab as der_tab_module


class _FakeElement:
    """Minimal chainable UI element used by the tab wrapper test."""

    def classes(self, _value: str) -> "_FakeElement":
        return self

    def __enter__(self) -> "_FakeElement":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


class _FakeUI:
    """Minimal NiceGUI replacement for testing tab layout wiring."""

    def label(self, _text: str) -> _FakeElement:
        return _FakeElement()

    def markdown(self, _text: str) -> _FakeElement:
        return _FakeElement()

    def tabs(self) -> _FakeElement:
        return _FakeElement()

    def tab(self, _name: str) -> _FakeElement:
        return _FakeElement()

    def tab_panels(self, _tabs: object, value: object = None) -> _FakeElement:
        return _FakeElement()

    def tab_panel(self, _tab: object) -> _FakeElement:
        return _FakeElement()


def test_der_optimization_tab_delegates_pypsa_panel(monkeypatch) -> None:
    """The top-level tab should delegate PyPSA rendering to the moved panel module."""
    called = {"count": 0}

    def _fake_render_panel() -> None:
        called["count"] += 1

    fake_app = SimpleNamespace(
        storage=SimpleNamespace(
            tab={
                "active_project": {
                    "workspace_path": "C:/COL/projects/demo",
                }
            }
        )
    )

    monkeypatch.setattr(der_tab_module, "app", fake_app)
    monkeypatch.setattr(der_tab_module, "ui", _FakeUI())
    monkeypatch.setattr(
        der_tab_module,
        "render_der_optimization_pypsa_panel",
        _fake_render_panel,
    )

    der_tab_module.der_optimization_tab()

    assert called["count"] == 1
