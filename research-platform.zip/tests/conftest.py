"""
Pytest configuration for the project test suite.

This file ensures that the src/ directory is added to Python's import path
so tests can import project modules using the package name `col`.
"""

import sys
from pathlib import Path

# Add src to path so tests can import `col.*`
sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))
